-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: localhost    Database: craft_base
-- ------------------------------------------------------
-- Server version	8.0.36-2ubuntu3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sieavnegmdeakjjhfitalbyhnkcccuyqmzyz` (`primaryOwnerId`),
  CONSTRAINT `fk_lqvlybsoyveavwmryqpfpecahscytivnbfzw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sieavnegmdeakjjhfitalbyhnkcccuyqmzyz` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yqgsucbvgyuivuffmpgsusexkcpfidzlygez` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_azeexyjfytscepowioowtmwjfxaxafueqbvq` (`dateRead`),
  KEY `fk_szpqcksreylukinrzbjoufwaxopezseuxfbz` (`pluginId`),
  CONSTRAINT `fk_fnpjwmxrjgihbwnuewjngosvxnakrzzbsfjx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_szpqcksreylukinrzbjoufwaxopezseuxfbz` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mcjbaqboryhzcejwfwwofdlfgnzwukbtyzra` (`sessionId`,`volumeId`),
  KEY `idx_zkyfgnmyqwcaakkbhansucjfuczhzmylcbur` (`volumeId`),
  CONSTRAINT `fk_ciqcbnxrxjbdwwxudhhjgsoayelihxpusain` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_igdfbgmswfcakrqbfzwcxommvixrpwgnbgth` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bfbtlkugmqghxeuyrwvtjjqwsnklmmzxevdh` (`filename`,`folderId`),
  KEY `idx_wdlmetkavrsmbeqwrupinxwnehecqpnyvtna` (`folderId`),
  KEY `idx_kblpvnxbfcpxiesuxvrjkydsteufxrtdecuv` (`volumeId`),
  KEY `fk_wzuacgojebqshekjctqeugzdvvwjescalwsn` (`uploaderId`),
  CONSTRAINT `fk_cnoxfrjnecgunsponvbqeltpyypluhqvnhlg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tutcspwgrkwfwuxnaospmchzyltmaiukgtok` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wzuacgojebqshekjctqeugzdvvwjescalwsn` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xtekdpqsaxctsxxwghtkpkiyombxjszrupta` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_zaypoeenfudpjhzvsjeijatqadrffphplvpi` (`siteId`),
  CONSTRAINT `fk_kjmzoekyaqefvizxwoqzqhucnhfxtkhdkimn` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zaypoeenfudpjhzvsjeijatqadrffphplvpi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_yzirstzfdydzwnsjoozoynsqqlwhmptnocpn` (`userId`),
  CONSTRAINT `fk_yzirstzfdydzwnsjoozoynsqqlwhmptnocpn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mewtmcgivznkpxfyrcgwwcgzsiycsyzjcnbq` (`groupId`),
  KEY `fk_pbddvylmydjrfqmgjjubnqijtnncidkiwlas` (`parentId`),
  CONSTRAINT `fk_ctnyhzjprbnxulutkewezszkzclprwsfgwux` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nfjoeaeosrostmjilxiouwdizqqpvdvqxjcr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pbddvylmydjrfqmgjjubnqijtnncidkiwlas` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gxzyckpnuuuprheiypecaubbhrnnbqafmbwg` (`name`),
  KEY `idx_zydnrnuibumrhseczbhfwezgzsfnzmtkemit` (`handle`),
  KEY `idx_uymzrpsazvpwlhfyrdeizsceymdymbhmohhi` (`structureId`),
  KEY `idx_bczlmxwggaeerfejstjmetjhrhxhxwasmycw` (`fieldLayoutId`),
  KEY `idx_kfzjzanytbguzuvjkgmsscccvjekhmtcqnqm` (`dateDeleted`),
  CONSTRAINT `fk_gzmkmbluzuyukjwntjzckkalucqbzcmzgzut` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kevbnvryatmublzsyksrsjciipmfjhkiwiec` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ocqrjyskycocwabmxzyzrlvedndgowehlpfl` (`groupId`,`siteId`),
  KEY `idx_qvmruggruxgkjmkxxtihfsgtwlihfnyuhxpw` (`siteId`),
  CONSTRAINT `fk_idxvxukwiphvqfffcacdahgeireejjjkuqmw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_iwslpzninzypgvnfalubdblmtfglagbqhode` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ytlihirokbxudbejysvenwgqtskykbkndmpz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_aqgnhcnjfbbmhwwvvazkdveqcbwrkwbanyqx` (`siteId`),
  KEY `fk_bkrxxizcycrcscgojrhlrnclsunchipizbfo` (`userId`),
  CONSTRAINT `fk_aqgnhcnjfbbmhwwvvazkdveqcbwrkwbanyqx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bkrxxizcycrcscgojrhlrnclsunchipizbfo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_jvjqxrqpwthcdugosjtzlqufpqslhqxdodue` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'firstName','2024-06-01 00:21:53',0,1),(1,1,'fullName','2024-06-01 00:21:53',0,1),(1,1,'lastName','2024-06-01 00:21:53',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_cyxomttfalvvwltgijkpbvzbdlzyebhsxbnu` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_mtqgflwbikumbwtdkxoxlqnnvqxlgbxpzqem` (`siteId`),
  KEY `fk_qrzglgourrzpjnllrrchadkbcxxqkfujkism` (`fieldId`),
  KEY `fk_vedfrxdbmfruxexlxgbxayvcavmrugtodhzh` (`userId`),
  CONSTRAINT `fk_axeiczhnqddkkqefldigvqrzhhfvllomxmuz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mtqgflwbikumbwtdkxoxlqnnvqxlgbxpzqem` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qrzglgourrzpjnllrrchadkbcxxqkfujkism` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vedfrxdbmfruxexlxgbxayvcavmrugtodhzh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_mnevhdutqtneasurohsftrdiptvvfuuhdgdv` (`userId`),
  CONSTRAINT `fk_mnevhdutqtneasurohsftrdiptvvfuuhdgdv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zgtufqofcyjykyryjnyltxpgczzqfxoleoye` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_yvckcjzcwyiveidfjdrsvskvtznywchsqosi` (`creatorId`,`provisional`),
  KEY `idx_dbvoeigaegpeflelxjupgwhqxkawjxhkkrrz` (`saved`),
  KEY `fk_rhsbsuncdxyeirjcbplfsxnuwbmeyblpydho` (`canonicalId`),
  CONSTRAINT `fk_rdfxtaobktbjzlrcxiugsjznpgcidegldmbw` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rhsbsuncdxyeirjcbplfsxnuwbmeyblpydho` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_wrpnoziqydvkdncfswsxhlgxpuuadiierwiw` (`elementId`,`timestamp`,`userId`),
  KEY `fk_djeqkoupssrxbodurlrxykytxxiluujstsog` (`userId`),
  KEY `fk_ftgkmfabybipfndlahochccgwryowseiiifc` (`siteId`),
  KEY `fk_dxfqttbbgueagehggurzlcwoqivbetzginns` (`draftId`),
  CONSTRAINT `fk_djeqkoupssrxbodurlrxykytxxiluujstsog` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dxfqttbbgueagehggurzlcwoqivbetzginns` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ftgkmfabybipfndlahochccgwryowseiiifc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qbktyonnvsbqtcqjswkaffjisvgjccwhbotg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (1,1,1,NULL,'save','2024-06-01 00:21:53'),(1,1,1,NULL,'view','2024-06-01 00:21:58'),(2,1,1,NULL,'view','2024-06-01 19:48:10');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yprkwcdtjpldivelsvwdipstdypyecdyhrex` (`dateDeleted`),
  KEY `idx_rrrjthtupkccfhwuhbxesxnnsmgieioplpck` (`fieldLayoutId`),
  KEY `idx_xhotovqdxjwublpnjxcemljgzdynrastxxha` (`type`),
  KEY `idx_hosgfevflznmcwuigslocvpncuiyiuxrsyig` (`enabled`),
  KEY `idx_iwqdfglvxqgcydppyvmxfmcygqzkyulrqkpv` (`canonicalId`),
  KEY `idx_vxjpeprvycdbonjdwxvkrdyaaczsqnuvhcde` (`archived`,`dateCreated`),
  KEY `idx_uqprtsmczgxnkswsjfsiyceqazameeiurrgb` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_tshzmtssqwkuwsilxkiiptwgbbqbiqzfvlcw` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_rsfmvwebliduejvzppizhyjyalrjrsfibcfb` (`draftId`),
  KEY `fk_cdjoyayfdojstynbuvurrmxxccenkpxuvwje` (`revisionId`),
  CONSTRAINT `fk_aksyectwgxczmjhznqbfmkligtqhmioybnex` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cdjoyayfdojstynbuvurrmxxccenkpxuvwje` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rsfmvwebliduejvzppizhyjyalrjrsfibcfb` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zzbhjabzzuqmvezmeieuifckqpivseebnbsz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-06-01 00:08:08','2024-06-01 00:21:53',NULL,NULL,NULL,'bf02866b-4da7-4102-9950-c6ef0c9cc0d9'),(2,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,NULL,NULL,'92f8810b-497e-44bc-9f8a-17f1028298ff'),(3,2,NULL,1,3,'craft\\elements\\Entry',1,0,'2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,NULL,NULL,'4a4e54e1-0e3f-435f-9624-f8b5c2aa5017'),(4,NULL,NULL,NULL,4,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:18:03','2024-06-03 17:18:03',NULL,NULL,NULL,'41ba029c-5560-4889-b020-cbff500e9bdd'),(5,NULL,NULL,NULL,5,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:18:51','2024-06-03 19:44:24',NULL,NULL,NULL,'7073c177-69ef-4762-8e87-a215481a3504'),(6,NULL,NULL,NULL,6,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:19:21','2024-06-03 17:20:34',NULL,NULL,NULL,'e71097ea-8036-4ab5-8637-e9dca0771aad');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_hdjuptxqrapzyctmdgsicmpbthvwsoahdrhy` (`timestamp`),
  CONSTRAINT `fk_hwrxnmaovmnnohbvazgossendaislhgcdpli` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_gxrcjywlmdkblxczuuwmcawsimykaubpgczw` (`ownerId`),
  CONSTRAINT `fk_gxrcjywlmdkblxczuuwmcawsimykaubpgczw` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_osfdhibfcttkxkavvqctekoqiwobpffvkwgm` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mytdkgcibiubohfyclhjwfzrhalimrigdkew` (`elementId`,`siteId`),
  KEY `idx_lylhyeydbbpqijkiagmztxssranoblmpvgmm` (`siteId`),
  KEY `idx_hvxsxlwjfhswxqlfhwbihkciuwydudkidade` (`title`,`siteId`),
  KEY `idx_vtmgkjxgtwqspsspdcfhgmnthxvtqofrunzl` (`slug`,`siteId`),
  KEY `idx_djfepcactcccshidyfdjbaiobtupmoqzotem` (`enabled`),
  KEY `idx_jbfnlkfugkpunwmegaohmfomxzhsvcfgniwp` (`uri`,`siteId`),
  CONSTRAINT `fk_hgzahndzysacatnuvgwrisowxaskudussyti` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oebimdjpemfzokfrhkvhwzzkzdpbhuqqhtld` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-06-01 00:08:08','2024-06-01 00:08:08','50b8b55a-a87a-4904-8432-9f40024e2592'),(2,2,1,'Home Page','home-page','__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','d6c7d674-5d4d-4771-83b0-ff8b301de9d0'),(3,3,1,'Home Page','home-page','__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','fc4a0d1a-6c55-40ff-bc71-240613c21c3c'),(4,4,1,NULL,NULL,NULL,'{\"c41cd145-6819-4d6d-b827-ddfe9e14f813\": \"all\"}',1,'2024-06-03 17:18:03','2024-06-03 17:18:03','3a2cdae7-3523-4aeb-8f4b-b3621fb5e8cb'),(5,5,1,NULL,NULL,NULL,NULL,1,'2024-06-03 17:18:51','2024-06-03 17:18:51','a72ffa01-03ad-4ffa-a216-bf25ee8c09f4'),(6,6,1,NULL,NULL,NULL,'{\"06fb32a9-2c98-48a8-a45b-97e613b191c0\": [{\"col1\": \"pageWidth\", \"col2\": \"1150\"}, {\"col1\": \"contentWidth\", \"col2\": \"940\"}, {\"col1\": \"sidebarWidth\", \"col2\": \"212\"}]}',1,'2024-06-03 17:19:21','2024-06-03 17:20:34','8df14bed-ea63-4541-82cf-cfe3d7beb6a6');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vtobcdijnjwulyvtwnytnmyjtkifiubcjtnx` (`postDate`),
  KEY `idx_yuhcswvacgkleobbtoikhrvvfklqirnziezk` (`expiryDate`),
  KEY `idx_bjxmkcfurmrglrgghdddihmnobgkpdrpsuta` (`sectionId`),
  KEY `idx_wfppxigpjssdzouhffpeqnlhsfwwlupjkwci` (`typeId`),
  KEY `idx_efpfitqukwkfwfeidzjvrxilpcyspvyozfos` (`primaryOwnerId`),
  KEY `idx_pexyannqnsnvlnhmcnluhmuoaszwdfwyrahm` (`fieldId`),
  KEY `fk_pwylaichxdadgroaczjgvzduynkdjgndeccg` (`parentId`),
  CONSTRAINT `fk_fomgswfnulqcdtiqtrtxsywzqnrbvjkgjjqo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_imserzhryubnflsyomvkzzptikcynsqrbklq` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pwylaichxdadgroaczjgvzduynkdjgndeccg` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qlefgpkhrymttpfpgloruipmtfqwzljanlbf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qsyuktsrhvwwpgkgmbvuddyhwbohejdecqda` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vczszmzyddktfwedpujalnvogwenzczcfpdq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-06-01 19:17:00',NULL,NULL,'2024-06-01 19:17:24','2024-06-01 19:17:24'),(3,1,NULL,NULL,NULL,1,'2024-06-01 19:17:00',NULL,NULL,'2024-06-01 19:17:24','2024-06-01 19:17:24');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_zyqrxtnhpzqozzhwfatsiqbaccillnstyito` (`authorId`),
  KEY `idx_iyvmuxikghsjkrjyymhwdpwizygoxakawvaa` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_wcxubitnwxhmrcnxsfvgpaafnqhecspovnmd` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wyannemjivtuwjgghwnfczfwotsrdjgrbppn` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fwkxfiegmhlrwabjfffjhphtccfsqqezrhle` (`fieldLayoutId`),
  KEY `idx_ryjksafnoskqlhtiungufztheetjfrvkhpus` (`dateDeleted`),
  CONSTRAINT `fk_wwvuoevhgtwuuqhprjfjbwqgqhhrijyullec` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,3,'Home Page','home','house',NULL,0,'site',NULL,'{section.name|raw}',0,'site',NULL,0,'2024-06-01 19:16:39','2024-06-01 19:16:39',NULL,'0ed79961-f5ad-4469-bd11-abcf7a9afd71'),(2,7,'Default Page','defaultPage','memo','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:23:29','2024-06-03 17:23:45',NULL,'c678a4d3-15e8-4ea1-86d7-9b5206b7359e'),(3,8,'Index Page','indexPage','list','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:25:48','2024-06-03 17:25:48',NULL,'7c32c045-0976-46d4-a6cb-9748ae189379'),(4,9,'Page Redirect','pageRedirect','arrows-rotate','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:26:59','2024-06-03 17:26:59',NULL,'39b18b62-f3cf-48e0-8827-95bb425853de');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ofebnaccaptplbcbmtfoqsymdjrknmkpzofq` (`dateDeleted`),
  KEY `idx_llkbalyatrocqocmmjmkjximzroabinhutaq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"f4e8e41b-3883-4d91-a7e4-1e0057072979\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"96e73468-e88d-4aaa-a07d-aeb7f9b1e8c7\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"3dec9884-fd99-49be-9df8-bde363c3a5ab\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fbc6e983-4336-4480-89fa-9084069c848c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:07:11','2024-06-01 19:12:52',NULL,'d95657ce-d0d3-4b7a-aa1f-47da27680636'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"ecb7d8c4-c296-427c-a2e9-af437c8edf5c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"57df7f4e-80db-413d-9a93-3d27f6b21e2d\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"d101e18f-d572-46ff-92d1-c5f8f7272b59\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5ccb7ad3-87b2-4106-946c-43f35b45b73b\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:12:31','2024-06-01 19:12:31',NULL,'19be8d25-1ea4-4715-a912-c7b518f8af29'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bb924369-6130-4e46-9d71-8c9cdebfd397\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b6c29a05-dbe3-4e10-baec-1621b25d687c\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:16:39','2024-06-01 19:16:39',NULL,'ddfb89b0-1589-4959-8e98-d2c7b81aaebf'),(4,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"9ef2366e-542c-40cc-a3f4-4eee419142c6\", \"name\": \"Site SEO\", \"elements\": [{\"tip\": null, \"uid\": \"a1e70cc1-3f73-4944-871c-26a69529c0ac\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"0b9fb8ec-a4b4-4921-9c50-fd4b135ef2c1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"605d136e-a57c-46fa-8bc7-7e700a8a6ee8\", \"name\": \"Technical SEO\", \"elements\": [{\"tip\": null, \"uid\": \"bfa35e87-c45b-4b39-ac22-6dec8a4cf772\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7ab49e1d-8c4e-4b01-b832-02d8c69746ef\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c41cd145-6819-4d6d-b827-ddfe9e14f813\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:18:03','2024-06-03 17:18:03',NULL,'8e48703c-752a-4eb7-8296-9948ee96e88f'),(5,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"3aa11335-95bb-45ed-aa78-fa3f3b364186\", \"name\": \"Navigation\", \"elements\": [{\"tip\": null, \"uid\": \"0b185442-deae-4531-804f-66be9f89ddcd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e64a9101-f277-49ae-8a14-3b3d9d77d8e3\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"6dade7bd-d1ae-4b9f-9e39-afc7c7cee0ab\", \"name\": \"Social Media\", \"elements\": [{\"tip\": null, \"uid\": \"a3b5eb47-2bb7-4145-aef0-2ed1ccd678af\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"105168a3-16f3-4b59-94dd-8ee954442a3e\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6bbe5cb3-b44e-4193-87cf-df55bde45db1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5410b80a-d2c8-4d87-bce0-7e047145966d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:18:51','2024-06-03 19:44:24',NULL,'5188c82f-e10c-48f8-8f78-cf5a182befed'),(6,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"5b03ec01-a79e-4143-b5a1-0027c0d18e6a\", \"name\": \"Settings\", \"elements\": [{\"tip\": null, \"uid\": \"06fb32a9-2c98-48a8-a45b-97e613b191c0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"052856f0-029e-4ecc-991b-f81833a59830\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:19:21','2024-06-03 17:19:21',NULL,'fe2036df-60f1-4282-9924-367184aa578e'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"afb666e8-faf6-44cd-84b9-4614053973fb\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"53e782d5-1589-4eef-971b-e7a79366df33\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"3e41ff08-5719-4097-aa9e-d4c3a8268ed8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"601c952a-0f95-412d-82d8-238aa80b0da6\", \"name\": \"Settings\", \"elements\": [{\"tip\": null, \"uid\": \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f7e7cbc6-dbf6-4e59-9430-a7728d67524d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"f5a163a9-f06c-4693-a109-eb4d0d343bbb\", \"name\": \"SEO\", \"elements\": [{\"tip\": null, \"uid\": \"ae9d5244-7717-481b-8186-55347020a03f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"83694166-ca67-4e8e-ac13-c5f9cab067bb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"a0dc1d7a-907b-4847-95cc-b2904523aca6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:23:29','2024-06-03 17:23:45',NULL,'e899e415-7240-4604-9eee-f2e13d904cf1'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b8c8b803-6d27-479c-9c86-bb1e72980a97\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"380e9145-1057-4ab4-af19-8fc1e14729f4\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"ee17bf72-cb79-4f5e-b69f-759cd76c410a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3284bdd5-e0be-4e3e-bc85-ceec41d39ff6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f8b138be-9608-4b14-91eb-d59aa08a08c4\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"612e4c86-ec48-454e-850a-c18fdad32d29\", \"name\": \"SEO\", \"elements\": [{\"tip\": null, \"uid\": \"f2ed8621-590e-46a4-8f2c-e2b7474e8fbd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"062ecb07-e4e4-47b1-bb1a-efa6804fba22\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"cc63830f-0573-4479-97a2-3ffc74e0baf4\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"89ca2926-2ebf-4689-9fac-a603b9a43272\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:25:48','2024-06-03 17:25:48',NULL,'637041b3-51c9-40b8-b376-0cd68ccf1c52'),(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"76130222-c605-495f-9479-62494df13443\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c13e5054-6b16-4c50-843b-42e34b26b633\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"0fe8496a-4fa5-4bc4-994a-f11493f1c911\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:26:59','2024-06-03 17:26:59',NULL,'70209356-2464-4ee7-9bc0-dcdb0fdad870');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ajtayeejxdfhxmivmksvvjskicshnorppxap` (`handle`,`context`),
  KEY `idx_lxkjzazgoetwrcconjsxfhezeodwoneidbzi` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Alternative Text','alternativeText','global',NULL,'This text is used within an HTML code to describe the appearance and function of an image on a page.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-01 19:11:12','2024-06-01 19:11:12','fbc6e983-4336-4480-89fa-9084069c848c'),(2,'Asset Description','assetDescription','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-01 19:11:47','2024-06-01 19:11:47','5ccb7ad3-87b2-4106-946c-43f35b45b73b'),(3,'Caption','caption','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:00:34','2024-06-03 17:00:34','799d449a-60ab-4566-87a2-badf0de0c1ec'),(4,'Carousel Interval','carouselInterval','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":10,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":null,\"suffix\":null}','2024-06-03 17:01:21','2024-06-03 17:01:21','a290cd19-1afc-4081-b7a5-d4f57e022734'),(5,'Facebook Handle','facebookHandle','global',NULL,'Your Facebook company/fan page handle (the part after https://www.facebook.com/)',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:02:08','2024-06-03 17:02:08','5410b80a-d2c8-4d87-bce0-7e047145966d'),(6,'Google Analytics Tracking ID','analyticsId','global',NULL,'If you enter your Google Analytics Tracking ID here, the Google Analytics script tags will be included in your <head> (the script is not included if devMode is on or during Live Preview). Only enter the ID, e.g.: UA-XXXXXX-XX, not the entire script code. [Here\'s how to get it](https://support.google.com/analytics/answer/1032385?hl=en).',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":15,\"code\":true,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:04:37','2024-06-03 17:04:37','7ab49e1d-8c4e-4b01-b832-02d8c69746ef'),(7,'Hide Sidebar','hideSidebar','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2024-06-03 17:05:16','2024-06-03 17:05:16','f7e7cbc6-dbf6-4e59-9430-a7728d67524d'),(8,'Page Heading','pageHeading','global',NULL,'Specify a main heading for the page. The **Page Title** will be used by default if you leave this empty.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Leave empty if same as Page Title\",\"uiMode\":\"normal\"}','2024-06-03 17:06:01','2024-06-03 17:06:01','9ba82f61-ac54-4bfe-827b-e506e0d79ff6'),(9,'Redirect Status Code','redirectStatusCode','global',NULL,NULL,0,'none',NULL,'craft\\fields\\RadioButtons','{\"options\":[{\"label\":\"Permanent Redirect (301)\",\"value\":\"301\",\"default\":\"1\"},{\"label\":\"Temporary Redirect (302)\",\"value\":\"302\",\"default\":\"\"}]}','2024-06-03 17:08:00','2024-06-03 17:08:00','2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9'),(10,'Section Template Folder','sectionTemplateFolder','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:08:44','2024-06-03 17:08:44','f8b138be-9608-4b14-91eb-d59aa08a08c4'),(11,'SEO Description','seoDescription','global',NULL,'The SEO Description should be between 70 and 160 characters (spaces included). Meta descriptions allow you to influence how your web pages are described and displayed in search results. Ensure that all of your web pages have a unique meta description that is explicit and contains your most important keywords.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":160,\"code\":false,\"initialRows\":3,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:09:23','2024-06-03 17:09:23','767e7a13-0040-4850-ab89-81ebe26655fc'),(12,'SEO Image','seoImage','global',NULL,'The image that should be used to represent this page',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":0,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Select an image\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-06-03 17:11:41','2024-06-03 17:11:41','c425ab9e-58a3-470e-92eb-b2accecd2325'),(13,'SEO Robots','seoRobots','global',NULL,'Tell the search engine crawlers what you want them to do with this page.',0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Indexing is allowed\",\"value\":\"all\",\"default\":\"1\"},{\"label\":\"Indexing is NOT allowed\",\"value\":\"noindex, nofollow\",\"default\":\"\"}]}','2024-06-03 17:12:28','2024-06-03 17:12:28','62acfd63-f994-4bfc-b9a4-bf043f8772c5'),(14,'SEO Title','seoTitle','global',NULL,'The SEO Title should be between 10 and 70 characters (spaces included). Make sure your title tag is explicit and contains your most important keywords. Be sure that each page has a unique title tag. The siteSeoName length is subtracted from the 70 character limit automatically, since it is appended to the seoTitle.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":70,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:13:02','2024-06-03 17:13:02','fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c'),(16,'Theme Settings','themeSettings','global',NULL,'Adjust the **Theme Level Settings** that control some of the content related functionality.',0,'none',NULL,'craft\\fields\\Table','{\"addRowLabel\":\"Add a setting\",\"columns\":{\"col1\":{\"heading\":\"Setting\",\"handle\":\"setting\",\"width\":\"\",\"type\":\"singleline\"},\"col2\":{\"heading\":\"Value\",\"handle\":\"value\",\"width\":\"\",\"type\":\"singleline\"}},\"defaults\":[{\"col1\":\"\",\"col2\":\"\"}],\"maxRows\":null,\"minRows\":null,\"staticRows\":false}','2024-06-03 17:15:01','2024-06-03 17:15:01','052856f0-029e-4ecc-991b-f81833a59830'),(17,'Twitter Handle','twitterHandle','global',NULL,'Your Twitter Handle, without the preceding @ This must be set for Twitter Card tags to be generated.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":true,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:15:34','2024-06-03 17:15:34','105168a3-16f3-4b59-94dd-8ee954442a3e'),(18,'Main Navigation','mainNavigation','global',NULL,'Select the entries that should appear in main navigation',0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":true,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:8f8af384-0f07-4623-8f6d-c54bde2fa965\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-06-03 19:43:29','2024-06-03 19:43:29','e64a9101-f277-49ae-8a14-3b3d9d77d8e3');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_inplzulgrhivetbugkzsvdmhmpbdjjrsombn` (`name`),
  KEY `idx_eckpvmcsigmeptusdzblqixervsvsohdnpyc` (`handle`),
  KEY `idx_qylxbphvmwoynxatamibqagaozdwjpcxwhcc` (`fieldLayoutId`),
  KEY `idx_wdrquybixzwtxebmycotoorihmszgsyimgrv` (`sortOrder`),
  CONSTRAINT `fk_dzfrztnjuzgglaxdzdjvkvnjmadrpmxmempd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rozuljjesohieabhkyuvfczjcwgupvvdwxri` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
INSERT INTO `globalsets` VALUES (4,'SEO Settings','seoSettings',4,1,'2024-06-03 17:18:03','2024-06-03 17:18:03','af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c'),(5,'Site Options','siteOptions',5,2,'2024-06-03 17:18:51','2024-06-03 17:18:51','7073c177-69ef-4762-8e87-a215481a3504'),(6,'Site Settings','siteSettings',6,3,'2024-06-03 17:19:21','2024-06-03 17:19:21','e71097ea-8036-4ab5-8637-e9dca0771aad');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jwcylsfmwhssihqpqvvsuxwroibmdmuroebq` (`accessToken`),
  UNIQUE KEY `idx_yzeggkqulvtuuolxvtpnxusoqipnjdwvdpmf` (`name`),
  KEY `fk_uifdzuaqsyddwddunayghigfwzjjeftmexmr` (`schemaId`),
  CONSTRAINT `fk_uifdzuaqsyddwddunayghigfwzjjeftmexmr` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dyzzrspkrcvnrxaoorssehrvodjkvslmeede` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vyjzuvazemhewpsjcasauxbkneuaolorrydj` (`name`),
  KEY `idx_yrrkzkvzhdvcewwfqupmqwvlfxbljpsyyjnl` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.1.7','5.0.0.20',0,'smuvjpfnfjqn','3@wvrqhvsckc','2024-06-01 00:08:08','2024-06-03 19:44:24','35f38d0d-8bed-4fa8-a3f3-17d1d72c2f49');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qnnlcebqfbywtpmfyksbwnwubkaolrnnfgpn` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3da0ee80-385f-4409-af55-a3737df59820'),(2,'craft','m221101_115859_create_entries_authors_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','d67571d8-b5d8-4a1d-8e4a-a9769396f0ae'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','332414e7-74af-4dc8-a8c4-902ab25799de'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','91623637-062f-44c4-aeec-ece921a42eac'),(5,'craft','m230314_110309_add_authenticator_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','14737193-d93a-4756-ad69-0a81fb12af1d'),(6,'craft','m230314_111234_add_webauthn_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','e7dc86d2-93bb-43b4-bcad-6db4f33e142a'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3b44309e-fed1-400c-9482-53a148d43302'),(8,'craft','m230511_000000_field_layout_configs','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','8d2ec236-cfe0-4977-9cde-892a6668207f'),(9,'craft','m230511_215903_content_refactor','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','58782faf-f359-45c5-8524-47cf5349c6d3'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','56ada16c-f51e-42c8-a131-ce7fe94f4265'),(11,'craft','m230524_000001_entry_type_icons','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','acaee37a-9291-4bd5-a9f8-0db021137666'),(12,'craft','m230524_000002_entry_type_colors','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','88e4d7e2-70b3-463a-9a1c-6a6efef5f5bb'),(13,'craft','m230524_220029_global_entry_types','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','d18401ae-f904-4fdc-be6e-0535c1d8d51a'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','24fb405d-0495-43a4-9fea-ea9b29ea3f83'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','caa21ab9-d348-44da-90bc-d969bcd7b55f'),(16,'craft','m230616_173810_kill_field_groups','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','dbe5c73e-ffe3-4cb5-b39a-986c75b64fcc'),(17,'craft','m230616_183820_remove_field_name_limit','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','9a33a87c-f791-4aaf-81a9-0675ce7d7208'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','9d7ca8fd-b25e-40be-a71e-e4729cf663c5'),(19,'craft','m230710_162700_element_activity','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','4d998b19-16b6-496f-8d0a-503e1337d59a'),(20,'craft','m230820_162023_fix_cache_id_type','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','05fc0f91-fb7b-4e61-a163-43a3f0ab3e9d'),(21,'craft','m230826_094050_fix_session_id_type','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','566ea00b-8999-47a7-8bc4-d1b39b263de9'),(22,'craft','m230904_190356_address_fields','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','08a23ea9-30bf-4b4c-a233-da4dc91343fe'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','bbfedafe-fd33-499c-8f19-fe786c7a7232'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','018ea963-45b1-4cf8-b198-89f553699611'),(25,'craft','m231213_030600_element_bulk_ops','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','a5aff2ce-2558-4c79-8f6d-408aa9869749'),(26,'craft','m240129_150719_sites_language_amend_length','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','c9295327-d08a-4505-afd4-c060a57a913f'),(27,'craft','m240206_035135_convert_json_columns','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','02a75551-bdd6-418a-b0c0-ad1c87121a0b'),(28,'craft','m240207_182452_address_line_3','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','86ed34d9-5699-4475-8dcc-d50c2a9827bc'),(29,'craft','m240302_212719_solo_preview_targets','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3fada93f-8be7-48de-a6e5-b9800d19a174'),(30,'plugin:aws-s3','Install','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','c5d7dd96-c02a-4483-8166-4288f1f719d5'),(31,'plugin:aws-s3','m220119_204627_update_fs_configs','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','2c1e015b-6a7c-408f-8432-6b911898c73c');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yumkmehegzqaijchhtieuioutonmgaqlbyaw` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'aws-s3','2.2.1','2.0','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','1f16a223-2339-4096-8866-bf5a4c285e6d');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1717443864'),('email.fromEmail','\"do-not-reply@nlcnet.net\"'),('email.fromName','\"Tungsten Craft CMS\"'),('email.replyToEmail','null'),('email.template','\"\"'),('email.transportSettings.host','\"smtp.mailtrap.io\"'),('email.transportSettings.password','\"d71536ab6f53c0\"'),('email.transportSettings.port','\"25\"'),('email.transportSettings.useAuthentication','\"1\"'),('email.transportSettings.username','\"4842f51c3d4591\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Smtp\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.color','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elementCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocapitalize','true'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocomplete','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocorrect','true'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.class','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.disabled','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.elementCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.id','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.includeInCards','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.inputType','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.instructions','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.label','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.max','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.min','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.name','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.orientation','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.placeholder','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.providesThumbs','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.readonly','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.requirable','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.size','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.step','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.tip','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.title','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.uid','\"b6c29a05-dbe3-4e10-baec-1621b25d687c\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.userCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.warning','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.width','100'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.name','\"Content\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.uid','\"bb924369-6130-4e46-9d71-8c9cdebfd397\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.userCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.handle','\"home\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.hasTitleField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.icon','\"house\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.name','\"Home Page\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.showSlugField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.showStatusField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.slugTranslationKeyFormat','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.slugTranslationMethod','\"site\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleFormat','\"{section.name|raw}\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleTranslationKeyFormat','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleTranslationMethod','\"site\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.color','\"orange\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocapitalize','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocomplete','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocorrect','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.class','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.disabled','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.id','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.includeInCards','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.inputType','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.instructions','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.label','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.max','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.min','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.name','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.orientation','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.placeholder','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.providesThumbs','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.readonly','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.requirable','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.size','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.step','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.tip','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.title','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.uid','\"c13e5054-6b16-4c50-843b-42e34b26b633\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.warning','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.width','100'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.fieldUid','\"2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.handle','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.includeInCards','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.instructions','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.label','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.providesThumbs','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.required','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.tip','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.uid','\"0fe8496a-4fa5-4bc4-994a-f11493f1c911\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.warning','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.width','100'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.name','\"Content\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.uid','\"76130222-c605-495f-9479-62494df13443\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.handle','\"pageRedirect\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.hasTitleField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.icon','\"arrows-rotate\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.name','\"Page Redirect\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.showSlugField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.showStatusField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.slugTranslationKeyFormat','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.slugTranslationMethod','\"site\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleFormat','\"\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleTranslationKeyFormat','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleTranslationMethod','\"site\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.color','\"orange\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocomplete','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocorrect','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.class','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.disabled','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.id','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.inputType','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.max','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.min','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.name','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.orientation','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.placeholder','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.readonly','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.requirable','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.size','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.step','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.title','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.uid','\"380e9145-1057-4ab4-af19-8fc1e14729f4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.fieldUid','\"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.uid','\"ee17bf72-cb79-4f5e-b69f-759cd76c410a\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.fieldUid','\"f8b138be-9608-4b14-91eb-d59aa08a08c4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.uid','\"3284bdd5-e0be-4e3e-bc85-ceec41d39ff6\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.name','\"Content\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.uid','\"b8c8b803-6d27-479c-9c86-bb1e72980a97\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.fieldUid','\"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.uid','\"f2ed8621-590e-46a4-8f2c-e2b7474e8fbd\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.uid','\"062ecb07-e4e4-47b1-bb1a-efa6804fba22\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.uid','\"cc63830f-0573-4479-97a2-3ffc74e0baf4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.uid','\"89ca2926-2ebf-4689-9fac-a603b9a43272\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.name','\"SEO\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.uid','\"612e4c86-ec48-454e-850a-c18fdad32d29\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.handle','\"indexPage\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.hasTitleField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.icon','\"list\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.name','\"Index Page\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.showSlugField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.showStatusField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.slugTranslationKeyFormat','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.slugTranslationMethod','\"site\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleFormat','\"\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleTranslationKeyFormat','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleTranslationMethod','\"site\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.color','\"orange\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocomplete','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocorrect','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.class','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.disabled','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.id','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.inputType','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.max','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.min','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.name','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.orientation','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.placeholder','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.readonly','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.requirable','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.size','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.step','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.title','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.uid','\"53e782d5-1589-4eef-971b-e7a79366df33\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.fieldUid','\"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.uid','\"3e41ff08-5719-4097-aa9e-d4c3a8268ed8\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.name','\"Content\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.uid','\"afb666e8-faf6-44cd-84b9-4614053973fb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.fieldUid','\"f7e7cbc6-dbf6-4e59-9430-a7728d67524d\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.uid','\"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.name','\"Settings\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.uid','\"601c952a-0f95-412d-82d8-238aa80b0da6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.fieldUid','\"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.uid','\"ae9d5244-7717-481b-8186-55347020a03f\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.uid','\"83694166-ca67-4e8e-ac13-c5f9cab067bb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.uid','\"a0dc1d7a-907b-4847-95cc-b2904523aca6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.uid','\"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.name','\"SEO\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.uid','\"f5a163a9-f06c-4693-a109-eb4d0d343bbb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.handle','\"defaultPage\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.hasTitleField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.icon','\"memo\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.name','\"Default Page\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.showSlugField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.showStatusField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.slugTranslationKeyFormat','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.slugTranslationMethod','\"site\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleFormat','\"\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleTranslationKeyFormat','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleTranslationMethod','\"site\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.columnSuffix','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.handle','\"themeSettings\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.instructions','\"Adjust the **Theme Level Settings** that control some of the content related functionality.\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.name','\"Theme Settings\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.searchable','false'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.addRowLabel','\"Add a setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.0','\"col1\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.0.0','\"heading\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.0.1','\"Setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.1.0','\"handle\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.1.1','\"setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.2.0','\"width\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.3.0','\"type\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.3.1','\"singleline\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.0','\"col2\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.0.0','\"heading\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.0.1','\"Value\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.1.0','\"handle\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.1.1','\"value\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.2.0','\"width\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.2.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.3.0','\"type\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.3.1','\"singleline\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.0.0','\"col1\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.0.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.1.0','\"col2\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.1.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.maxRows','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.minRows','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.staticRows','false'),('fields.052856f0-029e-4ecc-991b-f81833a59830.translationKeyFormat','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.translationMethod','\"none\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.type','\"craft\\\\fields\\\\Table\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.columnSuffix','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.handle','\"twitterHandle\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.instructions','\"Your Twitter Handle, without the preceding @ This must be set for Twitter Card tags to be generated.\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.name','\"Twitter Handle\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.searchable','true'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.byteLimit','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.charLimit','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.code','true'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.initialRows','4'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.multiline','false'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.placeholder','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.uiMode','\"normal\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.translationKeyFormat','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.translationMethod','\"none\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.columnSuffix','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.handle','\"redirectStatusCode\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.instructions','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.name','\"Redirect Status Code\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.searchable','false'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.0.0','\"label\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.0.1','\"Permanent Redirect (301)\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.1.0','\"value\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.1.1','\"301\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.2.0','\"default\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.2.1','\"1\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.0.0','\"label\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.0.1','\"Temporary Redirect (302)\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.1.0','\"value\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.1.1','\"302\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.2.0','\"default\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.2.1','\"\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.translationKeyFormat','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.translationMethod','\"none\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.type','\"craft\\\\fields\\\\RadioButtons\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.columnSuffix','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.handle','\"facebookHandle\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.instructions','\"Your Facebook company/fan page handle (the part after https://www.facebook.com/)\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.name','\"Facebook Handle\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.searchable','true'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.byteLimit','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.charLimit','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.code','false'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.initialRows','4'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.multiline','false'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.placeholder','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.uiMode','\"normal\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.translationKeyFormat','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.translationMethod','\"none\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.type','\"craft\\\\fields\\\\PlainText\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.columnSuffix','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.handle','\"assetDescription\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.instructions','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.name','\"Asset Description\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.searchable','true'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.byteLimit','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.charLimit','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.code','false'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.initialRows','4'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.multiline','false'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.placeholder','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.uiMode','\"normal\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.translationKeyFormat','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.translationMethod','\"none\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.type','\"craft\\\\fields\\\\PlainText\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.columnSuffix','null'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.handle','\"seoRobots\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.instructions','\"Tell the search engine crawlers what you want them to do with this page.\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.name','\"SEO Robots\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.searchable','false'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.0.0','\"label\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.0.1','\"Indexing is allowed\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.1.0','\"value\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.1.1','\"all\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.2.0','\"default\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.2.1','\"1\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.0.0','\"label\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.0.1','\"Indexing is NOT allowed\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.1.0','\"value\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.1.1','\"noindex, nofollow\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.2.0','\"default\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.2.1','\"\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.translationKeyFormat','null'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.translationMethod','\"none\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.columnSuffix','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.handle','\"seoDescription\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.instructions','\"The SEO Description should be between 70 and 160 characters (spaces included). Meta descriptions allow you to influence how your web pages are described and displayed in search results. Ensure that all of your web pages have a unique meta description that is explicit and contains your most important keywords.\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.name','\"SEO Description\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.searchable','true'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.byteLimit','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.charLimit','160'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.code','false'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.initialRows','3'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.multiline','true'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.placeholder','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.uiMode','\"normal\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.translationKeyFormat','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.translationMethod','\"none\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.type','\"craft\\\\fields\\\\PlainText\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.columnSuffix','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.handle','\"caption\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.instructions','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.name','\"Caption\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.searchable','true'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.byteLimit','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.charLimit','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.code','false'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.initialRows','4'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.multiline','false'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.placeholder','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.uiMode','\"normal\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.translationKeyFormat','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.translationMethod','\"none\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.type','\"craft\\\\fields\\\\PlainText\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.columnSuffix','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.handle','\"analyticsId\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.instructions','\"If you enter your Google Analytics Tracking ID here, the Google Analytics script tags will be included in your <head> (the script is not included if devMode is on or during Live Preview). Only enter the ID, e.g.: UA-XXXXXX-XX, not the entire script code. [Here\'s how to get it](https://support.google.com/analytics/answer/1032385?hl=en).\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.name','\"Google Analytics Tracking ID\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.searchable','false'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.byteLimit','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.charLimit','15'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.code','true'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.initialRows','4'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.multiline','false'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.placeholder','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.uiMode','\"normal\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.translationKeyFormat','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.translationMethod','\"none\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.type','\"craft\\\\fields\\\\PlainText\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.columnSuffix','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.handle','\"pageHeading\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.instructions','\"Specify a main heading for the page. The **Page Title** will be used by default if you leave this empty.\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.name','\"Page Heading\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.searchable','true'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.byteLimit','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.charLimit','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.code','false'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.initialRows','4'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.multiline','false'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.placeholder','\"Leave empty if same as Page Title\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.uiMode','\"normal\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.translationKeyFormat','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.translationMethod','\"none\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.type','\"craft\\\\fields\\\\PlainText\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.columnSuffix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.handle','\"carouselInterval\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.instructions','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.name','\"Carousel Interval\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.searchable','false'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.decimals','0'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.defaultValue','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.max','10'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.min','0'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.prefix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.previewCurrency','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.previewFormat','\"decimal\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.size','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.suffix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.translationKeyFormat','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.translationMethod','\"none\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.type','\"craft\\\\fields\\\\Number\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.columnSuffix','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.handle','\"seoImage\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.instructions','\"The image that should be used to represent this page\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.name','\"SEO Image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.searchable','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowedKinds.0','\"image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowSelfRelations','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowSubfolders','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowUploads','true'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.branchLimit','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.defaultUploadLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.defaultUploadLocationSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.localizeRelations','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.maintainHierarchy','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.maxRelations','1'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.minRelations','0'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.previewMode','\"full\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedDefaultUploadSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedLocationSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictFiles','true'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictLocation','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.selectionLabel','\"Select an image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showCardsInGrid','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showSiteMenu','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showUnpermittedFiles','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showUnpermittedVolumes','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.sources.0','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.targetSiteId','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.validateRelatedElements','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.viewMode','\"large\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.translationKeyFormat','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.translationMethod','\"site\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.type','\"craft\\\\fields\\\\Assets\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.columnSuffix','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.handle','\"mainNavigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.instructions','\"Select the entries that should appear in main navigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.name','\"Main Navigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.searchable','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.allowSelfRelations','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.branchLimit','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.localizeRelations','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.maintainHierarchy','true'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.maxRelations','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.minRelations','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.selectionLabel','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.showCardsInGrid','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.showSiteMenu','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.sources.0','\"section:8f8af384-0f07-4623-8f6d-c54bde2fa965\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.targetSiteId','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.validateRelatedElements','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.viewMode','\"list\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.translationKeyFormat','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.translationMethod','\"site\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.type','\"craft\\\\fields\\\\Entries\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.columnSuffix','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.handle','\"hideSidebar\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.instructions','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.name','\"Hide Sidebar\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.searchable','false'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.default','false'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.offLabel','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.onLabel','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.translationKeyFormat','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.translationMethod','\"none\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.columnSuffix','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.handle','\"sectionTemplateFolder\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.instructions','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.name','\"Section Template Folder\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.searchable','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.byteLimit','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.charLimit','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.code','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.initialRows','4'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.multiline','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.placeholder','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.uiMode','\"normal\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.translationKeyFormat','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.translationMethod','\"none\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.columnSuffix','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.handle','\"alternativeText\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.instructions','\"This text is used within an HTML code to describe the appearance and function of an image on a page.\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.name','\"Alternative Text\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.searchable','true'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.byteLimit','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.charLimit','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.code','false'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.initialRows','4'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.multiline','false'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.placeholder','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.uiMode','\"normal\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.translationKeyFormat','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.translationMethod','\"none\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.columnSuffix','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.handle','\"seoTitle\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.instructions','\"The SEO Title should be between 10 and 70 characters (spaces included). Make sure your title tag is explicit and contains your most important keywords. Be sure that each page has a unique title tag. The siteSeoName length is subtracted from the 70 character limit automatically, since it is appended to the seoTitle.\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.name','\"SEO Title\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.searchable','true'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.byteLimit','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.charLimit','70'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.code','false'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.initialRows','4'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.multiline','false'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.placeholder','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.uiMode','\"normal\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.translationKeyFormat','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.translationMethod','\"none\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.type','\"craft\\\\fields\\\\PlainText\"'),('fs.nlcCraftSitesAssets.hasUrls','true'),('fs.nlcCraftSitesAssets.name','\"NLC Craft Sites Assets\"'),('fs.nlcCraftSitesAssets.settings.addSubfolderToRootUrl','true'),('fs.nlcCraftSitesAssets.settings.autoFocalPoint','false'),('fs.nlcCraftSitesAssets.settings.bucket','\"$S3_BUCKET\"'),('fs.nlcCraftSitesAssets.settings.bucketSelectionMode','\"manual\"'),('fs.nlcCraftSitesAssets.settings.cfDistributionId','\"$CLOUDFRONT_DISTRIBUTION_ID\"'),('fs.nlcCraftSitesAssets.settings.cfPrefix','\"$CLOUDFRONT_PATH_PREFIX\"'),('fs.nlcCraftSitesAssets.settings.expires','\"3 months\"'),('fs.nlcCraftSitesAssets.settings.keyId','\"$S3_API_KEY\"'),('fs.nlcCraftSitesAssets.settings.makeUploadsPublic','false'),('fs.nlcCraftSitesAssets.settings.region','\"$S3_REGION\"'),('fs.nlcCraftSitesAssets.settings.secret','\"$S3_SECRET\"'),('fs.nlcCraftSitesAssets.settings.storageClass','\"\"'),('fs.nlcCraftSitesAssets.settings.subfolder','\"craft5base\"'),('fs.nlcCraftSitesAssets.type','\"craft\\\\awss3\\\\Fs\"'),('fs.nlcCraftSitesAssets.url','\"$CLOUDFRONT_URL\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.fieldUid','\"e64a9101-f277-49ae-8a14-3b3d9d77d8e3\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.uid','\"0b185442-deae-4531-804f-66be9f89ddcd\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.name','\"Navigation\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.uid','\"3aa11335-95bb-45ed-aa78-fa3f3b364186\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.fieldUid','\"105168a3-16f3-4b59-94dd-8ee954442a3e\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.uid','\"a3b5eb47-2bb7-4145-aef0-2ed1ccd678af\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.fieldUid','\"5410b80a-d2c8-4d87-bce0-7e047145966d\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.uid','\"6bbe5cb3-b44e-4193-87cf-df55bde45db1\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.name','\"Social Media\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.uid','\"6dade7bd-d1ae-4b9f-9e39-afc7c7cee0ab\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.handle','\"siteOptions\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.name','\"Site Options\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.sortOrder','2'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.uid','\"a1e70cc1-3f73-4944-871c-26a69529c0ac\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.uid','\"0b9fb8ec-a4b4-4921-9c50-fd4b135ef2c1\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.name','\"Site SEO\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.uid','\"9ef2366e-542c-40cc-a3f4-4eee419142c6\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.fieldUid','\"7ab49e1d-8c4e-4b01-b832-02d8c69746ef\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.uid','\"bfa35e87-c45b-4b39-ac22-6dec8a4cf772\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.uid','\"c41cd145-6819-4d6d-b827-ddfe9e14f813\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.name','\"Technical SEO\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.uid','\"605d136e-a57c-46fa-8bc7-7e700a8a6ee8\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.handle','\"seoSettings\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.name','\"SEO Settings\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.sortOrder','1'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elementCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.elementCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.fieldUid','\"052856f0-029e-4ecc-991b-f81833a59830\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.handle','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.includeInCards','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.instructions','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.label','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.providesThumbs','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.required','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.tip','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.uid','\"06fb32a9-2c98-48a8-a45b-97e613b191c0\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.userCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.warning','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.width','100'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.name','\"Settings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.uid','\"5b03ec01-a79e-4143-b5a1-0027c0d18e6a\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.userCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.handle','\"siteSettings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.name','\"Site Settings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.sortOrder','3'),('meta.__names__.052856f0-029e-4ecc-991b-f81833a59830','\"Theme Settings\"'),('meta.__names__.0ed79961-f5ad-4469-bd11-abcf7a9afd71','\"Home Page\"'),('meta.__names__.105168a3-16f3-4b59-94dd-8ee954442a3e','\"Twitter Handle\"'),('meta.__names__.2451a2c9-f6e7-45ba-b21f-6ba54d9018d8','\"Craft5 Base\"'),('meta.__names__.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9','\"Redirect Status Code\"'),('meta.__names__.39b18b62-f3cf-48e0-8827-95bb425853de','\"Page Redirect\"'),('meta.__names__.5410b80a-d2c8-4d87-bce0-7e047145966d','\"Facebook Handle\"'),('meta.__names__.5ccb7ad3-87b2-4106-946c-43f35b45b73b','\"Asset Description\"'),('meta.__names__.62acfd63-f994-4bfc-b9a4-bf043f8772c5','\"SEO Robots\"'),('meta.__names__.7073c177-69ef-4762-8e87-a215481a3504','\"Site Options\"'),('meta.__names__.767e7a13-0040-4850-ab89-81ebe26655fc','\"SEO Description\"'),('meta.__names__.799d449a-60ab-4566-87a2-badf0de0c1ec','\"Caption\"'),('meta.__names__.7ab49e1d-8c4e-4b01-b832-02d8c69746ef','\"Google Analytics Tracking ID\"'),('meta.__names__.7c32c045-0976-46d4-a6cb-9748ae189379','\"Index Page\"'),('meta.__names__.8e0e1072-3f93-4df7-a31d-e4f06eb6277f','\"Documents\"'),('meta.__names__.8f8af384-0f07-4623-8f6d-c54bde2fa965','\"Pages\"'),('meta.__names__.9ba82f61-ac54-4bfe-827b-e506e0d79ff6','\"Page Heading\"'),('meta.__names__.a290cd19-1afc-4081-b7a5-d4f57e022734','\"Carousel Interval\"'),('meta.__names__.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c','\"SEO Settings\"'),('meta.__names__.c12539e4-fc26-48ee-a298-47488a5a82e0','\"Images\"'),('meta.__names__.c425ab9e-58a3-470e-92eb-b2accecd2325','\"SEO Image\"'),('meta.__names__.c678a4d3-15e8-4ea1-86d7-9b5206b7359e','\"Default Page\"'),('meta.__names__.da2ec3b8-94ce-485b-8f32-4db302708c47','\"Craft5 Base\"'),('meta.__names__.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0','\"Home Page\"'),('meta.__names__.e64a9101-f277-49ae-8a14-3b3d9d77d8e3','\"Main Navigation\"'),('meta.__names__.e71097ea-8036-4ab5-8637-e9dca0771aad','\"Site Settings\"'),('meta.__names__.f7e7cbc6-dbf6-4e59-9430-a7728d67524d','\"Hide Sidebar\"'),('meta.__names__.f8b138be-9608-4b14-91eb-d59aa08a08c4','\"Section Template Folder\"'),('meta.__names__.fbc6e983-4336-4480-89fa-9084069c848c','\"Alternative Text\"'),('meta.__names__.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c','\"SEO Title\"'),('plugins.aws-s3.edition','\"standard\"'),('plugins.aws-s3.enabled','true'),('plugins.aws-s3.schemaVersion','\"2.0\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.defaultPlacement','\"end\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.enableVersioning','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.0','\"c678a4d3-15e8-4ea1-86d7-9b5206b7359e\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.1','\"7c32c045-0976-46d4-a6cb-9748ae189379\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.2','\"39b18b62-f3cf-48e0-8827-95bb425853de\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.handle','\"pages\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.maxAuthors','1'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.name','\"Pages\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.propagationMethod','\"all\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.enabledByDefault','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.template','\"page\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.uriFormat','\"{parent.uri}/{slug}\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.structure.maxLevels','3'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.structure.uid','\"fbf7ee7a-3807-4243-ab6a-a0dc25108cac\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.type','\"structure\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.defaultPlacement','\"end\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.enableVersioning','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.entryTypes.0','\"0ed79961-f5ad-4469-bd11-abcf7a9afd71\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.handle','\"home\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.maxAuthors','1'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.name','\"Home Page\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.propagationMethod','\"all\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.enabledByDefault','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.template','null'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.uriFormat','\"__home__\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.type','\"single\"'),('siteGroups.2451a2c9-f6e7-45ba-b21f-6ba54d9018d8.name','\"Craft5 Base\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.handle','\"default\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.language','\"en-US\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.name','\"Craft5 Base\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.primary','true'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.siteGroup','\"2451a2c9-f6e7-45ba-b21f-6ba54d9018d8\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Craft5 Base\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/New_York\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.altTranslationKeyFormat','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.altTranslationMethod','\"none\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocapitalize','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocomplete','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocorrect','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.class','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.disabled','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.id','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.includeInCards','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.inputType','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.instructions','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.label','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.max','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.min','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.name','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.orientation','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.placeholder','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.providesThumbs','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.readonly','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.requirable','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.size','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.step','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.tip','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.title','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.uid','\"57df7f4e-80db-413d-9a93-3d27f6b21e2d\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.warning','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.width','100'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.fieldUid','\"5ccb7ad3-87b2-4106-946c-43f35b45b73b\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.handle','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.includeInCards','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.instructions','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.label','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.providesThumbs','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.required','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.tip','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.uid','\"d101e18f-d572-46ff-92d1-c5f8f7272b59\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.warning','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.width','100'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.name','\"Content\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.uid','\"ecb7d8c4-c296-427c-a2e9-af437c8edf5c\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fs','\"nlcCraftSitesAssets\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.handle','\"documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.name','\"Documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.sortOrder','2'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.subpath','\"documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.titleTranslationKeyFormat','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.titleTranslationMethod','\"site\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.transformFs','\"\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.transformSubpath','\"\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.altTranslationKeyFormat','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.altTranslationMethod','\"none\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocapitalize','true'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocomplete','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocorrect','true'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.class','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.disabled','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.id','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.includeInCards','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.inputType','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.instructions','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.label','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.max','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.min','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.name','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.orientation','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.placeholder','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.providesThumbs','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.readonly','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.requirable','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.size','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.step','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.tip','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.title','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.uid','\"96e73468-e88d-4aaa-a07d-aeb7f9b1e8c7\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.warning','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.width','100'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.fieldUid','\"fbc6e983-4336-4480-89fa-9084069c848c\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.handle','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.includeInCards','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.instructions','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.label','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.providesThumbs','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.required','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.tip','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.uid','\"3dec9884-fd99-49be-9df8-bde363c3a5ab\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.warning','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.width','100'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.name','\"Content\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.uid','\"f4e8e41b-3883-4d91-a7e4-1e0057072979\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fs','\"nlcCraftSitesAssets\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.handle','\"images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.name','\"Images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.sortOrder','1'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.subpath','\"images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.titleTranslationKeyFormat','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.titleTranslationMethod','\"site\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.transformFs','\"\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_gowkhsfnfrmcsfsjzqhgdbitqoufphwhermz` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_sviiodbecyiwcvskhnpgmboufucmsjlleeyg` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xkzphagjpxeeggmphtqawzdphikcjfggvutk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_cvygfrxmsrfbffokurasdmzzxlemwjniqcqi` (`sourceId`),
  KEY `idx_gujhiuggtdyccvccjrmzfcmwccizbzjxlmsm` (`targetId`),
  KEY `idx_bdymjhqylmyiqfjqpgwopkexihthgjibdqds` (`sourceSiteId`),
  CONSTRAINT `fk_bbqnhgqixsfjealphbgzenvkxjtwtuavfzga` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dyrjyutkpwwslquivmvllppifidfqzbxjyvk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgiklexjeaktryyygfajrumtjmqealysqpyp` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('12f73fab','@craft/web/assets/fileupload/dist'),('14ae1b3f','@craft/web/assets/clearcaches/dist'),('14b7db47','@craft/web/assets/feed/dist'),('1bb254ae','@craft/web/assets/velocity/dist'),('1e255619','@craft/web/assets/jquerypayment/dist'),('1e76897b','@craft/web/assets/jquerytouchevents/dist'),('227e8cc7','@craft/web/assets/picturefill/dist'),('29c631c7','@craft/web/assets/xregexp/dist'),('2ba2e603','@craft/web/assets/craftsupport/dist'),('32524f01','@craft/web/assets/prismjs/dist'),('37c2fbc4','@craft/web/assets/htmx/dist'),('38b66fe','@craft/web/assets/elementresizedetector/dist'),('3a0f480a','@craft/web/assets/dashboard/dist'),('412af86d','@craft/web/assets/editsection/dist'),('426c6dc7','@craft/web/assets/jqueryui/dist'),('47f3a47f','@craft/web/assets/plugins/dist'),('488bfdd1','@bower/jquery/dist'),('48c1ab7f','@craft/web/assets/timepicker/dist'),('4c0be6c3','@craft/web/assets/xregexp/dist'),('4d6be239','@craft/web/assets/elementresizedetector/dist'),('50960dbc','@craft/web/assets/jquerytouchevents/dist'),('50c5d2de','@craft/web/assets/jquerypayment/dist'),('5425a2da','@craft/web/assets/updates/dist'),('5a575f80','@craft/web/assets/feed/dist'),('5c17bb6c','@craft/web/assets/fileupload/dist'),('5ffd546c','@storage/rebrand/logo'),('66b7916','@bower/jquery/dist'),('6a5f5bf1','@craft/web/assets/vue/dist'),('6c9e0800','@craft/web/assets/picturefill/dist'),('6df4fd8c','@craft/web/assets/dashboard/dist'),('7c595385','@craft/web/assets/craftsupport/dist'),('7e7f83aa','@craft/web/assets/velocity/dist'),('85214451','@craft/web/assets/generalsettings/dist'),('8724e665','@craft/web/assets/iframeresizer/dist'),('8c0e100a','@craft/web/assets/updateswidget/dist'),('8c45efd2','@craft/web/assets/d3/dist'),('9248e3a8','@craft/web/assets/fabric/dist'),('9670c99b','@craft/web/assets/cp/dist'),('9a386bd3','@craft/web/assets/selectize/dist'),('9d2dd1f1','@craft/web/assets/tailwindreset/dist'),('9f0bf9e6','@craft/web/assets/pluginstore/dist'),('a1658e23','@craft/web/assets/tablesettings/dist'),('a9891971','@craft/web/assets/conditionbuilder/dist'),('aa41c73d','@craft/web/assets/axios/dist'),('ada1fb8','@craft/awss3/resources'),('b2b45264','@craft/web/assets/recententries/dist'),('b2fbe47c','@craft/web/assets/axios/dist'),('b6d2f546','@craft/icons/custom-icons'),('bafad4bf','@craft/web/assets/garnish/dist'),('bb77143b','@craft/web/assets/updater/dist'),('c18b7c1d','@craft/web/assets/cp/dist'),('c490676f','@storage/rebrand/icon'),('c8ce900','@craft/web/assets/jqueryui/dist'),('c9c462a2','@craft/web/assets/iframeresizer/dist'),('cc82f151','@craft/web/assets/utilities/dist'),('ceed271b','@craft/web/assets/userpermissions/dist'),('cfadb794','@craft/web/assets/fieldsettings/dist'),('d25a6372','@craft/web/assets/sites/dist'),('d7798560','@craft/web/assets/recententries/dist'),('dbbe5a54','@craft/web/assets/d3/dist'),('dca8676f','@craft/web/assets/fabric/dist'),('e5941387','@craft/web/assets/admintable/dist'),('e9c3c70e','@craft/web/assets/updateswidget/dist'),('ece99e46','@craft/icons/custom-icons'),('f41a5078','@craft/web/assets/garnish/dist'),('f8e006f5','@craft/web/assets/tailwindreset/dist'),('f928cf5','@craft/web/assets/vue/dist'),('fac62ee2','@craft/web/assets/pluginstore/dist'),('fd2e30c6','@craft/web/assets/admintable/dist'),('fff5bcd7','@craft/web/assets/selectize/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yoxucjvmqyyixrjvvwsvndomniohvuakkqxy` (`canonicalId`,`num`),
  KEY `fk_lxibizrrahufshoixzrrdplzztvxusufapab` (`creatorId`),
  CONSTRAINT `fk_abaqaskgnutfviuffxcqfecofdkoxcmpfuqb` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lxibizrrahufshoixzrrdplzztvxusufapab` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_iseayuktrwtzqtjbjncddqehpxdhmonmalid` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' info thenewline com '),(1,'firstname',0,1,' tungsten '),(1,'fullname',0,1,' tungsten admin '),(1,'lastname',0,1,' admin '),(1,'slug',0,1,''),(1,'username',0,1,' atomin '),(2,'slug',0,1,' home page '),(2,'title',0,1,' home page '),(4,'slug',0,1,''),(5,'slug',0,1,''),(6,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eiqykpvcjsnovllhfqjfipxdcusgbhvxcgmv` (`handle`),
  KEY `idx_nyneazlcijyglerhqekfwjytwmxcofnpyobm` (`name`),
  KEY `idx_uofadfyoljzwoagncqykrznhssorfpeasifq` (`structureId`),
  KEY `idx_gbklnpiympffwkydlbutaxbkycgygyusoepb` (`dateDeleted`),
  CONSTRAINT `fk_xgkdhjetuvohnnnapsjepgzqzqwawozatwqy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home Page','home','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,'e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0'),(2,1,'Pages','pages','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-03 17:28:16','2024-06-03 17:28:16',NULL,'8f8af384-0f07-4623-8f6d-c54bde2fa965');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_qzalxyaymrbanekcjmsywgteskfjpjhuwgsl` (`typeId`),
  CONSTRAINT `fk_oamkjunefiqlewkqksejcztensvtrdxspbpz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qzalxyaymrbanekcjmsywgteskfjpjhuwgsl` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1),(2,2,1),(2,3,2),(2,4,3);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ykbkifngzmhxegmyulgvbtmbjvdtmlmjkjeb` (`sectionId`,`siteId`),
  KEY `idx_tpmhngcursfoujvnochqpstdgnkopzmwegqd` (`siteId`),
  CONSTRAINT `fk_beprpvpmyksfxkegskanyooluswkqlttvmfd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nuwxnvvkdiookqjxbjuaoftolzvyhhlgazlx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','dd9fe0fb-3dc7-4051-aaff-b369ee9cb704'),(2,2,1,1,'{parent.uri}/{slug}','page',1,'2024-06-03 17:28:16','2024-06-03 17:28:16','daca6403-13b4-4f66-abd4-42eaa3f2e78d');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kwgsgfgojbdkpqtpozbrzvhettxxmlhrgfbh` (`uid`),
  KEY `idx_hbmobhrezudfofphfpzetnfvgzdemlqzwqpy` (`token`),
  KEY `idx_yvwibjkuozgcefyqlvmfybslaraungruzjsv` (`dateUpdated`),
  KEY `idx_mfqmncutnfafyziamqounrbujdolnowwpqmc` (`userId`),
  CONSTRAINT `fk_yyvuumhyaszhtvbmetbdudlnzbicuswazmui` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'IDmkV5ZM8sF5qmmTCv51rtDTbqzrFiUAWp12oNsMkn_350QcUVZ68fY3JwPnUVmkuSA6bSRqmBdS8FBquA99FV8Z2b4XpU3MNt_E','2024-06-01 00:08:54','2024-06-01 00:46:05','254584e5-bd01-41d3-a347-c78c247e003f'),(2,1,'KL-5wycD-H8FrGvimdJp6Jl0KEErB5pqh9KvvY1scOC0hon3VC-_cA5ughUPO3ZqkZE0GDdvt1z9IpNUYRPy5_0TgUeI4Pk2pKL_','2024-06-01 18:54:20','2024-06-01 19:54:01','c97345d9-b124-4e78-a44e-3e7889bfd16e'),(3,1,'uZ5Qmwi7MxnC90yFw7Myn1QOZdabwroeFIzuiC-dsYRsp_OHTSDGVsIZzA0s6roETwpEzpU-tYvD9vvEP96WQMAkw2NprtcI8mWw','2024-06-03 15:35:10','2024-06-03 17:59:27','04a1c095-24e0-4a84-88b7-3f4b0ecd72fa'),(4,1,'7Ch7JzS1TWmxlyQtHbTTOeGDrWZj427ZZn8XR5ufJYvTCcQWP22CCsfu8XgAw2OqDIRv2BSY-7mJBNHoMjju5-Og5YYTNOtH2cim','2024-06-03 19:38:15','2024-06-03 19:49:10','16a2f11b-87f9-4b48-a7df-0ab83f4e7571');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lilygbqtewjenqugfpcesiglwepiqycbmopg` (`userId`,`message`),
  CONSTRAINT `fk_raavtmsyxilbwxbpngxstculfzsyyrtdjllg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kbsdfujttridhkrtdvvqwapwtcnyfwxoxqnn` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Craft5 Base','2024-06-01 00:08:08','2024-06-01 00:08:08',NULL,'2451a2c9-f6e7-45ba-b21f-6ba54d9018d8');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uhqzzulmlziktmdjtzrfuficzvbbhkumxtai` (`dateDeleted`),
  KEY `idx_mseocoosxcjckquhegkronwzeoxqvpzmxvzi` (`handle`),
  KEY `idx_zyrrtrawqojzhnhljaprrjqbewokususpceu` (`sortOrder`),
  KEY `fk_ppwijlcyhosgvenwzhaeuhijzkkaelldmren` (`groupId`),
  CONSTRAINT `fk_ppwijlcyhosgvenwzhaeuhijzkkaelldmren` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Craft5 Base','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-06-01 00:08:08','2024-06-01 00:08:08',NULL,'da2ec3b8-94ce-485b-8f32-4db302708c47');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_docxezndixnkkxhglaijpiqxsxuexhbgdmgr` (`structureId`,`elementId`),
  KEY `idx_qrlikeponngibrrknkbhdiytsaeimyyuegkk` (`root`),
  KEY `idx_masearxatbhtmxybgdmjdvxspfathwywprmz` (`lft`),
  KEY `idx_zcyhzidjqrcvdbcjfviepspmpqeaqmnpuuuo` (`rgt`),
  KEY `idx_jaxbxjcwqwmboahsjgdcopukfmbmwxxokdiw` (`level`),
  KEY `idx_vntsxqtljpzsajeepjrxbcdkydjimvbowfjz` (`elementId`),
  CONSTRAINT `fk_rygdrsvnopexrovbucfgruuthkliatbjyslq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fyxmorvmtnferhgneqifdfbgdjdijxribkgg` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,3,'2024-06-03 17:28:16','2024-06-03 17:28:16',NULL,'fbf7ee7a-3807-4243-ab6a-a0dc25108cac');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ygysemeiiajolrqmjrnjfssnexugsyebflgl` (`key`,`language`),
  KEY `idx_zhonjvxzpissfqacybagkvbxhvbypdyivwls` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qyzathanlpsnndtsjxdpkozqszfphltlaykl` (`name`),
  KEY `idx_ejfbfzhvvquywvbkjymsopmprdccbvklnkvq` (`handle`),
  KEY `idx_nxgvbpudjnbtmrnvbekvpqhasfvswdaxmxfg` (`dateDeleted`),
  KEY `fk_tanrtegfjzqwkakklfxotvzzkugdelupveoh` (`fieldLayoutId`),
  CONSTRAINT `fk_tanrtegfjzqwkakklfxotvzzkugdelupveoh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_piduihbanwrgoppjhwcpxgvhbabudrelxtji` (`groupId`),
  CONSTRAINT `fk_kqcvprughnibjwjorsvnixizpcaanqnbiaop` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omvooueckeggauyavtoeexxyjtmwnguazdkx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rrugsjrhinpnptkqlksxiifhipsbyutxprti` (`token`),
  KEY `idx_prupsfcvdsvkidybnpiktvgzjqhpvypnztcp` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fuqfwxnocniicwatgcslfwwwtjjxrksxdsxp` (`handle`),
  KEY `idx_xgtvsnhxlwlrslccerhjnsfpsqyrocvgjrnu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_azhkwewwxzsgnhzvimcztvknmkcbkxiytyck` (`groupId`,`userId`),
  KEY `idx_vdvazggejwxsebbwezpenxdopbbtwdyvhakp` (`userId`),
  CONSTRAINT `fk_ofyrsnybwfhiiznuzbzvvixgmrzlyhucstmm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ustgnftjlqjxotdpoooxqombysyqnsojrfoj` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gfhljicrovfbcxhxzgcskebzzkroocwsxrav` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nflowltwwjzwmhiksugofjvjzwmcynubeuwj` (`permissionId`,`groupId`),
  KEY `idx_wspcukpiwllzfhpysyfuhgrpgxvzyoaxucpo` (`groupId`),
  CONSTRAINT `fk_gynatkiwyalzkppeoghitzeedbarcdzvjgqg` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rxpstcvvlunspvutidieqzgircbucfuhcuwa` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqquvnewxzlsnjzdtvemizqejqjmamkmxjlb` (`permissionId`,`userId`),
  KEY `idx_tngghyyzynqrzuizxzwtaytiklvcasmmparj` (`userId`),
  CONSTRAINT `fk_dgnzweeydtzvhqthzaoevkeciuehneziptni` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zzkztnopgbeoekrbywbbtekgqcebuhzbpqkq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_jomqubqcxplkwvwusehzurpvzflnzzzsxnsj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ursyoqujnsadqwqdpquqgflrvinbcydbbjrt` (`active`),
  KEY `idx_mxwdhjloosplxcywhbpfiphrxroqgzuszzbp` (`locked`),
  KEY `idx_onktqgfizdlnyodtkobyjfflibcptzkqzcgx` (`pending`),
  KEY `idx_jukmysuihodnoajmdgewoimjaqhaqflbhwfj` (`suspended`),
  KEY `idx_qsjpgfoycuqcreazlatvufvqellieipxagqa` (`verificationCode`),
  KEY `idx_vxkjyeihhsynlmfmumxxnmfpzpxahzrjazgm` (`email`),
  KEY `idx_lcgacbikjmcyclogvfucljpzyilfebtcoldm` (`username`),
  KEY `fk_nhsvrvzyzbyfinqgxymaftiehgerylqrxclh` (`photoId`),
  CONSTRAINT `fk_nhsvrvzyzbyfinqgxymaftiehgerylqrxclh` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rmiqocolprgwrthoghavoyrhbicwfdjwdqdv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'atomin','Tungsten Admin','Tungsten','Admin','info@thenewline.com','$2y$13$cr/jBliW34kf8ArdiagYgOw1h4ealtjFOCRm1amSRzJHvB/za0Nai','2024-06-03 19:38:15',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-03 19:38:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_novmnatnhvqjbofwapliddowrwmnhtfyagay` (`name`,`parentId`,`volumeId`),
  KEY `idx_hlrmygmvhmbwomuxmtthzsvuxosigteayjsl` (`parentId`),
  KEY `idx_fkkgswvsblmclepeugtcmggvjxxewqpufbwt` (`volumeId`),
  CONSTRAINT `fk_egiaoiykbjggtnjsanwrirrwjvacxiqbqanr` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wkshspceivictocpkajccrhfufnzaembxocg` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images',NULL,'2024-06-01 19:07:11','2024-06-01 19:08:28','37dd4b1c-0f0d-4d15-993d-e3d58797c906'),(2,NULL,2,'Documents','','2024-06-01 19:12:31','2024-06-01 19:12:31','b990489e-3ae5-48c9-af30-33244e8b563a'),(3,NULL,NULL,'Temporary Uploads',NULL,'2024-06-01 19:12:57','2024-06-01 19:12:57','66c1c1e1-03fd-43b6-a05f-9d793ef49e0b'),(4,3,NULL,'user_1','user_1/','2024-06-01 19:12:57','2024-06-01 19:12:57','515cc3f3-d70d-4686-9abc-0e51588b2298');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tisrboattoyomphxkguelfhtxrxycyhowsuu` (`name`),
  KEY `idx_eamnjjanuyywonmmydzuivsfijjedjzyiuic` (`handle`),
  KEY `idx_twwgsnstfcnxxqdwsmvacgxwnonikwaufgdf` (`fieldLayoutId`),
  KEY `idx_xejkavovnfkhebpftqrtfsjjpmjovplnackk` (`dateDeleted`),
  CONSTRAINT `fk_vkvtlcaxnxevljtdecuwobxrrvcfujkuycxi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,1,'Images','images','nlcCraftSitesAssets','images','','','site',NULL,'none',NULL,1,'2024-06-01 19:07:11','2024-06-01 19:08:28',NULL,'c12539e4-fc26-48ee-a298-47488a5a82e0'),(2,2,'Documents','documents','nlcCraftSitesAssets','documents','','','site',NULL,'none',NULL,2,'2024-06-01 19:12:31','2024-06-01 19:12:31',NULL,'8e0e1072-3f93-4df7-a31d-e4f06eb6277f');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ldykmldsaouffhhvvedgiffbbrioqqfpvirx` (`userId`),
  CONSTRAINT `fk_ldykmldsaouffhhvvedgiffbbrioqqfpvirx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_myhxwqparfkfiuzenwsrgdaxhbygjdenvzgu` (`userId`),
  CONSTRAINT `fk_cgyhecrplafrdnyuesjiycistgfxsvxsyvmr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-06-01 00:08:55','2024-06-01 00:08:55','09244fa2-1320-4f85-9ec6-de348337c12a');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 15:49:38
