-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: localhost    Database: craft_base
-- ------------------------------------------------------
-- Server version	8.0.36-2ubuntu3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sieavnegmdeakjjhfitalbyhnkcccuyqmzyz` (`primaryOwnerId`),
  CONSTRAINT `fk_lqvlybsoyveavwmryqpfpecahscytivnbfzw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sieavnegmdeakjjhfitalbyhnkcccuyqmzyz` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yqgsucbvgyuivuffmpgsusexkcpfidzlygez` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_azeexyjfytscepowioowtmwjfxaxafueqbvq` (`dateRead`),
  KEY `fk_szpqcksreylukinrzbjoufwaxopezseuxfbz` (`pluginId`),
  CONSTRAINT `fk_fnpjwmxrjgihbwnuewjngosvxnakrzzbsfjx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_szpqcksreylukinrzbjoufwaxopezseuxfbz` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mcjbaqboryhzcejwfwwofdlfgnzwukbtyzra` (`sessionId`,`volumeId`),
  KEY `idx_zkyfgnmyqwcaakkbhansucjfuczhzmylcbur` (`volumeId`),
  CONSTRAINT `fk_ciqcbnxrxjbdwwxudhhjgsoayelihxpusain` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_igdfbgmswfcakrqbfzwcxommvixrpwgnbgth` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bfbtlkugmqghxeuyrwvtjjqwsnklmmzxevdh` (`filename`,`folderId`),
  KEY `idx_wdlmetkavrsmbeqwrupinxwnehecqpnyvtna` (`folderId`),
  KEY `idx_kblpvnxbfcpxiesuxvrjkydsteufxrtdecuv` (`volumeId`),
  KEY `fk_wzuacgojebqshekjctqeugzdvvwjescalwsn` (`uploaderId`),
  CONSTRAINT `fk_cnoxfrjnecgunsponvbqeltpyypluhqvnhlg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tutcspwgrkwfwuxnaospmchzyltmaiukgtok` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wzuacgojebqshekjctqeugzdvvwjescalwsn` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xtekdpqsaxctsxxwghtkpkiyombxjszrupta` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (9,1,1,1,'Por-do-Sol-em-Baixa-Grande.jpg','image',NULL,1024,683,143872,NULL,NULL,NULL,'2024-06-03 21:16:01','2024-06-03 21:16:01','2024-06-03 21:16:01'),(40,2,2,1,'P-Fit-Seat-Quote-part-numbers-reference.pdf','pdf',NULL,NULL,NULL,198451,NULL,NULL,NULL,'2024-06-05 15:54:51','2024-06-05 15:54:52','2024-06-05 15:54:52'),(41,2,2,1,'P-Fit-Back-Quote-part-numbers-reference.pdf','pdf',NULL,NULL,NULL,249989,NULL,NULL,NULL,'2024-06-05 15:54:52','2024-06-05 15:54:53','2024-06-05 15:54:53'),(42,2,2,1,'P-Fit-Back-Quote.pdf','pdf',NULL,NULL,NULL,71561,NULL,NULL,NULL,'2024-06-05 15:54:53','2024-06-05 15:54:53','2024-06-05 15:54:53'),(43,2,2,1,'P-Fit-Seat-Quote.pdf','pdf',NULL,NULL,NULL,64724,NULL,NULL,NULL,'2024-06-05 15:54:54','2024-06-05 15:54:54','2024-06-05 15:54:54');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_zaypoeenfudpjhzvsjeijatqadrffphplvpi` (`siteId`),
  CONSTRAINT `fk_kjmzoekyaqefvizxwoqzqhucnhfxtkhdkimn` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zaypoeenfudpjhzvsjeijatqadrffphplvpi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (9,1,NULL),(40,1,NULL),(41,1,NULL),(42,1,NULL),(43,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_yzirstzfdydzwnsjoozoynsqqlwhmptnocpn` (`userId`),
  CONSTRAINT `fk_yzirstzfdydzwnsjoozoynsqqlwhmptnocpn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mewtmcgivznkpxfyrcgwwcgzsiycsyzjcnbq` (`groupId`),
  KEY `fk_pbddvylmydjrfqmgjjubnqijtnncidkiwlas` (`parentId`),
  CONSTRAINT `fk_ctnyhzjprbnxulutkewezszkzclprwsfgwux` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nfjoeaeosrostmjilxiouwdizqqpvdvqxjcr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pbddvylmydjrfqmgjjubnqijtnncidkiwlas` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gxzyckpnuuuprheiypecaubbhrnnbqafmbwg` (`name`),
  KEY `idx_zydnrnuibumrhseczbhfwezgzsfnzmtkemit` (`handle`),
  KEY `idx_uymzrpsazvpwlhfyrdeizsceymdymbhmohhi` (`structureId`),
  KEY `idx_bczlmxwggaeerfejstjmetjhrhxhxwasmycw` (`fieldLayoutId`),
  KEY `idx_kfzjzanytbguzuvjkgmsscccvjekhmtcqnqm` (`dateDeleted`),
  CONSTRAINT `fk_gzmkmbluzuyukjwntjzckkalucqbzcmzgzut` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kevbnvryatmublzsyksrsjciipmfjhkiwiec` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ocqrjyskycocwabmxzyzrlvedndgowehlpfl` (`groupId`,`siteId`),
  KEY `idx_qvmruggruxgkjmkxxtihfsgtwlihfnyuhxpw` (`siteId`),
  CONSTRAINT `fk_idxvxukwiphvqfffcacdahgeireejjjkuqmw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_iwslpzninzypgvnfalubdblmtfglagbqhode` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ytlihirokbxudbejysvenwgqtskykbkndmpz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_aqgnhcnjfbbmhwwvvazkdveqcbwrkwbanyqx` (`siteId`),
  KEY `fk_bkrxxizcycrcscgojrhlrnclsunchipizbfo` (`userId`),
  CONSTRAINT `fk_aqgnhcnjfbbmhwwvvazkdveqcbwrkwbanyqx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bkrxxizcycrcscgojrhlrnclsunchipizbfo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_jvjqxrqpwthcdugosjtzlqufpqslhqxdodue` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'firstName','2024-06-01 00:21:53',0,1),(1,1,'fullName','2024-06-01 00:21:53',0,1),(1,1,'lastName','2024-06-01 00:21:53',0,1),(7,1,'postDate','2024-06-03 21:17:17',0,1),(7,1,'slug','2024-06-03 21:14:31',0,1),(7,1,'title','2024-06-03 21:14:31',0,1),(7,1,'uri','2024-06-03 21:14:31',0,1),(8,1,'enabled','2024-06-04 18:01:13',0,1),(8,1,'postDate','2024-06-03 21:16:23',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_cyxomttfalvvwltgijkpbvzbdlzyebhsxbnu` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_mtqgflwbikumbwtdkxoxlqnnvqxlgbxpzqem` (`siteId`),
  KEY `fk_qrzglgourrzpjnllrrchadkbcxxqkfujkism` (`fieldId`),
  KEY `fk_vedfrxdbmfruxexlxgbxayvcavmrugtodhzh` (`userId`),
  CONSTRAINT `fk_axeiczhnqddkkqefldigvqrzhhfvllomxmuz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mtqgflwbikumbwtdkxoxlqnnvqxlgbxpzqem` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qrzglgourrzpjnllrrchadkbcxxqkfujkism` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vedfrxdbmfruxexlxgbxayvcavmrugtodhzh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (7,1,23,'439d8587-b447-424f-a2aa-55d41dfc7d03','2024-06-05 16:19:39',0,1),(8,1,3,'9154ca2e-cd14-47ce-93f7-597e1eaaac53','2024-06-04 17:56:27',0,1),(8,1,20,'6d02377d-9d38-46d1-84c4-07836f4bea30','2024-06-04 17:56:14',0,1),(8,1,21,'b40963cc-fb78-4a85-9703-9dcd08ed5d91','2024-06-04 17:56:14',0,1),(8,1,22,'cab8976e-d51f-4252-92cb-87790402a1cf','2024-06-03 21:16:07',0,1),(33,1,26,'c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73','2024-06-04 18:17:44',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_mnevhdutqtneasurohsftrdiptvvfuuhdgdv` (`userId`),
  CONSTRAINT `fk_mnevhdutqtneasurohsftrdiptvvfuuhdgdv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zgtufqofcyjykyryjnyltxpgczzqfxoleoye` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_yvckcjzcwyiveidfjdrsvskvtznywchsqosi` (`creatorId`,`provisional`),
  KEY `idx_dbvoeigaegpeflelxjupgwhqxkawjxhkkrrz` (`saved`),
  KEY `fk_rhsbsuncdxyeirjcbplfsxnuwbmeyblpydho` (`canonicalId`),
  CONSTRAINT `fk_rdfxtaobktbjzlrcxiugsjznpgcidegldmbw` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rhsbsuncdxyeirjcbplfsxnuwbmeyblpydho` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (16,NULL,1,0,'First draft',NULL,0,NULL,1),(17,NULL,1,0,'First draft',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_wrpnoziqydvkdncfswsxhlgxpuuadiierwiw` (`elementId`,`timestamp`,`userId`),
  KEY `fk_djeqkoupssrxbodurlrxykytxxiluujstsog` (`userId`),
  KEY `fk_ftgkmfabybipfndlahochccgwryowseiiifc` (`siteId`),
  KEY `fk_dxfqttbbgueagehggurzlcwoqivbetzginns` (`draftId`),
  CONSTRAINT `fk_djeqkoupssrxbodurlrxykytxxiluujstsog` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dxfqttbbgueagehggurzlcwoqivbetzginns` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ftgkmfabybipfndlahochccgwryowseiiifc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qbktyonnvsbqtcqjswkaffjisvgjccwhbotg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (1,1,1,NULL,'save','2024-06-01 00:21:53'),(1,1,1,NULL,'view','2024-06-05 14:11:51'),(2,1,1,NULL,'view','2024-06-01 19:48:10'),(7,1,1,NULL,'edit','2024-06-05 16:19:34'),(7,1,1,NULL,'save','2024-06-05 16:19:39'),(7,1,1,NULL,'view','2024-06-05 16:26:57'),(8,1,1,NULL,'edit','2024-06-04 18:01:11'),(8,1,1,NULL,'save','2024-06-04 18:01:13'),(8,1,1,NULL,'view','2024-06-04 17:55:28'),(9,1,1,NULL,'view','2024-06-05 15:11:12'),(33,1,1,NULL,'edit','2024-06-04 18:17:43'),(33,1,1,NULL,'save','2024-06-04 18:17:44');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yprkwcdtjpldivelsvwdipstdypyecdyhrex` (`dateDeleted`),
  KEY `idx_rrrjthtupkccfhwuhbxesxnnsmgieioplpck` (`fieldLayoutId`),
  KEY `idx_xhotovqdxjwublpnjxcemljgzdynrastxxha` (`type`),
  KEY `idx_hosgfevflznmcwuigslocvpncuiyiuxrsyig` (`enabled`),
  KEY `idx_iwqdfglvxqgcydppyvmxfmcygqzkyulrqkpv` (`canonicalId`),
  KEY `idx_vxjpeprvycdbonjdwxvkrdyaaczsqnuvhcde` (`archived`,`dateCreated`),
  KEY `idx_uqprtsmczgxnkswsjfsiyceqazameeiurrgb` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_tshzmtssqwkuwsilxkiiptwgbbqbiqzfvlcw` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_rsfmvwebliduejvzppizhyjyalrjrsfibcfb` (`draftId`),
  KEY `fk_cdjoyayfdojstynbuvurrmxxccenkpxuvwje` (`revisionId`),
  CONSTRAINT `fk_aksyectwgxczmjhznqbfmkligtqhmioybnex` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cdjoyayfdojstynbuvurrmxxccenkpxuvwje` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rsfmvwebliduejvzppizhyjyalrjrsfibcfb` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zzbhjabzzuqmvezmeieuifckqpivseebnbsz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-06-01 00:08:08','2024-06-01 00:21:53',NULL,NULL,NULL,'bf02866b-4da7-4102-9950-c6ef0c9cc0d9'),(2,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,NULL,NULL,'92f8810b-497e-44bc-9f8a-17f1028298ff'),(3,2,NULL,1,3,'craft\\elements\\Entry',1,0,'2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,NULL,NULL,'4a4e54e1-0e3f-435f-9624-f8b5c2aa5017'),(4,NULL,NULL,NULL,4,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:18:03','2024-06-03 17:18:03',NULL,NULL,NULL,'41ba029c-5560-4889-b020-cbff500e9bdd'),(5,NULL,NULL,NULL,5,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:18:51','2024-06-04 17:19:43',NULL,NULL,NULL,'7073c177-69ef-4762-8e87-a215481a3504'),(6,NULL,NULL,NULL,6,'craft\\elements\\GlobalSet',1,0,'2024-06-03 17:19:21','2024-06-03 17:20:34',NULL,NULL,NULL,'e71097ea-8036-4ab5-8637-e9dca0771aad'),(7,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2024-06-03 21:14:24','2024-06-05 16:19:39',NULL,NULL,NULL,'d50b21ee-158f-4307-aadb-0b5b5c7f604d'),(8,NULL,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2024-06-03 21:15:32','2024-06-05 16:19:38',NULL,NULL,NULL,'512266fe-735d-4730-905b-841373842f5d'),(9,NULL,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2024-06-03 21:16:01','2024-06-03 21:16:01',NULL,NULL,NULL,'81b09e58-da55-4950-80d5-f6e3ad9a2c98'),(10,7,NULL,2,7,'craft\\elements\\Entry',1,0,'2024-06-03 21:17:17','2024-06-03 21:17:17',NULL,NULL,NULL,'0a1d9a3e-c76d-4747-8c65-e93e12f34d4c'),(11,8,NULL,3,10,'craft\\elements\\Entry',1,0,'2024-06-03 21:17:17','2024-06-03 21:17:17',NULL,NULL,NULL,'0aa8db99-f731-400b-98ff-b849b12a8e19'),(13,7,NULL,4,7,'craft\\elements\\Entry',1,0,'2024-06-03 21:25:29','2024-06-03 21:25:29',NULL,NULL,NULL,'eaafbff4-2b43-4979-b96c-1db975ff644c'),(14,8,NULL,5,10,'craft\\elements\\Entry',1,0,'2024-06-03 21:25:29','2024-06-03 21:25:29',NULL,NULL,NULL,'35e679b7-265c-4ef8-b595-e652d0de2283'),(16,7,NULL,6,7,'craft\\elements\\Entry',1,0,'2024-06-03 21:35:00','2024-06-03 21:35:00',NULL,NULL,NULL,'a42997dc-abe9-437f-bf7c-3cf3b8b58175'),(17,8,NULL,7,10,'craft\\elements\\Entry',1,0,'2024-06-03 21:35:00','2024-06-03 21:35:00',NULL,NULL,NULL,'35f0a299-2867-4f39-bb1e-3c814dfdad5c'),(21,7,NULL,8,7,'craft\\elements\\Entry',1,0,'2024-06-04 17:56:54','2024-06-04 17:56:54',NULL,NULL,NULL,'b6126533-2e0b-4d10-a51d-f910468a9c82'),(22,8,NULL,9,10,'craft\\elements\\Entry',1,0,'2024-06-04 17:56:52','2024-06-04 17:56:54',NULL,NULL,NULL,'f77370b0-46dc-47e0-8328-41cffb7fa4ac'),(24,7,NULL,10,7,'craft\\elements\\Entry',1,0,'2024-06-04 17:57:25','2024-06-04 17:57:26',NULL,NULL,NULL,'0db2f5d1-3d4e-42b1-a3a8-c6635025089f'),(25,8,NULL,11,10,'craft\\elements\\Entry',0,0,'2024-06-04 17:57:20','2024-06-04 17:57:26',NULL,NULL,NULL,'45a0fbb1-ac8c-4d07-8c5b-ed15e3e63601'),(27,7,NULL,12,7,'craft\\elements\\Entry',1,0,'2024-06-04 17:59:30','2024-06-04 17:59:30',NULL,NULL,NULL,'455839bf-b3ca-4678-b1d5-f1d7e324923e'),(28,8,NULL,13,10,'craft\\elements\\Entry',1,0,'2024-06-04 17:59:20','2024-06-04 17:59:30',NULL,NULL,NULL,'d8a90ffa-1ff9-46ae-857f-4a639e8ee89b'),(33,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2024-06-04 18:16:24','2024-06-05 16:19:39',NULL,NULL,NULL,'2246592a-0c45-4fc8-b812-4c07a69129ad'),(34,7,NULL,14,7,'craft\\elements\\Entry',1,0,'2024-06-04 18:16:24','2024-06-04 18:16:24',NULL,NULL,NULL,'8d704459-9666-4565-af6e-e064322051e1'),(35,8,NULL,15,10,'craft\\elements\\Entry',1,0,'2024-06-04 18:16:24','2024-06-04 18:16:24',NULL,NULL,NULL,'bf59b3ac-ded1-4c8d-b9b3-b460643fc03d'),(36,33,NULL,16,11,'craft\\elements\\Entry',1,0,'2024-06-04 18:16:24','2024-06-04 18:16:24',NULL,NULL,NULL,'533a1241-6258-4fc7-abae-ab67cf8f836d'),(40,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-06-05 15:54:52','2024-06-05 15:54:52',NULL,NULL,NULL,'6259fd5d-26c4-475a-bb6e-607fec8bcdc4'),(41,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-06-05 15:54:52','2024-06-05 15:54:52',NULL,NULL,NULL,'d5ea4d29-51f6-469d-b8fd-ffc33c59d1f4'),(42,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-06-05 15:54:53','2024-06-05 15:54:53',NULL,NULL,NULL,'741ee1f1-edce-467b-bed2-2b6b2bee3146'),(43,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-06-05 15:54:54','2024-06-05 15:54:54',NULL,NULL,NULL,'87b656b3-f405-4a8d-98ab-e43fba396548'),(45,NULL,NULL,NULL,12,'craft\\elements\\Entry',1,0,'2024-06-05 16:02:44','2024-06-05 16:19:39',NULL,NULL,NULL,'21152c76-9e54-4306-bbf0-b11a53bf8618'),(46,7,NULL,17,7,'craft\\elements\\Entry',1,0,'2024-06-05 16:02:44','2024-06-05 16:02:44',NULL,NULL,NULL,'163164a5-6542-444e-8fe0-307ded194a5c'),(47,8,NULL,18,10,'craft\\elements\\Entry',1,0,'2024-06-05 15:55:29','2024-06-05 16:02:44',NULL,NULL,NULL,'7621e6d2-71b1-49e9-986f-5faa069fd582'),(48,33,NULL,19,11,'craft\\elements\\Entry',1,0,'2024-06-05 15:55:29','2024-06-05 16:02:44',NULL,NULL,NULL,'dbb01fdd-2622-41a5-ad78-6cc1110fdc05'),(49,45,NULL,20,12,'craft\\elements\\Entry',1,0,'2024-06-05 16:02:44','2024-06-05 16:02:44',NULL,NULL,NULL,'c0d991b3-b6ae-4dcb-9044-dbff549f483c'),(52,NULL,NULL,NULL,13,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:19:39',NULL,NULL,NULL,'98797370-bab3-4620-838a-d11dee7702e7'),(53,7,NULL,21,7,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:18:54',NULL,NULL,NULL,'603c3cb8-33cc-4f29-8838-95c17fa74fa0'),(54,8,NULL,22,10,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:18:54',NULL,NULL,NULL,'84e82e2b-b81d-4c46-aa20-53f8a151cd62'),(55,33,NULL,23,11,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:18:54',NULL,NULL,NULL,'66e34ca5-10d2-472f-97bb-f313a1f1c5f7'),(56,45,NULL,24,12,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:18:54',NULL,NULL,NULL,'8f791b00-f53c-4268-a9ab-a1ffb052cd85'),(57,52,NULL,25,13,'craft\\elements\\Entry',1,0,'2024-06-05 16:18:54','2024-06-05 16:18:54',NULL,NULL,NULL,'310f6c51-2962-4e19-b77f-e4c1dd02f2af'),(60,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'2ed46c23-2b80-44e3-b802-4e8507999434'),(61,7,NULL,26,7,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'dc25b1d8-cb3a-4d95-a91c-82eca3c1d059'),(62,8,NULL,27,10,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:38','2024-06-05 16:19:39',NULL,NULL,NULL,'684fe9ad-ccce-437b-941e-0ce07ccd2f0a'),(63,33,NULL,28,11,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'274f185e-f62b-4559-b728-6b62e561240a'),(64,45,NULL,29,12,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'347e9768-2d50-451a-8977-389117cbc0fd'),(65,60,NULL,30,11,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'ed61caae-edf8-44c7-9e59-a60ce2bdd68e'),(66,52,NULL,31,13,'craft\\elements\\Entry',1,0,'2024-06-05 16:19:39','2024-06-05 16:19:39',NULL,NULL,NULL,'8200627e-951a-4931-ab52-e5df2af8bce2');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_hdjuptxqrapzyctmdgsicmpbthvwsoahdrhy` (`timestamp`),
  CONSTRAINT `fk_hwrxnmaovmnnohbvazgossendaislhgcdpli` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_gxrcjywlmdkblxczuuwmcawsimykaubpgczw` (`ownerId`),
  CONSTRAINT `fk_gxrcjywlmdkblxczuuwmcawsimykaubpgczw` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_osfdhibfcttkxkavvqctekoqiwobpffvkwgm` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES (8,7,1),(11,10,1),(14,13,1),(17,16,1),(22,21,1),(25,24,1),(28,27,1),(33,7,2),(35,34,1),(36,34,2),(45,7,3),(47,46,1),(48,46,2),(49,46,3),(52,7,5),(54,53,1),(55,53,2),(56,53,3),(57,53,4),(60,7,4),(62,61,1),(63,61,2),(64,61,3),(65,61,4),(66,61,5);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mytdkgcibiubohfyclhjwfzrhalimrigdkew` (`elementId`,`siteId`),
  KEY `idx_lylhyeydbbpqijkiagmztxssranoblmpvgmm` (`siteId`),
  KEY `idx_hvxsxlwjfhswxqlfhwbihkciuwydudkidade` (`title`,`siteId`),
  KEY `idx_vtmgkjxgtwqspsspdcfhgmnthxvtqofrunzl` (`slug`,`siteId`),
  KEY `idx_djfepcactcccshidyfdjbaiobtupmoqzotem` (`enabled`),
  KEY `idx_jbfnlkfugkpunwmegaohmfomxzhsvcfgniwp` (`uri`,`siteId`),
  CONSTRAINT `fk_hgzahndzysacatnuvgwrisowxaskudussyti` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oebimdjpemfzokfrhkvhwzzkzdpbhuqqhtld` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-06-01 00:08:08','2024-06-01 00:08:08','50b8b55a-a87a-4904-8432-9f40024e2592'),(2,2,1,'Home Page','home-page','__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','d6c7d674-5d4d-4771-83b0-ff8b301de9d0'),(3,3,1,'Home Page','home-page','__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','fc4a0d1a-6c55-40ff-bc71-240613c21c3c'),(4,4,1,NULL,NULL,NULL,'{\"c41cd145-6819-4d6d-b827-ddfe9e14f813\": \"all\"}',1,'2024-06-03 17:18:03','2024-06-03 17:18:03','3a2cdae7-3523-4aeb-8f4b-b3621fb5e8cb'),(5,5,1,NULL,NULL,NULL,NULL,1,'2024-06-03 17:18:51','2024-06-03 17:18:51','a72ffa01-03ad-4ffa-a216-bf25ee8c09f4'),(6,6,1,NULL,NULL,NULL,'{\"06fb32a9-2c98-48a8-a45b-97e613b191c0\": [{\"col1\": \"pageWidth\", \"col2\": \"1150\"}, {\"col1\": \"contentWidth\", \"col2\": \"940\"}, {\"col1\": \"sidebarWidth\", \"col2\": \"212\"}]}',1,'2024-06-03 17:19:21','2024-06-03 17:20:34','8df14bed-ea63-4541-82cf-cfe3d7beb6a6'),(7,7,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"8\\\"> </craft-entry><craft-entry data-entry-id=\\\"33\\\"> </craft-entry><p> </p><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p><craft-entry data-entry-id=\\\"45\\\"> </craft-entry><craft-entry data-entry-id=\\\"60\\\"> </craft-entry><craft-entry data-entry-id=\\\"52\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-03 21:14:24','2024-06-05 16:19:39','a3300107-3b7c-4319-933b-3a5a0bf10aae'),(8,8,1,'Por do Sol em Baixa Grande - Size: imageLarge - Border: No','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-03 21:15:32','2024-06-05 15:06:32','9f75b5de-f28a-40b6-820b-104fa5d5c1b1'),(9,9,1,'Por do Sol em Baixa Grande',NULL,NULL,NULL,1,'2024-06-03 21:16:01','2024-06-03 21:16:01','8acd45f1-8781-41fc-9d25-4d727d48fe99'),(10,10,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<p>This is the about page. Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"11\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-03 21:17:17','2024-06-03 21:17:17','ad1ac342-9022-411d-9f4c-b1ef5f87e224'),(11,11,1,NULL,'__temp_hjghmlrwmsdlgakjaeymkptdqdnxunvxeitp',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageMedium\", \"9154ca2e-cd14-47ce-93f7-597e1eaaac53\": \"Sunrise\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": true}',1,'2024-06-03 21:17:17','2024-06-03 21:17:17','7699fe5c-1c32-4c95-ac92-45059cab84e9'),(13,13,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"14\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-03 21:25:29','2024-06-03 21:25:30','2f533a0d-542b-49d3-ad3b-414db6b92c08'),(14,14,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageMedium\", \"9154ca2e-cd14-47ce-93f7-597e1eaaac53\": \"Sunrise\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": true}',1,'2024-06-03 21:25:29','2024-06-03 21:25:29','502520bb-2c27-4f1c-ad8f-1bd89ea4df2e'),(16,16,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"17\\\"> </craft-entry><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-03 21:35:00','2024-06-03 21:35:00','3d01b552-f79c-4bd3-bb14-35561d04adfa'),(17,17,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageMedium\", \"9154ca2e-cd14-47ce-93f7-597e1eaaac53\": \"Sunrise\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": true}',1,'2024-06-03 21:35:00','2024-06-03 21:35:00','a07eb821-81f8-4ad5-bfb1-de2142b65e2b'),(21,21,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"22\\\"> </craft-entry><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-04 17:56:54','2024-06-04 17:56:54','b825e1e4-cf00-43c1-9542-e12d1b3803be'),(22,22,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-04 17:56:54','2024-06-04 17:56:54','6a416e22-268f-4d72-b9ca-3bc05f71d45f'),(24,24,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"25\\\"> </craft-entry><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-04 17:57:26','2024-06-04 17:57:26','639b6b29-582b-40a9-a571-80b3e7a78c2f'),(25,25,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-04 17:57:26','2024-06-04 17:57:26','3bd8e0bd-1adc-4014-848e-1f6743d95ae2'),(27,27,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"28\\\"> </craft-entry><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-04 17:59:30','2024-06-04 17:59:30','92432ae0-0d04-4df4-857c-cb846e7ac104'),(28,28,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-04 17:59:30','2024-06-04 17:59:30','6a46c74b-7156-4b16-b834-a9cc1936e5a7'),(33,33,1,'Visible - Space above: custom - Space below: default','divider-1-custom-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"custom\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true, \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\": 4}',1,'2024-06-04 18:16:24','2024-06-05 16:19:39','66e06d7f-2f85-4a2f-a463-4dde0aadc234'),(34,34,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"35\\\"> </craft-entry><craft-entry data-entry-id=\\\"36\\\"> </craft-entry><p> </p><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-04 18:16:24','2024-06-04 18:16:24','eb2f23b6-8eb1-413f-bf77-b4aec7f1fa64'),(35,35,1,'Por do Sol em Baixa Grande','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-04 18:16:24','2024-06-04 18:16:24','d309477c-82ff-4121-b8ad-a15055ee54ad'),(36,36,1,'Divider (Visible - custom/default)','divider-1-custom-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"custom\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true, \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\": 150}',1,'2024-06-04 18:16:24','2024-06-04 18:16:24','cd8c9ac0-619f-4abd-b004-8757d2c14c1d'),(40,40,1,'P Fit Seat Quote part numbers reference',NULL,NULL,NULL,1,'2024-06-05 15:54:52','2024-06-05 15:54:52','0098af33-82f2-456f-9c53-6ac618002dae'),(41,41,1,'P Fit Back Quote part numbers reference',NULL,NULL,NULL,1,'2024-06-05 15:54:52','2024-06-05 15:54:52','6faeaa1a-f0a2-4765-8c6c-835c8c739132'),(42,42,1,'P Fit Back Quote',NULL,NULL,NULL,1,'2024-06-05 15:54:53','2024-06-05 15:54:53','c8345c33-ac45-49d9-a25f-723758be67be'),(43,43,1,'P Fit Seat Quote',NULL,NULL,NULL,1,'2024-06-05 15:54:54','2024-06-05 15:54:54','1b04472f-0b64-4d64-beea-908a2e9c3c13'),(45,45,1,'2 Document(s) - Display: cards - Show file size: Yes','cards-1',NULL,'{\"5f0aebc1-82b2-41e4-9425-279580bc9d3b\": \"cards\", \"6b35829f-d82f-4e26-8b33-1da55ef11648\": true}',1,'2024-06-05 16:02:44','2024-06-05 16:02:44','6b83de03-a26e-4086-b4ca-556ef3dee108'),(46,46,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"47\\\"> </craft-entry><craft-entry data-entry-id=\\\"48\\\"> </craft-entry><p> </p><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p><craft-entry data-entry-id=\\\"49\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-05 16:02:44','2024-06-05 16:02:44','64aa8f02-7f1c-4dd6-880f-a81dcd981d49'),(47,47,1,'Por do Sol em Baixa Grande - Size: imageLarge - Border: No','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-05 16:02:44','2024-06-05 16:02:44','16612bbb-9692-455a-a7c3-6394ba5639db'),(48,48,1,'Visible - Space above: custom - Space below: default','divider-1-custom-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"custom\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true, \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\": 4}',1,'2024-06-05 16:02:44','2024-06-05 16:02:44','34eb0e17-8a3c-4760-81d4-ee2332ad0c0a'),(49,49,1,'2 Document(s) - Display: cards - Show file size: Yes','cards-1',NULL,'{\"5f0aebc1-82b2-41e4-9425-279580bc9d3b\": \"cards\", \"6b35829f-d82f-4e26-8b33-1da55ef11648\": true}',1,'2024-06-05 16:02:44','2024-06-05 16:02:44','c1426077-c2fd-41c9-9930-92071c3c2b36'),(52,52,1,'YouTube Video','youtube-video',NULL,'{\"deb35a50-a7c0-4d90-ab01-2c07189845aa\": \"<iframe width=\\\"560\\\" height=\\\"315\\\" src=\\\"https://www.youtube.com/embed/wzb5Yn3oT2w?si=AjMHmWpDOtSG7lmm\\\" title=\\\"YouTube video player\\\" frameborder=\\\"0\\\" allow=\\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\\\" referrerpolicy=\\\"strict-origin-when-cross-origin\\\" allowfullscreen></iframe>\"}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','fb85a246-fb13-4a5d-8ec9-56bb0ab29b6b'),(53,53,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"54\\\"> </craft-entry><craft-entry data-entry-id=\\\"55\\\"> </craft-entry><p> </p><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p><craft-entry data-entry-id=\\\"56\\\"> </craft-entry><craft-entry data-entry-id=\\\"57\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','5b429bc5-9e28-4297-aea6-0b46b14ce07b'),(54,54,1,'Por do Sol em Baixa Grande - Size: imageLarge - Border: No','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','06abcf42-27fe-4d53-8a7d-e5d0fe990444'),(55,55,1,'Visible - Space above: custom - Space below: default','divider-1-custom-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"custom\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true, \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\": 4}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','9f8e13be-23aa-42f6-8e1c-5ad3384c56c8'),(56,56,1,'2 Document(s) - Display: cards - Show file size: Yes','cards-1',NULL,'{\"5f0aebc1-82b2-41e4-9425-279580bc9d3b\": \"cards\", \"6b35829f-d82f-4e26-8b33-1da55ef11648\": true}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','f384eb6a-f8aa-4dd3-8f38-9bdd6bd5c182'),(57,57,1,'YouTube Video','youtube-video',NULL,'{\"deb35a50-a7c0-4d90-ab01-2c07189845aa\": \"<iframe width=\\\"560\\\" height=\\\"315\\\" src=\\\"https://www.youtube.com/embed/wzb5Yn3oT2w?si=AjMHmWpDOtSG7lmm\\\" title=\\\"YouTube video player\\\" frameborder=\\\"0\\\" allow=\\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\\\" referrerpolicy=\\\"strict-origin-when-cross-origin\\\" allowfullscreen></iframe>\"}',1,'2024-06-05 16:18:54','2024-06-05 16:18:54','3d6b9ade-8b75-4951-a596-49d5e1c04fa2'),(60,60,1,'Visible - Space above: default - Space below: default','visible-space-above-default-space-below-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"default\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','7b948736-ba41-4a5d-827c-dde480fb00c0'),(61,61,1,'About Us','about-us','about-us','{\"439d8587-b447-424f-a2aa-55d41dfc7d03\": \"<h2>This is the about page.</h2><p>Let\'s see how this looks like when I add an image.</p><craft-entry data-entry-id=\\\"62\\\"> </craft-entry><craft-entry data-entry-id=\\\"63\\\"> </craft-entry><p> </p><figure class=\\\"table\\\"><table><thead><tr><th>Name</th><th>Date</th><th>Options</th></tr></thead><tbody><tr><td>Peter Pan</td><td>January 7th, 2024</td><td>More options than you can imagine</td></tr><tr><td>Jack London</td><td>September 4th, 2022</td><td>Material has been extended</td></tr></tbody></table></figure><p>I wonder how the table above looks like.</p><craft-entry data-entry-id=\\\"64\\\"> </craft-entry><craft-entry data-entry-id=\\\"65\\\"> </craft-entry><craft-entry data-entry-id=\\\"66\\\"> </craft-entry><p> </p>\", \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\": false, \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\": \"all\"}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','a87bc4db-bc48-4855-a15e-890a687d1e17'),(62,62,1,'Por do Sol em Baixa Grande - Size: imageLarge - Border: No','por-do-sol-em-baixa-grande',NULL,'{\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\": \"left\", \"6d02377d-9d38-46d1-84c4-07836f4bea30\": \"imageLarge\", \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\": false}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','5e8e81f1-1170-4b63-82e9-bf23ffb729f7'),(63,63,1,'Visible - Space above: custom - Space below: default','divider-1-custom-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"custom\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true, \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\": 4}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','ad15c02a-3c4f-4ffb-85eb-69fe8153fc8b'),(64,64,1,'2 Document(s) - Display: cards - Show file size: Yes','cards-1',NULL,'{\"5f0aebc1-82b2-41e4-9425-279580bc9d3b\": \"cards\", \"6b35829f-d82f-4e26-8b33-1da55ef11648\": true}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','22d5a2e0-3144-446d-884d-12b27fcfa351'),(65,65,1,'Visible - Space above: default - Space below: default','visible-space-above-default-space-below-default',NULL,'{\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\": \"default\", \"1b6c7209-a337-4255-b3dc-a262768a2d60\": \"default\", \"8a3e7279-eb49-4331-a669-34d48b31c79c\": true}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','f277f30d-45b3-49fa-8161-37738f1757e3'),(66,66,1,'YouTube Video','youtube-video',NULL,'{\"deb35a50-a7c0-4d90-ab01-2c07189845aa\": \"<iframe width=\\\"560\\\" height=\\\"315\\\" src=\\\"https://www.youtube.com/embed/wzb5Yn3oT2w?si=AjMHmWpDOtSG7lmm\\\" title=\\\"YouTube video player\\\" frameborder=\\\"0\\\" allow=\\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\\\" referrerpolicy=\\\"strict-origin-when-cross-origin\\\" allowfullscreen></iframe>\"}',1,'2024-06-05 16:19:39','2024-06-05 16:19:39','89a0f1e9-dece-4682-bcf5-e91804192f21');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vtobcdijnjwulyvtwnytnmyjtkifiubcjtnx` (`postDate`),
  KEY `idx_yuhcswvacgkleobbtoikhrvvfklqirnziezk` (`expiryDate`),
  KEY `idx_bjxmkcfurmrglrgghdddihmnobgkpdrpsuta` (`sectionId`),
  KEY `idx_wfppxigpjssdzouhffpeqnlhsfwwlupjkwci` (`typeId`),
  KEY `idx_efpfitqukwkfwfeidzjvrxilpcyspvyozfos` (`primaryOwnerId`),
  KEY `idx_pexyannqnsnvlnhmcnluhmuoaszwdfwyrahm` (`fieldId`),
  KEY `fk_pwylaichxdadgroaczjgvzduynkdjgndeccg` (`parentId`),
  CONSTRAINT `fk_fomgswfnulqcdtiqtrtxsywzqnrbvjkgjjqo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_imserzhryubnflsyomvkzzptikcynsqrbklq` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pwylaichxdadgroaczjgvzduynkdjgndeccg` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qlefgpkhrymttpfpgloruipmtfqwzljanlbf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qsyuktsrhvwwpgkgmbvuddyhwbohejdecqda` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vczszmzyddktfwedpujalnvogwenzczcfpdq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-06-01 19:17:00',NULL,NULL,'2024-06-01 19:17:24','2024-06-01 19:17:24'),(3,1,NULL,NULL,NULL,1,'2024-06-01 19:17:00',NULL,NULL,'2024-06-01 19:17:24','2024-06-01 19:17:24'),(7,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-03 21:14:24','2024-06-03 21:17:17'),(8,NULL,NULL,7,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-03 21:15:32','2024-06-03 21:16:23'),(10,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-03 21:17:17','2024-06-03 21:17:17'),(11,NULL,NULL,10,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-03 21:17:17','2024-06-03 21:17:17'),(13,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-03 21:25:29','2024-06-03 21:25:29'),(14,NULL,NULL,13,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-03 21:25:29','2024-06-03 21:25:29'),(16,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-03 21:35:00','2024-06-03 21:35:00'),(17,NULL,NULL,16,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-03 21:35:00','2024-06-03 21:35:00'),(21,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-04 17:56:54','2024-06-04 17:56:54'),(22,NULL,NULL,21,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-04 17:56:54','2024-06-04 17:56:54'),(24,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-04 17:57:26','2024-06-04 17:57:26'),(25,NULL,NULL,24,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-04 17:57:26','2024-06-04 17:57:26'),(27,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-04 17:59:30','2024-06-04 17:59:30'),(28,NULL,NULL,27,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-04 17:59:30','2024-06-04 17:59:30'),(33,NULL,NULL,7,23,6,'2024-06-04 18:11:00',NULL,NULL,'2024-06-04 18:16:24','2024-06-04 18:16:24'),(34,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-04 18:16:24','2024-06-04 18:16:24'),(35,NULL,NULL,34,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-04 18:16:24','2024-06-04 18:16:24'),(36,NULL,NULL,34,23,6,'2024-06-04 18:11:00',NULL,NULL,'2024-06-04 18:16:24','2024-06-04 18:16:24'),(45,NULL,NULL,7,23,7,'2024-06-05 15:55:00',NULL,NULL,'2024-06-05 16:02:44','2024-06-05 16:02:44'),(46,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-05 16:02:44','2024-06-05 16:02:44'),(47,NULL,NULL,46,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-05 16:02:44','2024-06-05 16:02:44'),(48,NULL,NULL,46,23,6,'2024-06-04 18:11:00',NULL,NULL,'2024-06-05 16:02:44','2024-06-05 16:02:44'),(49,NULL,NULL,46,23,7,'2024-06-05 15:55:00',NULL,NULL,'2024-06-05 16:02:44','2024-06-05 16:02:44'),(52,NULL,NULL,7,23,8,'2024-06-05 16:18:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(53,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(54,NULL,NULL,53,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(55,NULL,NULL,53,23,6,'2024-06-04 18:11:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(56,NULL,NULL,53,23,7,'2024-06-05 15:55:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(57,NULL,NULL,53,23,8,'2024-06-05 16:18:00',NULL,NULL,'2024-06-05 16:18:54','2024-06-05 16:18:54'),(60,NULL,NULL,7,23,6,'2024-06-05 16:19:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(61,2,NULL,NULL,NULL,2,'2024-06-03 21:17:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(62,NULL,NULL,61,23,5,'2024-06-03 21:16:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(63,NULL,NULL,61,23,6,'2024-06-04 18:11:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(64,NULL,NULL,61,23,7,'2024-06-05 15:55:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(65,NULL,NULL,61,23,6,'2024-06-05 16:19:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39'),(66,NULL,NULL,61,23,8,'2024-06-05 16:18:00',NULL,NULL,'2024-06-05 16:19:39','2024-06-05 16:19:39');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_zyqrxtnhpzqozzhwfatsiqbaccillnstyito` (`authorId`),
  KEY `idx_iyvmuxikghsjkrjyymhwdpwizygoxakawvaa` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_wcxubitnwxhmrcnxsfvgpaafnqhecspovnmd` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wyannemjivtuwjgghwnfczfwotsrdjgrbppn` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
INSERT INTO `entries_authors` VALUES (7,1,1),(10,1,1),(13,1,1),(16,1,1),(21,1,1),(24,1,1),(27,1,1),(34,1,1),(46,1,1),(53,1,1),(61,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fwkxfiegmhlrwabjfffjhphtccfsqqezrhle` (`fieldLayoutId`),
  KEY `idx_ryjksafnoskqlhtiungufztheetjfrvkhpus` (`dateDeleted`),
  CONSTRAINT `fk_wwvuoevhgtwuuqhprjfjbwqgqhhrijyullec` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,3,'Home Page','home','house',NULL,0,'site',NULL,'{section.name|raw}',0,'site',NULL,0,'2024-06-01 19:16:39','2024-06-01 19:16:39',NULL,'0ed79961-f5ad-4469-bd11-abcf7a9afd71'),(2,7,'Default Page','defaultPage','memo','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:23:29','2024-06-03 17:23:45',NULL,'c678a4d3-15e8-4ea1-86d7-9b5206b7359e'),(3,8,'Index Page','indexPage','list','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:25:48','2024-06-03 17:25:48',NULL,'7c32c045-0976-46d4-a6cb-9748ae189379'),(4,9,'Page Redirect','pageRedirect','arrows-rotate','orange',1,'site',NULL,'',1,'site',NULL,1,'2024-06-03 17:26:59','2024-06-03 17:26:59',NULL,'39b18b62-f3cf-48e0-8827-95bb425853de'),(5,10,'Image','image','image','purple',0,'site',NULL,'{image.one.title} - Size: {imageSize} - Border: {showBorder ? \'Yes\' : \'No\'}',0,'site',NULL,1,'2024-06-03 21:03:24','2024-06-05 15:06:31',NULL,'ca088dca-1d9b-4782-8007-3c66a30e5d3b'),(6,11,'Divider','divider','horizontal-rule','purple',0,'site',NULL,'{visible ? \'Visible\' : \'Hidden\'} - Space above: {spaceAbove} - Space below: {spaceBelow}',0,'site',NULL,1,'2024-06-04 18:10:11','2024-06-05 15:04:40',NULL,'15de76f8-38e3-4f91-9c3c-d7bf1a841274'),(7,12,'Documents','documents','file','purple',0,'site',NULL,'{documents.count} Document(s) - Display: {displayMode} - Show file size: {showFileSize ? \'Yes\' : \'No\'}',0,'site',NULL,1,'2024-06-05 14:22:07','2024-06-05 15:57:55',NULL,'a4797dec-412d-48c3-a4ae-60458e6a7110'),(8,13,'Embed','embed','code','purple',1,'site',NULL,'',0,'site',NULL,1,'2024-06-05 16:16:42','2024-06-05 16:16:42',NULL,'527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ofebnaccaptplbcbmtfoqsymdjrknmkpzofq` (`dateDeleted`),
  KEY `idx_llkbalyatrocqocmmjmkjximzroabinhutaq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"f4e8e41b-3883-4d91-a7e4-1e0057072979\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"96e73468-e88d-4aaa-a07d-aeb7f9b1e8c7\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"3dec9884-fd99-49be-9df8-bde363c3a5ab\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fbc6e983-4336-4480-89fa-9084069c848c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:07:11','2024-06-01 19:12:52',NULL,'d95657ce-d0d3-4b7a-aa1f-47da27680636'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"ecb7d8c4-c296-427c-a2e9-af437c8edf5c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"57df7f4e-80db-413d-9a93-3d27f6b21e2d\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"d101e18f-d572-46ff-92d1-c5f8f7272b59\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5ccb7ad3-87b2-4106-946c-43f35b45b73b\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:12:31','2024-06-01 19:12:31',NULL,'19be8d25-1ea4-4715-a912-c7b518f8af29'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bb924369-6130-4e46-9d71-8c9cdebfd397\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b6c29a05-dbe3-4e10-baec-1621b25d687c\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-01 19:16:39','2024-06-01 19:16:39',NULL,'ddfb89b0-1589-4959-8e98-d2c7b81aaebf'),(4,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"9ef2366e-542c-40cc-a3f4-4eee419142c6\", \"name\": \"Site SEO\", \"elements\": [{\"tip\": null, \"uid\": \"a1e70cc1-3f73-4944-871c-26a69529c0ac\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"0b9fb8ec-a4b4-4921-9c50-fd4b135ef2c1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"605d136e-a57c-46fa-8bc7-7e700a8a6ee8\", \"name\": \"Technical SEO\", \"elements\": [{\"tip\": null, \"uid\": \"bfa35e87-c45b-4b39-ac22-6dec8a4cf772\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7ab49e1d-8c4e-4b01-b832-02d8c69746ef\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c41cd145-6819-4d6d-b827-ddfe9e14f813\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:18:03','2024-06-03 17:18:03',NULL,'8e48703c-752a-4eb7-8296-9948ee96e88f'),(5,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"3aa11335-95bb-45ed-aa78-fa3f3b364186\", \"name\": \"Navigation\", \"elements\": [{\"tip\": null, \"uid\": \"0b185442-deae-4531-804f-66be9f89ddcd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e64a9101-f277-49ae-8a14-3b3d9d77d8e3\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"6dade7bd-d1ae-4b9f-9e39-afc7c7cee0ab\", \"name\": \"Social Media\", \"elements\": [{\"tip\": null, \"uid\": \"a3b5eb47-2bb7-4145-aef0-2ed1ccd678af\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"105168a3-16f3-4b59-94dd-8ee954442a3e\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6bbe5cb3-b44e-4193-87cf-df55bde45db1\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5410b80a-d2c8-4d87-bce0-7e047145966d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:18:51','2024-06-03 19:44:24',NULL,'5188c82f-e10c-48f8-8f78-cf5a182befed'),(6,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"5b03ec01-a79e-4143-b5a1-0027c0d18e6a\", \"name\": \"Settings\", \"elements\": [{\"tip\": null, \"uid\": \"06fb32a9-2c98-48a8-a45b-97e613b191c0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"052856f0-029e-4ecc-991b-f81833a59830\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:19:21','2024-06-03 17:19:21',NULL,'fe2036df-60f1-4282-9924-367184aa578e'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"afb666e8-faf6-44cd-84b9-4614053973fb\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"53e782d5-1589-4eef-971b-e7a79366df33\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"3e41ff08-5719-4097-aa9e-d4c3a8268ed8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"439d8587-b447-424f-a2aa-55d41dfc7d03\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"b4aac04f-9920-4cd9-b418-167317008cc9\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"601c952a-0f95-412d-82d8-238aa80b0da6\", \"name\": \"Settings\", \"elements\": [{\"tip\": null, \"uid\": \"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f7e7cbc6-dbf6-4e59-9430-a7728d67524d\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"f5a163a9-f06c-4693-a109-eb4d0d343bbb\", \"name\": \"SEO\", \"elements\": [{\"tip\": null, \"uid\": \"ae9d5244-7717-481b-8186-55347020a03f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"83694166-ca67-4e8e-ac13-c5f9cab067bb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"a0dc1d7a-907b-4847-95cc-b2904523aca6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:23:29','2024-06-03 21:14:06',NULL,'e899e415-7240-4604-9eee-f2e13d904cf1'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"b8c8b803-6d27-479c-9c86-bb1e72980a97\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"380e9145-1057-4ab4-af19-8fc1e14729f4\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"ee17bf72-cb79-4f5e-b69f-759cd76c410a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"3284bdd5-e0be-4e3e-bc85-ceec41d39ff6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f8b138be-9608-4b14-91eb-d59aa08a08c4\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"612e4c86-ec48-454e-850a-c18fdad32d29\", \"name\": \"SEO\", \"elements\": [{\"tip\": null, \"uid\": \"f2ed8621-590e-46a4-8f2c-e2b7474e8fbd\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"062ecb07-e4e4-47b1-bb1a-efa6804fba22\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"767e7a13-0040-4850-ab89-81ebe26655fc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"cc63830f-0573-4479-97a2-3ffc74e0baf4\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c425ab9e-58a3-470e-92eb-b2accecd2325\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"89ca2926-2ebf-4689-9fac-a603b9a43272\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"62acfd63-f994-4bfc-b9a4-bf043f8772c5\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:25:48','2024-06-03 17:25:48',NULL,'637041b3-51c9-40b8-b376-0cd68ccf1c52'),(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"76130222-c605-495f-9479-62494df13443\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c13e5054-6b16-4c50-843b-42e34b26b633\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"0fe8496a-4fa5-4bc4-994a-f11493f1c911\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 17:26:59','2024-06-03 17:26:59',NULL,'70209356-2464-4ee7-9bc0-dcdb0fdad870'),(10,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"eab38575-10f3-4db9-980b-aafe839eca8b\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"f5e15e65-8fb4-4b24-a5c9-b8cb24317fb5\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"cab8976e-d51f-4252-92cb-87790402a1cf\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"36550229-8708-4818-8d7e-38ac2cc5c716\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"2d9f81b3-3665-44b7-935a-c85a3bc9c490\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c43bfd3e-0cb3-4222-a355-edff142c41cc\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6d02377d-9d38-46d1-84c4-07836f4bea30\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d5cc3481-2797-4764-a74c-b7516866e8ec\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9154ca2e-cd14-47ce-93f7-597e1eaaac53\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"799d449a-60ab-4566-87a2-badf0de0c1ec\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"b40963cc-fb78-4a85-9703-9dcd08ed5d91\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-03 21:03:24','2024-06-05 15:06:31',NULL,'21207bb3-6dd3-4af9-a168-995011950a41'),(11,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"0ab7bd21-26bd-40cf-895a-d6e4069236c8\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"3b4de434-26dd-4b8b-8980-466ef50ea0cb\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"8a3e7279-eb49-4331-a669-34d48b31c79c\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"83aa0b48-9a9a-4704-a405-7622485a2ee6\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"1b6c7209-a337-4255-b3dc-a262768a2d60\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"8d317a03-dd86-4bd3-8aa9-90e87fa5e077\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d7bfb071-e404-4dce-b616-54d08eb40e11\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": {\"class\": \"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\", \"elementType\": \"craft\\\\elements\\\\Entry\", \"fieldContext\": \"global\", \"conditionRules\": [{\"uid\": \"ac59a797-83cd-4489-8660-be8750cdfd8c\", \"class\": \"craft\\\\fields\\\\conditions\\\\OptionsFieldConditionRule\", \"values\": [\"custom\"], \"fieldUid\": \"8d317a03-dd86-4bd3-8aa9-90e87fa5e077\", \"operator\": \"in\", \"layoutElementUid\": \"1b6c7209-a337-4255-b3dc-a262768a2d60\"}]}}, {\"tip\": null, \"uid\": \"12fb1e10-9f6f-4acb-aba8-789f107b07b0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"275acf99-1424-4755-b9da-e515727f036f\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"56b74f68-7c6c-497f-8985-80369a20d040\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d0d661f3-3c1c-4c9d-9108-a3fa916ba6af\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": {\"class\": \"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\", \"elementType\": \"craft\\\\elements\\\\Entry\", \"fieldContext\": \"global\", \"conditionRules\": [{\"uid\": \"c6d6f3cb-aec4-4922-9cd1-1f36d06ea062\", \"class\": \"craft\\\\fields\\\\conditions\\\\OptionsFieldConditionRule\", \"values\": [\"custom\"], \"fieldUid\": \"275acf99-1424-4755-b9da-e515727f036f\", \"operator\": \"in\", \"layoutElementUid\": \"12fb1e10-9f6f-4acb-aba8-789f107b07b0\"}]}}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-04 18:10:11','2024-06-05 15:04:40',NULL,'f79bcaf8-131a-483a-a751-e81a0c0161cf'),(12,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"9eb0863a-c9d5-456b-a70b-c0a894ec77a7\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"70dc51bd-15c6-4992-a6d8-22ea46a721cd\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"5841ffe1-e774-4771-9d77-8134e04bd2ac\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c70b1406-454c-4f9c-a5e6-5baf68193177\", \"required\": true, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"5f0aebc1-82b2-41e4-9425-279580bc9d3b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9f75bf48-5103-49fe-bee5-7d016b7a7c00\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6b35829f-d82f-4e26-8b33-1da55ef11648\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c6cd16bc-aa04-46fd-b6fe-628216e7e8c8\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-05 14:22:07','2024-06-05 15:57:55',NULL,'4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c'),(13,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"148f94dc-c131-4c15-9fa9-14200c99f44a\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"b96d3d8d-1e92-4bfa-b8c4-4e29f0e23fa8\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": \"Embed type\", \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": \"Please describe what type of embed is this and/or what is its purpose (e.g. YouTube Video)\", \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"deb35a50-a7c0-4d90-ab01-2c07189845aa\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"40cffa1a-cd1e-4729-9196-f4f7cb49b510\", \"required\": true, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-06-05 16:16:42','2024-06-05 16:16:42',NULL,'96f43348-64ba-40e0-aa42-ea0eecfcc154');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ajtayeejxdfhxmivmksvvjskicshnorppxap` (`handle`,`context`),
  KEY `idx_lxkjzazgoetwrcconjsxfhezeodwoneidbzi` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Alternative Text','alternativeText','global',NULL,'This text is used within an HTML code to describe the appearance and function of an image on a page.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-01 19:11:12','2024-06-01 19:11:12','fbc6e983-4336-4480-89fa-9084069c848c'),(2,'Asset Description','assetDescription','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-01 19:11:47','2024-06-01 19:11:47','5ccb7ad3-87b2-4106-946c-43f35b45b73b'),(3,'Caption','caption','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:00:34','2024-06-03 17:00:34','799d449a-60ab-4566-87a2-badf0de0c1ec'),(4,'Carousel Interval','carouselInterval','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":10,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":null,\"suffix\":null}','2024-06-03 17:01:21','2024-06-03 17:01:21','a290cd19-1afc-4081-b7a5-d4f57e022734'),(5,'Facebook Handle','facebookHandle','global',NULL,'Your Facebook company/fan page handle (the part after https://www.facebook.com/)',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:02:08','2024-06-03 17:02:08','5410b80a-d2c8-4d87-bce0-7e047145966d'),(6,'Google Analytics Tracking ID','analyticsId','global',NULL,'If you enter your Google Analytics Tracking ID here, the Google Analytics script tags will be included in your <head> (the script is not included if devMode is on or during Live Preview). Only enter the ID, e.g.: UA-XXXXXX-XX, not the entire script code. [Here\'s how to get it](https://support.google.com/analytics/answer/1032385?hl=en).',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":15,\"code\":true,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:04:37','2024-06-03 17:04:37','7ab49e1d-8c4e-4b01-b832-02d8c69746ef'),(7,'Hide Sidebar','hideSidebar','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2024-06-03 17:05:16','2024-06-03 17:05:16','f7e7cbc6-dbf6-4e59-9430-a7728d67524d'),(8,'Page Heading','pageHeading','global',NULL,'Specify a main heading for the page. The **Page Title** will be used by default if you leave this empty.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":\"Leave empty if same as Page Title\",\"uiMode\":\"normal\"}','2024-06-03 17:06:01','2024-06-03 17:06:01','9ba82f61-ac54-4bfe-827b-e506e0d79ff6'),(9,'Redirect Status Code','redirectStatusCode','global',NULL,NULL,0,'none',NULL,'craft\\fields\\RadioButtons','{\"options\":[{\"label\":\"Permanent Redirect (301)\",\"value\":\"301\",\"default\":\"1\"},{\"label\":\"Temporary Redirect (302)\",\"value\":\"302\",\"default\":\"\"}]}','2024-06-03 17:08:00','2024-06-03 17:08:00','2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9'),(10,'Section Template Folder','sectionTemplateFolder','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:08:44','2024-06-03 17:08:44','f8b138be-9608-4b14-91eb-d59aa08a08c4'),(11,'SEO Description','seoDescription','global',NULL,'The SEO Description should be between 70 and 160 characters (spaces included). Meta descriptions allow you to influence how your web pages are described and displayed in search results. Ensure that all of your web pages have a unique meta description that is explicit and contains your most important keywords.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":160,\"code\":false,\"initialRows\":3,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:09:23','2024-06-03 17:09:23','767e7a13-0040-4850-ab89-81ebe26655fc'),(12,'SEO Image','seoImage','global',NULL,'The image that should be used to represent this page',0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":0,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Select an image\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-06-03 17:11:41','2024-06-03 17:11:41','c425ab9e-58a3-470e-92eb-b2accecd2325'),(13,'SEO Robots','seoRobots','global',NULL,'Tell the search engine crawlers what you want them to do with this page.',0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Indexing is allowed\",\"value\":\"all\",\"default\":\"1\"},{\"label\":\"Indexing is NOT allowed\",\"value\":\"noindex, nofollow\",\"default\":\"\"}]}','2024-06-03 17:12:28','2024-06-03 17:12:28','62acfd63-f994-4bfc-b9a4-bf043f8772c5'),(14,'SEO Title','seoTitle','global',NULL,'The SEO Title should be between 10 and 70 characters (spaces included). Make sure your title tag is explicit and contains your most important keywords. Be sure that each page has a unique title tag. The siteSeoName length is subtracted from the 70 character limit automatically, since it is appended to the seoTitle.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":70,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:13:02','2024-06-03 17:13:02','fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c'),(16,'Theme Settings','themeSettings','global',NULL,'Adjust the **Theme Level Settings** that control some of the content related functionality.',0,'none',NULL,'craft\\fields\\Table','{\"addRowLabel\":\"Add a setting\",\"columns\":{\"col1\":{\"heading\":\"Setting\",\"handle\":\"setting\",\"width\":\"\",\"type\":\"singleline\"},\"col2\":{\"heading\":\"Value\",\"handle\":\"value\",\"width\":\"\",\"type\":\"singleline\"}},\"defaults\":[{\"col1\":\"\",\"col2\":\"\"}],\"maxRows\":null,\"minRows\":null,\"staticRows\":false}','2024-06-03 17:15:01','2024-06-03 17:15:01','052856f0-029e-4ecc-991b-f81833a59830'),(17,'Twitter Handle','twitterHandle','global',NULL,'Your Twitter Handle, without the preceding @ This must be set for Twitter Card tags to be generated.',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":true,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-03 17:15:34','2024-06-03 17:15:34','105168a3-16f3-4b59-94dd-8ee954442a3e'),(18,'Main Navigation','mainNavigation','global',NULL,'Select the entries that should appear in main navigation',0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":true,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:8f8af384-0f07-4623-8f6d-c54bde2fa965\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-06-03 19:43:29','2024-06-03 19:43:29','e64a9101-f277-49ae-8a14-3b3d9d77d8e3'),(19,'Alignment','alignment','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Left\",\"value\":\"left\",\"default\":\"1\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"right\",\"value\":\"right\",\"default\":\"\"}]}','2024-06-03 21:04:34','2024-06-03 21:04:34','c43bfd3e-0cb3-4222-a355-edff142c41cc'),(20,'Image Size','imageSize','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Thumbnail\",\"value\":\"imageThumbnail\",\"default\":\"\"},{\"label\":\"Small\",\"value\":\"imageSmall\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"imageMedium\",\"default\":\"1\"},{\"label\":\"Large\",\"value\":\"imageLarge\",\"default\":\"\"},{\"label\":\"Full Width\",\"value\":\"imageFull\",\"default\":\"\"}]}','2024-06-03 21:05:42','2024-06-03 21:05:42','d5cc3481-2797-4764-a74c-b7516866e8ec'),(21,'Show Border','showBorder','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":\"NO\",\"onLabel\":\"YES\"}','2024-06-03 21:06:10','2024-06-03 21:06:10','7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e'),(22,'Image','image','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Select an image\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"sources\":[\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-06-03 21:07:41','2024-06-03 21:07:41','36550229-8708-4818-8d7e-38ac2cc5c716'),(23,'Main Content','mainContent','global',NULL,NULL,1,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"*\",\"ckeConfig\":\"6c6f8774-f88b-4d21-b5db-035b04738b9d\",\"createButtonLabel\":\"+ Block\",\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"entryTypes\":[\"ca088dca-1d9b-4782-8007-3c66a30e5d3b\",\"15de76f8-38e3-4f91-9c3c-d7bf1a841274\",\"a4797dec-412d-48c3-a4ae-60458e6a7110\",\"527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc\"],\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-06-03 21:13:43','2024-06-05 16:17:03','b4aac04f-9920-4cd9-b418-167317008cc9'),(24,'Visible','visible','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":true,\"offLabel\":\"NO\",\"onLabel\":\"YES\"}','2024-06-04 18:03:57','2024-06-04 18:03:57','83aa0b48-9a9a-4704-a405-7622485a2ee6'),(25,'Space Above','spaceAbove','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Smaller\",\"value\":\"smaller\",\"default\":\"\"},{\"label\":\"Default\",\"value\":\"default\",\"default\":\"1\"},{\"label\":\"Larger\",\"value\":\"larger\",\"default\":\"\"},{\"label\":\"Custom\",\"value\":\"custom\",\"default\":\"\"}]}','2024-06-04 18:04:42','2024-06-04 18:04:42','8d317a03-dd86-4bd3-8aa9-90e87fa5e077'),(26,'Space Above (Custom)','spaceAboveCustom','global',NULL,'Specify the amount of space above the divider if you selected **Other** above.',0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":3,\"suffix\":null}','2024-06-04 18:05:21','2024-06-04 18:06:42','d7bfb071-e404-4dce-b616-54d08eb40e11'),(27,'Space Below','spaceBelow','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Smaller\",\"value\":\"smaller\",\"default\":\"\"},{\"label\":\"Default\",\"value\":\"default\",\"default\":\"1\"},{\"label\":\"Larger\",\"value\":\"larger\",\"default\":\"\"},{\"label\":\"Custom\",\"value\":\"custom\",\"default\":\"\"}]}','2024-06-04 18:05:58','2024-06-04 18:05:58','275acf99-1424-4755-b9da-e515727f036f'),(28,'Space Below (Custom)','spaceBelowCustom','global',NULL,'Specify the amount of space below the divider if you selected **Other** above.',0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":3,\"suffix\":null}','2024-06-04 18:06:27','2024-06-04 18:06:27','d0d661f3-3c1c-4c9d-9108-a3fa916ba6af'),(29,'Documents','documents','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:8e0e1072-3f93-4df7-a31d-e4f06eb6277f\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Add documents\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-06-05 14:17:27','2024-06-05 14:17:27','c70b1406-454c-4f9c-a5e6-5baf68193177'),(30,'Display Mode','displayMode','global',NULL,NULL,0,'none',NULL,'craft\\fields\\RadioButtons','{\"options\":[{\"label\":\"Listing\",\"value\":\"listing\",\"default\":\"1\"},{\"label\":\"Cards\",\"value\":\"cards\",\"default\":\"\"}]}','2024-06-05 14:18:07','2024-06-05 14:18:07','9f75bf48-5103-49fe-bee5-7d016b7a7c00'),(31,'Show File Size','showFileSize','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":\"No\",\"onLabel\":\"YES\"}','2024-06-05 14:18:38','2024-06-05 14:18:38','c6cd16bc-aa04-46fd-b6fe-628216e7e8c8'),(32,'Embed Code','embedCode','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":true,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-06-05 16:13:53','2024-06-05 16:13:53','40cffa1a-cd1e-4729-9196-f4f7cb49b510');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_inplzulgrhivetbugkzsvdmhmpbdjjrsombn` (`name`),
  KEY `idx_eckpvmcsigmeptusdzblqixervsvsohdnpyc` (`handle`),
  KEY `idx_qylxbphvmwoynxatamibqagaozdwjpcxwhcc` (`fieldLayoutId`),
  KEY `idx_wdrquybixzwtxebmycotoorihmszgsyimgrv` (`sortOrder`),
  CONSTRAINT `fk_dzfrztnjuzgglaxdzdjvkvnjmadrpmxmempd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rozuljjesohieabhkyuvfczjcwgupvvdwxri` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
INSERT INTO `globalsets` VALUES (4,'SEO Settings','seoSettings',4,1,'2024-06-03 17:18:03','2024-06-03 17:18:03','af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c'),(5,'Site Options','siteOptions',5,2,'2024-06-03 17:18:51','2024-06-03 17:18:51','7073c177-69ef-4762-8e87-a215481a3504'),(6,'Site Settings','siteSettings',6,3,'2024-06-03 17:19:21','2024-06-03 17:19:21','e71097ea-8036-4ab5-8637-e9dca0771aad');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-06-05 14:11:10','2024-06-05 14:11:10','6db79ffd-4500-4902-99a6-bb99e4a85c23');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jwcylsfmwhssihqpqvvsuxwroibmdmuroebq` (`accessToken`),
  UNIQUE KEY `idx_yzeggkqulvtuuolxvtpnxusoqipnjdwvdpmf` (`name`),
  KEY `fk_uifdzuaqsyddwddunayghigfwzjjeftmexmr` (`schemaId`),
  CONSTRAINT `fk_uifdzuaqsyddwddunayghigfwzjjeftmexmr` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dyzzrspkrcvnrxaoorssehrvodjkvslmeede` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (1,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_30x20_crop_center-center_none',1,0,0,'2024-06-03 21:16:01','2024-06-03 21:16:01','2024-06-03 21:16:02','561aeacc-64ab-4b61-bbe3-7f009e2b6426'),(2,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_60x40_crop_center-center_none',1,0,0,'2024-06-03 21:16:01','2024-06-03 21:16:01','2024-06-03 21:16:03','7d1b077e-b0bc-41e5-99e3-9080743faf37'),(3,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_120x80_crop_center-center_none',1,0,0,'2024-06-03 21:16:06','2024-06-03 21:16:06','2024-06-03 21:16:07','c0b71f4f-c3b1-41dd-8191-44f7408e07e7'),(4,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_240x160_crop_center-center_none',1,0,0,'2024-06-03 21:16:06','2024-06-03 21:16:06','2024-06-03 21:17:18','a823f0e5-41bd-44c0-82c2-26139b4d0ad2'),(5,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_imageMedium',1,0,0,'2024-06-04 17:54:52','2024-06-04 17:54:52','2024-06-04 17:54:53','20958a43-4ece-4ec5-8c93-5d920d7b3dc2'),(6,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_imageSmall',1,0,0,'2024-06-04 17:55:57','2024-06-04 17:55:57','2024-06-04 17:55:58','3dc04f59-eb06-43df-b7af-e83804e8a1e0'),(7,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_imageLarge',1,0,0,'2024-06-04 17:56:15','2024-06-04 17:56:15','2024-06-04 17:56:16','54f23cb8-effb-4e95-b996-3949f02efd4a'),(8,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_284x190_crop_center-center_none',0,0,1,'2024-06-05 15:10:55','2024-06-05 15:10:55','2024-06-05 15:10:56','7f747740-a217-4ccc-a180-14b6a95bee49'),(9,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_568x380_crop_center-center_none',0,0,1,'2024-06-05 15:10:55','2024-06-05 15:10:55','2024-06-05 15:10:57','4253d3bb-1e58-4062-a27a-c2d6b7989d13'),(10,9,'craft\\imagetransforms\\ImageTransformer','Por-do-Sol-em-Baixa-Grande.jpg',NULL,'_1000x666_crop_center-center_none',0,0,1,'2024-06-05 15:11:04','2024-06-05 15:11:04','2024-06-05 15:11:05','c6f155c1-6fb9-4cae-952a-187396abe4c6');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vyjzuvazemhewpsjcasauxbkneuaolorrydj` (`name`),
  KEY `idx_yrrkzkvzhdvcewwfqupmqwvlfxbljpsyyjnl` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
INSERT INTO `imagetransforms` VALUES (1,'Image Large','imageLarge','fit','center-center',610,610,NULL,NULL,'none',NULL,0,'2024-06-04 17:53:54','2024-06-04 17:51:11','2024-06-04 17:53:54','87d6e9a5-3f0c-40cf-95fc-792962dcc5df'),(2,'Image Medium','imageMedium','fit','center-center',370,370,NULL,NULL,'none',NULL,0,'2024-06-04 17:53:04','2024-06-04 17:53:04','2024-06-04 17:53:04','854cf04c-6962-4002-89fa-551e6ae91659'),(3,'Image Small','imageSmall','fit','center-center',290,290,NULL,NULL,'none',NULL,0,'2024-06-04 17:53:25','2024-06-04 17:53:25','2024-06-04 17:53:25','5d81f0b0-8923-4fb3-9aab-c1e6f611baca'),(4,'Image Thumbnail','imageThumbnail','fit','center-center',130,130,NULL,NULL,'none',NULL,0,'2024-06-04 17:53:47','2024-06-04 17:53:47','2024-06-04 17:53:47','31b7b597-22d9-48a5-833c-8a522c3a4b40');
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.1.7','5.0.0.20',0,'azrlcuxkirgs','3@tyqhgsbfsu','2024-06-01 00:08:08','2024-06-05 16:17:03','35f38d0d-8bed-4fa8-a3f3-17d1d72c2f49');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qnnlcebqfbywtpmfyksbwnwubkaolrnnfgpn` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3da0ee80-385f-4409-af55-a3737df59820'),(2,'craft','m221101_115859_create_entries_authors_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','d67571d8-b5d8-4a1d-8e4a-a9769396f0ae'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','332414e7-74af-4dc8-a8c4-902ab25799de'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','91623637-062f-44c4-aeec-ece921a42eac'),(5,'craft','m230314_110309_add_authenticator_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','14737193-d93a-4756-ad69-0a81fb12af1d'),(6,'craft','m230314_111234_add_webauthn_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','e7dc86d2-93bb-43b4-bcad-6db4f33e142a'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3b44309e-fed1-400c-9482-53a148d43302'),(8,'craft','m230511_000000_field_layout_configs','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','8d2ec236-cfe0-4977-9cde-892a6668207f'),(9,'craft','m230511_215903_content_refactor','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','58782faf-f359-45c5-8524-47cf5349c6d3'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','56ada16c-f51e-42c8-a131-ce7fe94f4265'),(11,'craft','m230524_000001_entry_type_icons','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','acaee37a-9291-4bd5-a9f8-0db021137666'),(12,'craft','m230524_000002_entry_type_colors','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','88e4d7e2-70b3-463a-9a1c-6a6efef5f5bb'),(13,'craft','m230524_220029_global_entry_types','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','d18401ae-f904-4fdc-be6e-0535c1d8d51a'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','24fb405d-0495-43a4-9fea-ea9b29ea3f83'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','caa21ab9-d348-44da-90bc-d969bcd7b55f'),(16,'craft','m230616_173810_kill_field_groups','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','dbe5c73e-ffe3-4cb5-b39a-986c75b64fcc'),(17,'craft','m230616_183820_remove_field_name_limit','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','9a33a87c-f791-4aaf-81a9-0675ce7d7208'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','9d7ca8fd-b25e-40be-a71e-e4729cf663c5'),(19,'craft','m230710_162700_element_activity','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','4d998b19-16b6-496f-8d0a-503e1337d59a'),(20,'craft','m230820_162023_fix_cache_id_type','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','05fc0f91-fb7b-4e61-a163-43a3f0ab3e9d'),(21,'craft','m230826_094050_fix_session_id_type','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','566ea00b-8999-47a7-8bc4-d1b39b263de9'),(22,'craft','m230904_190356_address_fields','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','08a23ea9-30bf-4b4c-a233-da4dc91343fe'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','bbfedafe-fd33-499c-8f19-fe786c7a7232'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','018ea963-45b1-4cf8-b198-89f553699611'),(25,'craft','m231213_030600_element_bulk_ops','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','a5aff2ce-2558-4c79-8f6d-408aa9869749'),(26,'craft','m240129_150719_sites_language_amend_length','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','c9295327-d08a-4505-afd4-c060a57a913f'),(27,'craft','m240206_035135_convert_json_columns','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','02a75551-bdd6-418a-b0c0-ad1c87121a0b'),(28,'craft','m240207_182452_address_line_3','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','86ed34d9-5699-4475-8dcc-d50c2a9827bc'),(29,'craft','m240302_212719_solo_preview_targets','2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-01 00:08:08','3fada93f-8be7-48de-a6e5-b9800d19a174'),(30,'plugin:aws-s3','Install','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','c5d7dd96-c02a-4483-8166-4288f1f719d5'),(31,'plugin:aws-s3','m220119_204627_update_fs_configs','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','2c1e015b-6a7c-408f-8432-6b911898c73c'),(32,'plugin:ckeditor','Install','2024-06-03 21:00:12','2024-06-03 21:00:12','2024-06-03 21:00:12','762f6813-f585-473a-bc9c-138ff5a040bf'),(33,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-06-03 21:00:12','2024-06-03 21:00:12','2024-06-03 21:00:12','f8bcff81-6856-435c-9315-0f82f677a4b1');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yumkmehegzqaijchhtieuioutonmgaqlbyaw` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'aws-s3','2.2.1','2.0','2024-06-01 00:38:02','2024-06-01 00:38:02','2024-06-01 00:38:02','1f16a223-2339-4096-8866-bf5a4c285e6d'),(2,'ckeditor','4.0.6','3.0.0.0','2024-06-03 21:00:12','2024-06-03 21:00:12','2024-06-03 21:00:12','b10df6cd-e065-424d-90d9-ddb216d17645'),(4,'tungsten','4.0.0','1.0.0','2024-06-04 17:15:24','2024-06-04 17:15:24','2024-06-04 17:15:24','167e3f82-a3eb-4c6f-9495-9df8ff0f42e8'),(5,'expanded-singles','3.0.0','1.0.0','2024-06-05 13:52:03','2024-06-05 13:52:03','2024-06-05 13:52:03','94e4e47d-62b5-4150-bf46-8b4d909bcadf'),(6,'seomate','3.0.0-beta.6','1.0.0','2024-06-05 13:55:04','2024-06-05 13:55:04','2024-06-05 13:55:04','26ba0b22-2d79-4abe-850b-9887a37714d4'),(7,'field-manager','4.0.0','1.0.0','2024-06-05 14:10:14','2024-06-05 14:10:14','2024-06-05 14:10:14','d358912f-d465-4c44-bc19-b02875575038');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.headingLevels.0','2'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.headingLevels.1','3'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.headingLevels.2','4'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.name','\"Standard\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.0','\"createEntry\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.1','\"|\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.10','\"sourceEditing\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.2','\"heading\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.3','\"|\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.4','\"bold\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.5','\"italic\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.6','\"link\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.7','\"insertImage\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.8','\"mediaEmbed\"'),('ckeditor.configs.6c6f8774-f88b-4d21-b5db-035b04738b9d.toolbar.9','\"insertTable\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.0','1'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.1','2'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.2','3'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.3','4'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.4','5'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.headingLevels.5','6'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.name','\"Simple\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.toolbar.0','\"heading\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.toolbar.1','\"|\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.toolbar.2','\"bold\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.toolbar.3','\"italic\"'),('ckeditor.configs.bd2e5310-4895-4011-aed7-33022289b269.toolbar.4','\"link\"'),('dateModified','1717604223'),('elementSources.craft\\elements\\Entry.0.key','\"single:e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.heading','\"Structures\"'),('elementSources.craft\\elements\\Entry.1.type','\"heading\"'),('elementSources.craft\\elements\\Entry.2.defaultSort.0','\"structure\"'),('elementSources.craft\\elements\\Entry.2.defaultSort.1','\"asc\"'),('elementSources.craft\\elements\\Entry.2.disabled','false'),('elementSources.craft\\elements\\Entry.2.key','\"section:8f8af384-0f07-4623-8f6d-c54bde2fa965\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.0','\"postDate\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.1','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.2','\"authors\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Entry.2.type','\"native\"'),('elementSources.craft\\elements\\Entry.3.heading','\"\"'),('elementSources.craft\\elements\\Entry.3.type','\"heading\"'),('elementSources.craft\\elements\\Entry.4.key','\"*\"'),('elementSources.craft\\elements\\Entry.4.type','\"native\"'),('email.fromEmail','\"do-not-reply@nlcnet.net\"'),('email.fromName','\"Tungsten Craft CMS\"'),('email.replyToEmail','null'),('email.template','\"\"'),('email.transportSettings.host','\"smtp.mailtrap.io\"'),('email.transportSettings.password','\"d71536ab6f53c0\"'),('email.transportSettings.port','\"25\"'),('email.transportSettings.useAuthentication','\"1\"'),('email.transportSettings.username','\"4842f51c3d4591\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Smtp\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.color','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elementCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocapitalize','true'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocomplete','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.autocorrect','true'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.class','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.disabled','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.elementCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.id','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.includeInCards','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.inputType','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.instructions','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.label','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.max','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.min','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.name','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.orientation','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.placeholder','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.providesThumbs','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.readonly','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.requirable','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.size','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.step','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.tip','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.title','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.uid','\"b6c29a05-dbe3-4e10-baec-1621b25d687c\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.userCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.warning','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.elements.0.width','100'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.name','\"Content\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.uid','\"bb924369-6130-4e46-9d71-8c9cdebfd397\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.fieldLayouts.ddfb89b0-1589-4959-8e98-d2c7b81aaebf.tabs.0.userCondition','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.handle','\"home\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.hasTitleField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.icon','\"house\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.name','\"Home Page\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.showSlugField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.showStatusField','false'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.slugTranslationKeyFormat','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.slugTranslationMethod','\"site\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleFormat','\"{section.name|raw}\"'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleTranslationKeyFormat','null'),('entryTypes.0ed79961-f5ad-4469-bd11-abcf7a9afd71.titleTranslationMethod','\"site\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.color','\"purple\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elementCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.autocapitalize','true'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.autocomplete','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.autocorrect','true'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.class','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.disabled','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.elementCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.id','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.inputType','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.max','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.min','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.name','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.orientation','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.placeholder','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.readonly','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.requirable','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.size','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.step','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.title','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.uid','\"3b4de434-26dd-4b8b-8980-466ef50ea0cb\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.0.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.elementCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.fieldUid','\"83aa0b48-9a9a-4704-a405-7622485a2ee6\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.handle','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.required','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.uid','\"8a3e7279-eb49-4331-a669-34d48b31c79c\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.1.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.elementCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.fieldUid','\"8d317a03-dd86-4bd3-8aa9-90e87fa5e077\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.handle','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.required','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.uid','\"1b6c7209-a337-4255-b3dc-a262768a2d60\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.2.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\OptionsFieldConditionRule\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.fieldUid','\"8d317a03-dd86-4bd3-8aa9-90e87fa5e077\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.layoutElementUid','\"1b6c7209-a337-4255-b3dc-a262768a2d60\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.operator','\"in\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.uid','\"ac59a797-83cd-4489-8660-be8750cdfd8c\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.conditionRules.0.values.0','\"custom\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.elementCondition.fieldContext','\"global\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.fieldUid','\"d7bfb071-e404-4dce-b616-54d08eb40e11\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.handle','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.required','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.uid','\"c3cb2fdf-1aed-4e14-bf2f-f4107da3ff73\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.3.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.elementCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.fieldUid','\"275acf99-1424-4755-b9da-e515727f036f\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.handle','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.required','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.uid','\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.4.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\OptionsFieldConditionRule\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.fieldUid','\"275acf99-1424-4755-b9da-e515727f036f\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.layoutElementUid','\"12fb1e10-9f6f-4acb-aba8-789f107b07b0\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.operator','\"in\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.uid','\"c6d6f3cb-aec4-4922-9cd1-1f36d06ea062\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.conditionRules.0.values.0','\"custom\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.elementCondition.fieldContext','\"global\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.fieldUid','\"d0d661f3-3c1c-4c9d-9108-a3fa916ba6af\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.handle','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.includeInCards','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.instructions','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.label','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.providesThumbs','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.required','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.tip','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.uid','\"56b74f68-7c6c-497f-8985-80369a20d040\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.warning','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.elements.5.width','100'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.name','\"Content\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.uid','\"0ab7bd21-26bd-40cf-895a-d6e4069236c8\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.fieldLayouts.f79bcaf8-131a-483a-a751-e81a0c0161cf.tabs.0.userCondition','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.handle','\"divider\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.hasTitleField','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.icon','\"horizontal-rule\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.name','\"Divider\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.showSlugField','false'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.showStatusField','true'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.slugTranslationKeyFormat','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.slugTranslationMethod','\"site\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.titleFormat','\"{visible ? \'Visible\' : \'Hidden\'} - Space above: {spaceAbove} - Space below: {spaceBelow}\"'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.titleTranslationKeyFormat','null'),('entryTypes.15de76f8-38e3-4f91-9c3c-d7bf1a841274.titleTranslationMethod','\"site\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.color','\"orange\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocapitalize','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocomplete','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.autocorrect','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.class','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.disabled','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.id','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.includeInCards','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.inputType','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.instructions','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.label','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.max','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.min','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.name','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.orientation','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.placeholder','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.providesThumbs','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.readonly','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.requirable','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.size','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.step','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.tip','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.title','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.uid','\"c13e5054-6b16-4c50-843b-42e34b26b633\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.warning','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.0.width','100'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.elementCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.fieldUid','\"2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.handle','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.includeInCards','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.instructions','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.label','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.providesThumbs','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.required','false'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.tip','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.uid','\"0fe8496a-4fa5-4bc4-994a-f11493f1c911\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.warning','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.elements.1.width','100'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.name','\"Content\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.uid','\"76130222-c605-495f-9479-62494df13443\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.fieldLayouts.70209356-2464-4ee7-9bc0-dcdb0fdad870.tabs.0.userCondition','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.handle','\"pageRedirect\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.hasTitleField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.icon','\"arrows-rotate\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.name','\"Page Redirect\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.showSlugField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.showStatusField','true'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.slugTranslationKeyFormat','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.slugTranslationMethod','\"site\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleFormat','\"\"'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleTranslationKeyFormat','null'),('entryTypes.39b18b62-f3cf-48e0-8827-95bb425853de.titleTranslationMethod','\"site\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.color','\"purple\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elementCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.autocapitalize','true'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.autocomplete','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.autocorrect','true'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.class','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.disabled','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.elementCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.id','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.includeInCards','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.inputType','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.instructions','\"Please describe what type of embed is this and/or what is its purpose (e.g. YouTube Video)\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.label','\"Embed type\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.max','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.min','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.name','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.orientation','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.placeholder','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.providesThumbs','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.readonly','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.requirable','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.size','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.step','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.tip','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.title','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.uid','\"b96d3d8d-1e92-4bfa-b8c4-4e29f0e23fa8\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.userCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.warning','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.0.width','100'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.elementCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.fieldUid','\"40cffa1a-cd1e-4729-9196-f4f7cb49b510\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.handle','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.includeInCards','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.instructions','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.label','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.providesThumbs','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.required','true'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.tip','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.uid','\"deb35a50-a7c0-4d90-ab01-2c07189845aa\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.userCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.warning','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.elements.1.width','100'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.name','\"Content\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.uid','\"148f94dc-c131-4c15-9fa9-14200c99f44a\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.fieldLayouts.96f43348-64ba-40e0-aa42-ea0eecfcc154.tabs.0.userCondition','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.handle','\"embed\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.hasTitleField','true'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.icon','\"code\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.name','\"Embed\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.showSlugField','false'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.showStatusField','true'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.slugTranslationKeyFormat','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.slugTranslationMethod','\"site\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.titleFormat','\"\"'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.titleTranslationKeyFormat','null'),('entryTypes.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc.titleTranslationMethod','\"site\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.color','\"orange\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocomplete','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.autocorrect','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.class','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.disabled','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.id','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.inputType','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.max','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.min','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.name','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.orientation','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.placeholder','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.readonly','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.requirable','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.size','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.step','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.title','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.uid','\"380e9145-1057-4ab4-af19-8fc1e14729f4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.0.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.fieldUid','\"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.uid','\"ee17bf72-cb79-4f5e-b69f-759cd76c410a\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.1.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.fieldUid','\"f8b138be-9608-4b14-91eb-d59aa08a08c4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.uid','\"3284bdd5-e0be-4e3e-bc85-ceec41d39ff6\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.elements.2.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.name','\"Content\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.uid','\"b8c8b803-6d27-479c-9c86-bb1e72980a97\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.fieldUid','\"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.uid','\"f2ed8621-590e-46a4-8f2c-e2b7474e8fbd\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.0.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.uid','\"062ecb07-e4e4-47b1-bb1a-efa6804fba22\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.1.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.uid','\"cc63830f-0573-4479-97a2-3ffc74e0baf4\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.2.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.elementCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.handle','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.includeInCards','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.instructions','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.label','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.providesThumbs','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.required','false'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.tip','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.uid','\"89ca2926-2ebf-4689-9fac-a603b9a43272\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.warning','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.elements.3.width','100'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.name','\"SEO\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.uid','\"612e4c86-ec48-454e-850a-c18fdad32d29\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.fieldLayouts.637041b3-51c9-40b8-b376-0cd68ccf1c52.tabs.1.userCondition','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.handle','\"indexPage\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.hasTitleField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.icon','\"list\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.name','\"Index Page\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.showSlugField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.showStatusField','true'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.slugTranslationKeyFormat','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.slugTranslationMethod','\"site\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleFormat','\"\"'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleTranslationKeyFormat','null'),('entryTypes.7c32c045-0976-46d4-a6cb-9748ae189379.titleTranslationMethod','\"site\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.color','\"purple\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elementCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.autocapitalize','true'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.autocomplete','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.autocorrect','true'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.class','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.disabled','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.elementCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.id','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.includeInCards','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.inputType','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.instructions','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.label','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.max','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.min','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.name','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.orientation','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.placeholder','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.providesThumbs','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.readonly','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.requirable','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.size','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.step','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.tip','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.title','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.uid','\"70dc51bd-15c6-4992-a6d8-22ea46a721cd\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.userCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.warning','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.0.width','100'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.elementCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.fieldUid','\"c70b1406-454c-4f9c-a5e6-5baf68193177\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.handle','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.includeInCards','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.instructions','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.label','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.providesThumbs','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.required','true'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.tip','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.uid','\"5841ffe1-e774-4771-9d77-8134e04bd2ac\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.userCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.warning','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.1.width','100'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.elementCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.fieldUid','\"9f75bf48-5103-49fe-bee5-7d016b7a7c00\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.handle','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.includeInCards','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.instructions','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.label','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.providesThumbs','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.required','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.tip','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.uid','\"5f0aebc1-82b2-41e4-9425-279580bc9d3b\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.userCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.warning','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.2.width','100'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.elementCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.fieldUid','\"c6cd16bc-aa04-46fd-b6fe-628216e7e8c8\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.handle','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.includeInCards','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.instructions','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.label','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.providesThumbs','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.required','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.tip','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.uid','\"6b35829f-d82f-4e26-8b33-1da55ef11648\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.userCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.warning','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.elements.3.width','100'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.name','\"Content\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.uid','\"9eb0863a-c9d5-456b-a70b-c0a894ec77a7\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.fieldLayouts.4ead87b3-a9f6-4bde-be90-7b64ceb2bd8c.tabs.0.userCondition','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.handle','\"documents\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.hasTitleField','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.icon','\"file\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.name','\"Documents\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.showSlugField','false'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.showStatusField','true'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.slugTranslationKeyFormat','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.slugTranslationMethod','\"site\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.titleFormat','\"{documents.count} Document(s) - Display: {displayMode} - Show file size: {showFileSize ? \'Yes\' : \'No\'}\"'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.titleTranslationKeyFormat','null'),('entryTypes.a4797dec-412d-48c3-a4ae-60458e6a7110.titleTranslationMethod','\"site\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.color','\"orange\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocomplete','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.autocorrect','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.class','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.disabled','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.id','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.inputType','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.max','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.min','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.name','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.orientation','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.placeholder','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.readonly','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.requirable','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.size','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.step','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.title','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.uid','\"53e782d5-1589-4eef-971b-e7a79366df33\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.fieldUid','\"9ba82f61-ac54-4bfe-827b-e506e0d79ff6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.uid','\"3e41ff08-5719-4097-aa9e-d4c3a8268ed8\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.1.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.fieldUid','\"b4aac04f-9920-4cd9-b418-167317008cc9\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.uid','\"439d8587-b447-424f-a2aa-55d41dfc7d03\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.elements.2.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.name','\"Content\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.uid','\"afb666e8-faf6-44cd-84b9-4614053973fb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.fieldUid','\"f7e7cbc6-dbf6-4e59-9430-a7728d67524d\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.uid','\"8a179b1b-5cb4-45d7-9db5-00ba9dbfcc10\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.name','\"Settings\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.uid','\"601c952a-0f95-412d-82d8-238aa80b0da6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.fieldUid','\"fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.uid','\"ae9d5244-7717-481b-8186-55347020a03f\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.0.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.uid','\"83694166-ca67-4e8e-ac13-c5f9cab067bb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.1.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.uid','\"a0dc1d7a-907b-4847-95cc-b2904523aca6\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.2.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.elementCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.handle','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.includeInCards','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.instructions','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.label','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.providesThumbs','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.required','false'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.tip','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.uid','\"ee31c04b-d20a-4a5a-9e4e-3b8d99886c5e\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.warning','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.elements.3.width','100'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.name','\"SEO\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.uid','\"f5a163a9-f06c-4693-a109-eb4d0d343bbb\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.fieldLayouts.e899e415-7240-4604-9eee-f2e13d904cf1.tabs.2.userCondition','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.handle','\"defaultPage\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.hasTitleField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.icon','\"memo\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.name','\"Default Page\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.showSlugField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.showStatusField','true'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.slugTranslationKeyFormat','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.slugTranslationMethod','\"site\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleFormat','\"\"'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleTranslationKeyFormat','null'),('entryTypes.c678a4d3-15e8-4ea1-86d7-9b5206b7359e.titleTranslationMethod','\"site\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.color','\"purple\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.autocapitalize','true'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.autocomplete','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.autocorrect','true'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.class','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.disabled','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.id','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.inputType','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.max','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.min','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.name','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.orientation','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.placeholder','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.readonly','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.requirable','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.size','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.step','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.title','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.uid','\"f5e15e65-8fb4-4b24-a5c9-b8cb24317fb5\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.0.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.fieldUid','\"36550229-8708-4818-8d7e-38ac2cc5c716\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.handle','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.required','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.uid','\"cab8976e-d51f-4252-92cb-87790402a1cf\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.1.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.fieldUid','\"c43bfd3e-0cb3-4222-a355-edff142c41cc\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.handle','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.required','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.uid','\"2d9f81b3-3665-44b7-935a-c85a3bc9c490\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.2.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.fieldUid','\"d5cc3481-2797-4764-a74c-b7516866e8ec\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.handle','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.required','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.uid','\"6d02377d-9d38-46d1-84c4-07836f4bea30\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.3.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.fieldUid','\"799d449a-60ab-4566-87a2-badf0de0c1ec\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.handle','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.required','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.uid','\"9154ca2e-cd14-47ce-93f7-597e1eaaac53\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.4.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.elementCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.fieldUid','\"7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.handle','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.includeInCards','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.instructions','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.label','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.providesThumbs','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.required','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.tip','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.uid','\"b40963cc-fb78-4a85-9703-9dcd08ed5d91\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.warning','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.elements.5.width','100'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.name','\"Content\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.uid','\"eab38575-10f3-4db9-980b-aafe839eca8b\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.fieldLayouts.21207bb3-6dd3-4af9-a168-995011950a41.tabs.0.userCondition','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.handle','\"image\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.hasTitleField','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.icon','\"image\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.name','\"Image\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.showSlugField','false'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.showStatusField','true'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.slugTranslationKeyFormat','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.slugTranslationMethod','\"site\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.titleFormat','\"{image.one.title} - Size: {imageSize} - Border: {showBorder ? \'Yes\' : \'No\'}\"'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.titleTranslationKeyFormat','null'),('entryTypes.ca088dca-1d9b-4782-8007-3c66a30e5d3b.titleTranslationMethod','\"site\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.columnSuffix','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.handle','\"themeSettings\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.instructions','\"Adjust the **Theme Level Settings** that control some of the content related functionality.\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.name','\"Theme Settings\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.searchable','false'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.addRowLabel','\"Add a setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.0','\"col1\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.0.0','\"heading\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.0.1','\"Setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.1.0','\"handle\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.1.1','\"setting\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.2.0','\"width\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.3.0','\"type\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.0.1.__assoc__.3.1','\"singleline\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.0','\"col2\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.0.0','\"heading\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.0.1','\"Value\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.1.0','\"handle\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.1.1','\"value\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.2.0','\"width\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.2.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.3.0','\"type\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.columns.__assoc__.1.1.__assoc__.3.1','\"singleline\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.0.0','\"col1\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.0.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.1.0','\"col2\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.defaults.0.__assoc__.1.1','\"\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.maxRows','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.minRows','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.settings.staticRows','false'),('fields.052856f0-029e-4ecc-991b-f81833a59830.translationKeyFormat','null'),('fields.052856f0-029e-4ecc-991b-f81833a59830.translationMethod','\"none\"'),('fields.052856f0-029e-4ecc-991b-f81833a59830.type','\"craft\\\\fields\\\\Table\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.columnSuffix','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.handle','\"twitterHandle\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.instructions','\"Your Twitter Handle, without the preceding @ This must be set for Twitter Card tags to be generated.\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.name','\"Twitter Handle\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.searchable','true'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.byteLimit','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.charLimit','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.code','true'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.initialRows','4'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.multiline','false'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.placeholder','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.settings.uiMode','\"normal\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.translationKeyFormat','null'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.translationMethod','\"none\"'),('fields.105168a3-16f3-4b59-94dd-8ee954442a3e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.columnSuffix','null'),('fields.275acf99-1424-4755-b9da-e515727f036f.handle','\"spaceBelow\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.instructions','null'),('fields.275acf99-1424-4755-b9da-e515727f036f.name','\"Space Below\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.searchable','false'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.0.0','\"label\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.0.1','\"Smaller\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.1.0','\"value\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.1.1','\"smaller\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.2.0','\"default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.0.__assoc__.2.1','\"\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.0.0','\"label\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.0.1','\"Default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.1.0','\"value\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.1.1','\"default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.2.0','\"default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.1.__assoc__.2.1','\"1\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.0.0','\"label\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.0.1','\"Larger\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.1.0','\"value\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.1.1','\"larger\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.2.0','\"default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.2.__assoc__.2.1','\"\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.0.0','\"label\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.0.1','\"Custom\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.1.0','\"value\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.1.1','\"custom\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.2.0','\"default\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.settings.options.3.__assoc__.2.1','\"\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.translationKeyFormat','null'),('fields.275acf99-1424-4755-b9da-e515727f036f.translationMethod','\"none\"'),('fields.275acf99-1424-4755-b9da-e515727f036f.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.columnSuffix','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.handle','\"redirectStatusCode\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.instructions','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.name','\"Redirect Status Code\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.searchable','false'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.0.0','\"label\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.0.1','\"Permanent Redirect (301)\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.1.0','\"value\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.1.1','\"301\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.2.0','\"default\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.0.__assoc__.2.1','\"1\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.0.0','\"label\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.0.1','\"Temporary Redirect (302)\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.1.0','\"value\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.1.1','\"302\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.2.0','\"default\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.settings.options.1.__assoc__.2.1','\"\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.translationKeyFormat','null'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.translationMethod','\"none\"'),('fields.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9.type','\"craft\\\\fields\\\\RadioButtons\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.columnSuffix','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.handle','\"image\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.instructions','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.name','\"Image\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.searchable','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.allowedKinds.0','\"image\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.allowSelfRelations','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.allowSubfolders','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.allowUploads','true'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.branchLimit','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.defaultUploadLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.defaultUploadLocationSubpath','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.localizeRelations','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.maintainHierarchy','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.maxRelations','1'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.minRelations','1'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.previewMode','\"full\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.restrictedDefaultUploadSubpath','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.restrictedLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.restrictedLocationSubpath','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.restrictFiles','true'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.restrictLocation','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.selectionLabel','\"Select an image\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.showCardsInGrid','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.showSiteMenu','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.showUnpermittedFiles','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.showUnpermittedVolumes','true'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.sources.0','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.targetSiteId','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.validateRelatedElements','false'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.settings.viewMode','\"large\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.translationKeyFormat','null'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.translationMethod','\"site\"'),('fields.36550229-8708-4818-8d7e-38ac2cc5c716.type','\"craft\\\\fields\\\\Assets\"'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.columnSuffix','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.handle','\"embedCode\"'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.instructions','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.name','\"Embed Code\"'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.searchable','false'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.byteLimit','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.charLimit','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.code','true'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.initialRows','4'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.multiline','true'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.placeholder','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.settings.uiMode','\"normal\"'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.translationKeyFormat','null'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.translationMethod','\"none\"'),('fields.40cffa1a-cd1e-4729-9196-f4f7cb49b510.type','\"craft\\\\fields\\\\PlainText\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.columnSuffix','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.handle','\"facebookHandle\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.instructions','\"Your Facebook company/fan page handle (the part after https://www.facebook.com/)\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.name','\"Facebook Handle\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.searchable','true'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.byteLimit','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.charLimit','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.code','false'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.initialRows','4'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.multiline','false'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.placeholder','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.settings.uiMode','\"normal\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.translationKeyFormat','null'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.translationMethod','\"none\"'),('fields.5410b80a-d2c8-4d87-bce0-7e047145966d.type','\"craft\\\\fields\\\\PlainText\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.columnSuffix','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.handle','\"assetDescription\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.instructions','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.name','\"Asset Description\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.searchable','true'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.byteLimit','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.charLimit','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.code','false'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.initialRows','4'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.multiline','false'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.placeholder','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.settings.uiMode','\"normal\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.translationKeyFormat','null'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.translationMethod','\"none\"'),('fields.5ccb7ad3-87b2-4106-946c-43f35b45b73b.type','\"craft\\\\fields\\\\PlainText\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.columnSuffix','null'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.handle','\"seoRobots\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.instructions','\"Tell the search engine crawlers what you want them to do with this page.\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.name','\"SEO Robots\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.searchable','false'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.0.0','\"label\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.0.1','\"Indexing is allowed\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.1.0','\"value\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.1.1','\"all\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.2.0','\"default\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.0.__assoc__.2.1','\"1\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.0.0','\"label\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.0.1','\"Indexing is NOT allowed\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.1.0','\"value\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.1.1','\"noindex, nofollow\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.2.0','\"default\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.settings.options.1.__assoc__.2.1','\"\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.translationKeyFormat','null'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.translationMethod','\"none\"'),('fields.62acfd63-f994-4bfc-b9a4-bf043f8772c5.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.columnSuffix','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.handle','\"seoDescription\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.instructions','\"The SEO Description should be between 70 and 160 characters (spaces included). Meta descriptions allow you to influence how your web pages are described and displayed in search results. Ensure that all of your web pages have a unique meta description that is explicit and contains your most important keywords.\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.name','\"SEO Description\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.searchable','true'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.byteLimit','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.charLimit','160'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.code','false'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.initialRows','3'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.multiline','true'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.placeholder','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.settings.uiMode','\"normal\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.translationKeyFormat','null'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.translationMethod','\"none\"'),('fields.767e7a13-0040-4850-ab89-81ebe26655fc.type','\"craft\\\\fields\\\\PlainText\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.columnSuffix','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.handle','\"caption\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.instructions','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.name','\"Caption\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.searchable','true'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.byteLimit','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.charLimit','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.code','false'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.initialRows','4'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.multiline','false'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.placeholder','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.settings.uiMode','\"normal\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.translationKeyFormat','null'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.translationMethod','\"none\"'),('fields.799d449a-60ab-4566-87a2-badf0de0c1ec.type','\"craft\\\\fields\\\\PlainText\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.columnSuffix','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.handle','\"analyticsId\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.instructions','\"If you enter your Google Analytics Tracking ID here, the Google Analytics script tags will be included in your <head> (the script is not included if devMode is on or during Live Preview). Only enter the ID, e.g.: UA-XXXXXX-XX, not the entire script code. [Here\'s how to get it](https://support.google.com/analytics/answer/1032385?hl=en).\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.name','\"Google Analytics Tracking ID\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.searchable','false'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.byteLimit','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.charLimit','15'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.code','true'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.initialRows','4'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.multiline','false'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.placeholder','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.settings.uiMode','\"normal\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.translationKeyFormat','null'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.translationMethod','\"none\"'),('fields.7ab49e1d-8c4e-4b01-b832-02d8c69746ef.type','\"craft\\\\fields\\\\PlainText\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.columnSuffix','null'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.handle','\"showBorder\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.instructions','null'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.name','\"Show Border\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.searchable','false'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.settings.default','false'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.settings.offLabel','\"NO\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.settings.onLabel','\"YES\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.translationKeyFormat','null'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.translationMethod','\"none\"'),('fields.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.columnSuffix','null'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.handle','\"visible\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.instructions','null'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.name','\"Visible\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.searchable','false'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.settings.default','true'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.settings.offLabel','\"NO\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.settings.onLabel','\"YES\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.translationKeyFormat','null'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.translationMethod','\"none\"'),('fields.83aa0b48-9a9a-4704-a405-7622485a2ee6.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.columnSuffix','null'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.handle','\"spaceAbove\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.instructions','null'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.name','\"Space Above\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.searchable','false'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.0.0','\"label\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.0.1','\"Smaller\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.1.0','\"value\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.1.1','\"smaller\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.2.0','\"default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.0.__assoc__.2.1','\"\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.0.0','\"label\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.0.1','\"Default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.1.0','\"value\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.1.1','\"default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.2.0','\"default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.1.__assoc__.2.1','\"1\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.0.0','\"label\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.0.1','\"Larger\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.1.0','\"value\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.1.1','\"larger\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.2.0','\"default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.2.__assoc__.2.1','\"\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.0.0','\"label\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.0.1','\"Custom\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.1.0','\"value\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.1.1','\"custom\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.2.0','\"default\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.settings.options.3.__assoc__.2.1','\"\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.translationKeyFormat','null'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.translationMethod','\"none\"'),('fields.8d317a03-dd86-4bd3-8aa9-90e87fa5e077.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.columnSuffix','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.handle','\"pageHeading\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.instructions','\"Specify a main heading for the page. The **Page Title** will be used by default if you leave this empty.\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.name','\"Page Heading\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.searchable','true'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.byteLimit','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.charLimit','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.code','false'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.initialRows','4'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.multiline','false'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.placeholder','\"Leave empty if same as Page Title\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.settings.uiMode','\"normal\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.translationKeyFormat','null'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.translationMethod','\"none\"'),('fields.9ba82f61-ac54-4bfe-827b-e506e0d79ff6.type','\"craft\\\\fields\\\\PlainText\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.columnSuffix','null'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.handle','\"displayMode\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.instructions','null'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.name','\"Display Mode\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.searchable','false'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.0.0','\"label\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.0.1','\"Listing\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.1.0','\"value\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.1.1','\"listing\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.2.0','\"default\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.0.__assoc__.2.1','\"1\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.0.0','\"label\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.0.1','\"Cards\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.1.0','\"value\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.1.1','\"cards\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.2.0','\"default\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.settings.options.1.__assoc__.2.1','\"\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.translationKeyFormat','null'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.translationMethod','\"none\"'),('fields.9f75bf48-5103-49fe-bee5-7d016b7a7c00.type','\"craft\\\\fields\\\\RadioButtons\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.columnSuffix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.handle','\"carouselInterval\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.instructions','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.name','\"Carousel Interval\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.searchable','false'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.decimals','0'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.defaultValue','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.max','10'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.min','0'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.prefix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.previewCurrency','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.previewFormat','\"decimal\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.size','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.settings.suffix','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.translationKeyFormat','null'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.translationMethod','\"none\"'),('fields.a290cd19-1afc-4081-b7a5-d4f57e022734.type','\"craft\\\\fields\\\\Number\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.columnSuffix','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.handle','\"mainContent\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.instructions','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.name','\"Main Content\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.searchable','true'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.availableTransforms','\"\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.availableVolumes','\"*\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.ckeConfig','\"6c6f8774-f88b-4d21-b5db-035b04738b9d\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.createButtonLabel','\"+ Block\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.defaultTransform','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.enableSourceEditingForNonAdmins','false'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.entryTypes.0','\"ca088dca-1d9b-4782-8007-3c66a30e5d3b\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.entryTypes.1','\"15de76f8-38e3-4f91-9c3c-d7bf1a841274\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.entryTypes.2','\"a4797dec-412d-48c3-a4ae-60458e6a7110\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.entryTypes.3','\"527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.purifierConfig','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.purifyHtml','true'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.showUnpermittedFiles','false'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.showUnpermittedVolumes','false'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.showWordCount','false'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.settings.wordLimit','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.translationKeyFormat','null'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.translationMethod','\"none\"'),('fields.b4aac04f-9920-4cd9-b418-167317008cc9.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.columnSuffix','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.handle','\"seoImage\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.instructions','\"The image that should be used to represent this page\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.name','\"SEO Image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.searchable','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowedKinds.0','\"image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowSelfRelations','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowSubfolders','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.allowUploads','true'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.branchLimit','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.defaultUploadLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.defaultUploadLocationSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.localizeRelations','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.maintainHierarchy','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.maxRelations','1'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.minRelations','0'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.previewMode','\"full\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedDefaultUploadSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictedLocationSubpath','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictFiles','true'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.restrictLocation','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.selectionLabel','\"Select an image\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showCardsInGrid','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showSiteMenu','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showUnpermittedFiles','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.showUnpermittedVolumes','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.sources.0','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.targetSiteId','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.validateRelatedElements','false'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.settings.viewMode','\"large\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.translationKeyFormat','null'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.translationMethod','\"site\"'),('fields.c425ab9e-58a3-470e-92eb-b2accecd2325.type','\"craft\\\\fields\\\\Assets\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.columnSuffix','null'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.handle','\"alignment\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.instructions','null'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.name','\"Alignment\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.searchable','false'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.0.0','\"label\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.0.1','\"Left\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.1.0','\"value\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.1.1','\"left\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.2.0','\"default\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.0.__assoc__.2.1','\"1\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.0.0','\"label\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.0.1','\"Center\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.1.0','\"value\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.1.1','\"center\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.2.0','\"default\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.1.__assoc__.2.1','\"\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.0.0','\"label\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.0.1','\"right\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.1.0','\"value\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.1.1','\"right\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.2.0','\"default\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.settings.options.2.__assoc__.2.1','\"\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.translationKeyFormat','null'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.translationMethod','\"none\"'),('fields.c43bfd3e-0cb3-4222-a355-edff142c41cc.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.columnSuffix','null'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.handle','\"showFileSize\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.instructions','null'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.name','\"Show File Size\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.searchable','false'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.settings.default','false'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.settings.offLabel','\"No\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.settings.onLabel','\"YES\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.translationKeyFormat','null'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.translationMethod','\"none\"'),('fields.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.columnSuffix','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.handle','\"documents\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.instructions','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.name','\"Documents\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.searchable','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.allowedKinds','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.allowSelfRelations','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.allowSubfolders','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.allowUploads','true'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.branchLimit','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.defaultUploadLocationSource','\"volume:8e0e1072-3f93-4df7-a31d-e4f06eb6277f\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.defaultUploadLocationSubpath','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.localizeRelations','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.maintainHierarchy','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.maxRelations','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.minRelations','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.previewMode','\"full\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.restrictedDefaultUploadSubpath','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.restrictedLocationSource','\"volume:c12539e4-fc26-48ee-a298-47488a5a82e0\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.restrictedLocationSubpath','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.restrictFiles','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.restrictLocation','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.selectionLabel','\"Add documents\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.showCardsInGrid','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.showSiteMenu','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.showUnpermittedFiles','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.showUnpermittedVolumes','true'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.sources','\"*\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.targetSiteId','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.validateRelatedElements','false'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.settings.viewMode','\"list\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.translationKeyFormat','null'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.translationMethod','\"site\"'),('fields.c70b1406-454c-4f9c-a5e6-5baf68193177.type','\"craft\\\\fields\\\\Assets\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.columnSuffix','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.handle','\"spaceBelowCustom\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.instructions','\"Specify the amount of space below the divider if you selected **Other** above.\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.name','\"Space Below (Custom)\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.searchable','false'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.decimals','0'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.defaultValue','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.max','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.min','0'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.prefix','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.previewCurrency','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.previewFormat','\"decimal\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.size','3'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.settings.suffix','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.translationKeyFormat','null'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.translationMethod','\"none\"'),('fields.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af.type','\"craft\\\\fields\\\\Number\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.columnSuffix','null'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.handle','\"imageSize\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.instructions','null'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.name','\"Image Size\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.searchable','false'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.0.0','\"label\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.0.1','\"Thumbnail\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.1.0','\"value\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.1.1','\"imageThumbnail\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.2.0','\"default\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.0.__assoc__.2.1','\"\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.0.0','\"label\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.0.1','\"Small\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.1.0','\"value\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.1.1','\"imageSmall\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.2.0','\"default\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.1.__assoc__.2.1','\"\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.0.0','\"label\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.0.1','\"Medium\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.1.0','\"value\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.1.1','\"imageMedium\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.2.0','\"default\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.2.__assoc__.2.1','\"1\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.0.0','\"label\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.0.1','\"Large\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.1.0','\"value\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.1.1','\"imageLarge\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.2.0','\"default\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.3.__assoc__.2.1','\"\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.0.0','\"label\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.0.1','\"Full Width\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.1.0','\"value\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.1.1','\"imageFull\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.2.0','\"default\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.settings.options.4.__assoc__.2.1','\"\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.translationKeyFormat','null'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.translationMethod','\"none\"'),('fields.d5cc3481-2797-4764-a74c-b7516866e8ec.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.columnSuffix','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.handle','\"spaceAboveCustom\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.instructions','\"Specify the amount of space above the divider if you selected **Other** above.\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.name','\"Space Above (Custom)\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.searchable','false'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.decimals','0'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.defaultValue','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.max','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.min','0'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.prefix','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.previewCurrency','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.previewFormat','\"decimal\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.size','3'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.settings.suffix','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.translationKeyFormat','null'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.translationMethod','\"none\"'),('fields.d7bfb071-e404-4dce-b616-54d08eb40e11.type','\"craft\\\\fields\\\\Number\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.columnSuffix','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.handle','\"mainNavigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.instructions','\"Select the entries that should appear in main navigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.name','\"Main Navigation\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.searchable','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.allowSelfRelations','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.branchLimit','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.localizeRelations','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.maintainHierarchy','true'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.maxRelations','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.minRelations','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.selectionLabel','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.showCardsInGrid','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.showSiteMenu','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.sources.0','\"section:8f8af384-0f07-4623-8f6d-c54bde2fa965\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.targetSiteId','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.validateRelatedElements','false'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.settings.viewMode','\"list\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.translationKeyFormat','null'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.translationMethod','\"site\"'),('fields.e64a9101-f277-49ae-8a14-3b3d9d77d8e3.type','\"craft\\\\fields\\\\Entries\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.columnSuffix','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.handle','\"hideSidebar\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.instructions','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.name','\"Hide Sidebar\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.searchable','false'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.default','false'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.offLabel','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.settings.onLabel','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.translationKeyFormat','null'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.translationMethod','\"none\"'),('fields.f7e7cbc6-dbf6-4e59-9430-a7728d67524d.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.columnSuffix','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.handle','\"sectionTemplateFolder\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.instructions','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.name','\"Section Template Folder\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.searchable','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.byteLimit','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.charLimit','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.code','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.initialRows','4'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.multiline','false'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.placeholder','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.settings.uiMode','\"normal\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.translationKeyFormat','null'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.translationMethod','\"none\"'),('fields.f8b138be-9608-4b14-91eb-d59aa08a08c4.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.columnSuffix','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.handle','\"alternativeText\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.instructions','\"This text is used within an HTML code to describe the appearance and function of an image on a page.\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.name','\"Alternative Text\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.searchable','true'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.byteLimit','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.charLimit','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.code','false'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.initialRows','4'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.multiline','false'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.placeholder','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.settings.uiMode','\"normal\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.translationKeyFormat','null'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.translationMethod','\"none\"'),('fields.fbc6e983-4336-4480-89fa-9084069c848c.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.columnSuffix','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.handle','\"seoTitle\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.instructions','\"The SEO Title should be between 10 and 70 characters (spaces included). Make sure your title tag is explicit and contains your most important keywords. Be sure that each page has a unique title tag. The siteSeoName length is subtracted from the 70 character limit automatically, since it is appended to the seoTitle.\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.name','\"SEO Title\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.searchable','true'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.byteLimit','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.charLimit','70'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.code','false'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.initialRows','4'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.multiline','false'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.placeholder','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.settings.uiMode','\"normal\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.translationKeyFormat','null'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.translationMethod','\"none\"'),('fields.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c.type','\"craft\\\\fields\\\\PlainText\"'),('fs.nlcCraftSitesAssets.hasUrls','true'),('fs.nlcCraftSitesAssets.name','\"NLC Craft Sites Assets\"'),('fs.nlcCraftSitesAssets.settings.addSubfolderToRootUrl','true'),('fs.nlcCraftSitesAssets.settings.autoFocalPoint','false'),('fs.nlcCraftSitesAssets.settings.bucket','\"$S3_BUCKET\"'),('fs.nlcCraftSitesAssets.settings.bucketSelectionMode','\"manual\"'),('fs.nlcCraftSitesAssets.settings.cfDistributionId','\"$CLOUDFRONT_DISTRIBUTION_ID\"'),('fs.nlcCraftSitesAssets.settings.cfPrefix','\"$CLOUDFRONT_PATH_PREFIX\"'),('fs.nlcCraftSitesAssets.settings.expires','\"3 months\"'),('fs.nlcCraftSitesAssets.settings.keyId','\"$S3_API_KEY\"'),('fs.nlcCraftSitesAssets.settings.makeUploadsPublic','false'),('fs.nlcCraftSitesAssets.settings.region','\"$S3_REGION\"'),('fs.nlcCraftSitesAssets.settings.secret','\"$S3_SECRET\"'),('fs.nlcCraftSitesAssets.settings.storageClass','\"\"'),('fs.nlcCraftSitesAssets.settings.subfolder','\"craft5base\"'),('fs.nlcCraftSitesAssets.type','\"craft\\\\awss3\\\\Fs\"'),('fs.nlcCraftSitesAssets.url','\"$CLOUDFRONT_URL\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.fieldUid','\"e64a9101-f277-49ae-8a14-3b3d9d77d8e3\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.uid','\"0b185442-deae-4531-804f-66be9f89ddcd\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.elements.0.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.name','\"Navigation\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.uid','\"3aa11335-95bb-45ed-aa78-fa3f3b364186\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.fieldUid','\"105168a3-16f3-4b59-94dd-8ee954442a3e\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.uid','\"a3b5eb47-2bb7-4145-aef0-2ed1ccd678af\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.0.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.elementCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.fieldUid','\"5410b80a-d2c8-4d87-bce0-7e047145966d\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.handle','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.includeInCards','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.instructions','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.label','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.providesThumbs','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.required','false'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.tip','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.uid','\"6bbe5cb3-b44e-4193-87cf-df55bde45db1\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.warning','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.elements.1.width','100'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.name','\"Social Media\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.uid','\"6dade7bd-d1ae-4b9f-9e39-afc7c7cee0ab\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.fieldLayouts.5188c82f-e10c-48f8-8f78-cf5a182befed.tabs.1.userCondition','null'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.handle','\"siteOptions\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.name','\"Site Options\"'),('globalSets.7073c177-69ef-4762-8e87-a215481a3504.sortOrder','2'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.fieldUid','\"767e7a13-0040-4850-ab89-81ebe26655fc\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.uid','\"a1e70cc1-3f73-4944-871c-26a69529c0ac\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.0.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.fieldUid','\"c425ab9e-58a3-470e-92eb-b2accecd2325\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.uid','\"0b9fb8ec-a4b4-4921-9c50-fd4b135ef2c1\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.elements.1.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.name','\"Site SEO\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.uid','\"9ef2366e-542c-40cc-a3f4-4eee419142c6\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.fieldUid','\"7ab49e1d-8c4e-4b01-b832-02d8c69746ef\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.uid','\"bfa35e87-c45b-4b39-ac22-6dec8a4cf772\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.0.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.elementCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.fieldUid','\"62acfd63-f994-4bfc-b9a4-bf043f8772c5\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.handle','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.includeInCards','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.instructions','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.label','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.providesThumbs','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.required','false'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.tip','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.uid','\"c41cd145-6819-4d6d-b827-ddfe9e14f813\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.warning','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.elements.1.width','100'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.name','\"Technical SEO\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.uid','\"605d136e-a57c-46fa-8bc7-7e700a8a6ee8\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.fieldLayouts.8e48703c-752a-4eb7-8296-9948ee96e88f.tabs.1.userCondition','null'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.handle','\"seoSettings\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.name','\"SEO Settings\"'),('globalSets.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c.sortOrder','1'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elementCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.elementCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.fieldUid','\"052856f0-029e-4ecc-991b-f81833a59830\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.handle','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.includeInCards','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.instructions','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.label','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.providesThumbs','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.required','false'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.tip','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.uid','\"06fb32a9-2c98-48a8-a45b-97e613b191c0\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.userCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.warning','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.elements.0.width','100'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.name','\"Settings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.uid','\"5b03ec01-a79e-4143-b5a1-0027c0d18e6a\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.fieldLayouts.fe2036df-60f1-4282-9924-367184aa578e.tabs.0.userCondition','null'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.handle','\"siteSettings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.name','\"Site Settings\"'),('globalSets.e71097ea-8036-4ab5-8637-e9dca0771aad.sortOrder','3'),('graphql.schemas.6db79ffd-4500-4902-99a6-bb99e4a85c23.isPublic','true'),('graphql.schemas.6db79ffd-4500-4902-99a6-bb99e4a85c23.name','\"Public Schema\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.fill','null'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.format','null'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.handle','\"imageThumbnail\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.height','130'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.interlace','\"none\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.mode','\"fit\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.name','\"Image Thumbnail\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.position','\"center-center\"'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.quality','null'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.upscale','false'),('imageTransforms.31b7b597-22d9-48a5-833c-8a522c3a4b40.width','130'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.fill','null'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.format','null'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.handle','\"imageSmall\"'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.height','290'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.interlace','\"none\"'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.mode','\"fit\"'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.name','\"Image Small\"'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.position','\"center-center\"'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.quality','null'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.upscale','false'),('imageTransforms.5d81f0b0-8923-4fb3-9aab-c1e6f611baca.width','290'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.fill','null'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.format','null'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.handle','\"imageMedium\"'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.height','370'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.interlace','\"none\"'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.mode','\"fit\"'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.name','\"Image Medium\"'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.position','\"center-center\"'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.quality','null'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.upscale','false'),('imageTransforms.854cf04c-6962-4002-89fa-551e6ae91659.width','370'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.fill','null'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.format','null'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.handle','\"imageLarge\"'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.height','610'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.interlace','\"none\"'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.mode','\"fit\"'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.name','\"Image Large\"'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.position','\"center-center\"'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.quality','null'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.upscale','false'),('imageTransforms.87d6e9a5-3f0c-40cf-95fc-792962dcc5df.width','610'),('meta.__names__.052856f0-029e-4ecc-991b-f81833a59830','\"Theme Settings\"'),('meta.__names__.0ed79961-f5ad-4469-bd11-abcf7a9afd71','\"Home Page\"'),('meta.__names__.105168a3-16f3-4b59-94dd-8ee954442a3e','\"Twitter Handle\"'),('meta.__names__.15de76f8-38e3-4f91-9c3c-d7bf1a841274','\"Divider\"'),('meta.__names__.2451a2c9-f6e7-45ba-b21f-6ba54d9018d8','\"Craft5 Base\"'),('meta.__names__.275acf99-1424-4755-b9da-e515727f036f','\"Space Below\"'),('meta.__names__.2e6998f5-c6d8-40ec-9b6e-b7f6c1de8de9','\"Redirect Status Code\"'),('meta.__names__.31b7b597-22d9-48a5-833c-8a522c3a4b40','\"Image Thumbnail\"'),('meta.__names__.36550229-8708-4818-8d7e-38ac2cc5c716','\"Image\"'),('meta.__names__.39b18b62-f3cf-48e0-8827-95bb425853de','\"Page Redirect\"'),('meta.__names__.40cffa1a-cd1e-4729-9196-f4f7cb49b510','\"Embed Code\"'),('meta.__names__.527b1cd6-8a3d-4ea6-b91b-80cb77cbe4dc','\"Embed\"'),('meta.__names__.5410b80a-d2c8-4d87-bce0-7e047145966d','\"Facebook Handle\"'),('meta.__names__.5ccb7ad3-87b2-4106-946c-43f35b45b73b','\"Asset Description\"'),('meta.__names__.5d81f0b0-8923-4fb3-9aab-c1e6f611baca','\"Image Small\"'),('meta.__names__.62acfd63-f994-4bfc-b9a4-bf043f8772c5','\"SEO Robots\"'),('meta.__names__.6c6f8774-f88b-4d21-b5db-035b04738b9d','\"Standard\"'),('meta.__names__.6db79ffd-4500-4902-99a6-bb99e4a85c23','\"Public Schema\"'),('meta.__names__.7073c177-69ef-4762-8e87-a215481a3504','\"Site Options\"'),('meta.__names__.767e7a13-0040-4850-ab89-81ebe26655fc','\"SEO Description\"'),('meta.__names__.799d449a-60ab-4566-87a2-badf0de0c1ec','\"Caption\"'),('meta.__names__.7ab49e1d-8c4e-4b01-b832-02d8c69746ef','\"Google Analytics Tracking ID\"'),('meta.__names__.7c32c045-0976-46d4-a6cb-9748ae189379','\"Index Page\"'),('meta.__names__.7dfb6456-2059-4ce7-8d73-2a8bce3e9d8e','\"Show Border\"'),('meta.__names__.83aa0b48-9a9a-4704-a405-7622485a2ee6','\"Visible\"'),('meta.__names__.854cf04c-6962-4002-89fa-551e6ae91659','\"Image Medium\"'),('meta.__names__.87d6e9a5-3f0c-40cf-95fc-792962dcc5df','\"Image Large\"'),('meta.__names__.8d317a03-dd86-4bd3-8aa9-90e87fa5e077','\"Space Above\"'),('meta.__names__.8e0e1072-3f93-4df7-a31d-e4f06eb6277f','\"Documents\"'),('meta.__names__.8f8af384-0f07-4623-8f6d-c54bde2fa965','\"Pages\"'),('meta.__names__.9ba82f61-ac54-4bfe-827b-e506e0d79ff6','\"Page Heading\"'),('meta.__names__.9f75bf48-5103-49fe-bee5-7d016b7a7c00','\"Display Mode\"'),('meta.__names__.a290cd19-1afc-4081-b7a5-d4f57e022734','\"Carousel Interval\"'),('meta.__names__.a4797dec-412d-48c3-a4ae-60458e6a7110','\"Documents\"'),('meta.__names__.af7828ef-46d4-4c0f-8c6b-6c69dcf9aa7c','\"SEO Settings\"'),('meta.__names__.b4aac04f-9920-4cd9-b418-167317008cc9','\"Main Content\"'),('meta.__names__.bd2e5310-4895-4011-aed7-33022289b269','\"Simple\"'),('meta.__names__.c12539e4-fc26-48ee-a298-47488a5a82e0','\"Images\"'),('meta.__names__.c425ab9e-58a3-470e-92eb-b2accecd2325','\"SEO Image\"'),('meta.__names__.c43bfd3e-0cb3-4222-a355-edff142c41cc','\"Alignment\"'),('meta.__names__.c678a4d3-15e8-4ea1-86d7-9b5206b7359e','\"Default Page\"'),('meta.__names__.c6cd16bc-aa04-46fd-b6fe-628216e7e8c8','\"Show File Size\"'),('meta.__names__.c70b1406-454c-4f9c-a5e6-5baf68193177','\"Documents\"'),('meta.__names__.ca088dca-1d9b-4782-8007-3c66a30e5d3b','\"Image\"'),('meta.__names__.d0d661f3-3c1c-4c9d-9108-a3fa916ba6af','\"Space Below (Custom)\"'),('meta.__names__.d5cc3481-2797-4764-a74c-b7516866e8ec','\"Image Size\"'),('meta.__names__.d7bfb071-e404-4dce-b616-54d08eb40e11','\"Space Above (Custom)\"'),('meta.__names__.da2ec3b8-94ce-485b-8f32-4db302708c47','\"Craft5 Base\"'),('meta.__names__.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0','\"Home Page\"'),('meta.__names__.e64a9101-f277-49ae-8a14-3b3d9d77d8e3','\"Main Navigation\"'),('meta.__names__.e71097ea-8036-4ab5-8637-e9dca0771aad','\"Site Settings\"'),('meta.__names__.f7e7cbc6-dbf6-4e59-9430-a7728d67524d','\"Hide Sidebar\"'),('meta.__names__.f8b138be-9608-4b14-91eb-d59aa08a08c4','\"Section Template Folder\"'),('meta.__names__.fbc6e983-4336-4480-89fa-9084069c848c','\"Alternative Text\"'),('meta.__names__.fe08e72b-9b20-4df9-b5ea-e1a21dcaf69c','\"SEO Title\"'),('plugins.aws-s3.edition','\"standard\"'),('plugins.aws-s3.enabled','true'),('plugins.aws-s3.schemaVersion','\"2.0\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.expanded-singles.edition','\"standard\"'),('plugins.expanded-singles.enabled','true'),('plugins.expanded-singles.schemaVersion','\"1.0.0\"'),('plugins.expanded-singles.settings.expandSingles','true'),('plugins.expanded-singles.settings.redirectToEntry','true'),('plugins.field-manager.edition','\"standard\"'),('plugins.field-manager.enabled','true'),('plugins.field-manager.schemaVersion','\"1.0.0\"'),('plugins.seomate.edition','\"standard\"'),('plugins.seomate.enabled','true'),('plugins.seomate.schemaVersion','\"1.0.0\"'),('plugins.tungsten.edition','\"standard\"'),('plugins.tungsten.enabled','true'),('plugins.tungsten.schemaVersion','\"1.0.0\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.defaultPlacement','\"end\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.enableVersioning','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.0','\"c678a4d3-15e8-4ea1-86d7-9b5206b7359e\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.1','\"7c32c045-0976-46d4-a6cb-9748ae189379\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.entryTypes.2','\"39b18b62-f3cf-48e0-8827-95bb425853de\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.handle','\"pages\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.maxAuthors','1'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.name','\"Pages\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.propagationMethod','\"all\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.enabledByDefault','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.template','\"page\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.uriFormat','\"{parent.uri}/{slug}\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.structure.maxLevels','3'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.structure.uid','\"fbf7ee7a-3807-4243-ab6a-a0dc25108cac\"'),('sections.8f8af384-0f07-4623-8f6d-c54bde2fa965.type','\"structure\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.defaultPlacement','\"end\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.enableVersioning','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.entryTypes.0','\"0ed79961-f5ad-4469-bd11-abcf7a9afd71\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.handle','\"home\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.maxAuthors','1'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.name','\"Home Page\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.propagationMethod','\"all\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.enabledByDefault','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.template','null'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.siteSettings.da2ec3b8-94ce-485b-8f32-4db302708c47.uriFormat','\"__home__\"'),('sections.e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0.type','\"single\"'),('siteGroups.2451a2c9-f6e7-45ba-b21f-6ba54d9018d8.name','\"Craft5 Base\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.handle','\"default\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.hasUrls','true'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.language','\"en-US\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.name','\"Craft5 Base\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.primary','true'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.siteGroup','\"2451a2c9-f6e7-45ba-b21f-6ba54d9018d8\"'),('sites.da2ec3b8-94ce-485b-8f32-4db302708c47.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Craft5 Base\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/New_York\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.altTranslationKeyFormat','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.altTranslationMethod','\"none\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocapitalize','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocomplete','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.autocorrect','true'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.class','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.disabled','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.id','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.includeInCards','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.inputType','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.instructions','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.label','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.max','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.min','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.name','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.orientation','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.placeholder','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.providesThumbs','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.readonly','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.requirable','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.size','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.step','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.tip','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.title','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.uid','\"57df7f4e-80db-413d-9a93-3d27f6b21e2d\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.warning','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.0.width','100'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.elementCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.fieldUid','\"5ccb7ad3-87b2-4106-946c-43f35b45b73b\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.handle','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.includeInCards','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.instructions','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.label','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.providesThumbs','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.required','false'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.tip','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.uid','\"d101e18f-d572-46ff-92d1-c5f8f7272b59\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.warning','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.elements.1.width','100'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.name','\"Content\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.uid','\"ecb7d8c4-c296-427c-a2e9-af437c8edf5c\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fieldLayouts.19be8d25-1ea4-4715-a912-c7b518f8af29.tabs.0.userCondition','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.fs','\"nlcCraftSitesAssets\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.handle','\"documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.name','\"Documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.sortOrder','2'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.subpath','\"documents\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.titleTranslationKeyFormat','null'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.titleTranslationMethod','\"site\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.transformFs','\"\"'),('volumes.8e0e1072-3f93-4df7-a31d-e4f06eb6277f.transformSubpath','\"\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.altTranslationKeyFormat','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.altTranslationMethod','\"none\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocapitalize','true'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocomplete','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.autocorrect','true'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.class','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.disabled','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.id','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.includeInCards','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.inputType','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.instructions','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.label','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.max','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.min','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.name','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.orientation','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.placeholder','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.providesThumbs','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.readonly','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.requirable','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.size','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.step','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.tip','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.title','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.uid','\"96e73468-e88d-4aaa-a07d-aeb7f9b1e8c7\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.warning','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.0.width','100'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.elementCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.fieldUid','\"fbc6e983-4336-4480-89fa-9084069c848c\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.handle','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.includeInCards','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.instructions','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.label','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.providesThumbs','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.required','false'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.tip','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.uid','\"3dec9884-fd99-49be-9df8-bde363c3a5ab\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.warning','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.elements.1.width','100'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.name','\"Content\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.uid','\"f4e8e41b-3883-4d91-a7e4-1e0057072979\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fieldLayouts.d95657ce-d0d3-4b7a-aa1f-47da27680636.tabs.0.userCondition','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.fs','\"nlcCraftSitesAssets\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.handle','\"images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.name','\"Images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.sortOrder','1'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.subpath','\"images\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.titleTranslationKeyFormat','null'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.titleTranslationMethod','\"site\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.transformFs','\"\"'),('volumes.c12539e4-fc26-48ee-a298-47488a5a82e0.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_gowkhsfnfrmcsfsjzqhgdbitqoufphwhermz` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_sviiodbecyiwcvskhnpgmboufucmsjlleeyg` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xkzphagjpxeeggmphtqawzdphikcjfggvutk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_cvygfrxmsrfbffokurasdmzzxlemwjniqcqi` (`sourceId`),
  KEY `idx_gujhiuggtdyccvccjrmzfcmwccizbzjxlmsm` (`targetId`),
  KEY `idx_bdymjhqylmyiqfjqpgwopkexihthgjibdqds` (`sourceSiteId`),
  CONSTRAINT `fk_bbqnhgqixsfjealphbgzenvkxjtwtuavfzga` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dyrjyutkpwwslquivmvllppifidfqzbxjyvk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgiklexjeaktryyygfajrumtjmqealysqpyp` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (1,22,8,NULL,9,1,'2024-06-03 21:16:07','2024-06-03 21:16:07','ad493288-6650-4b20-b605-4fe1cf9e354c'),(2,22,11,NULL,9,1,'2024-06-03 21:17:17','2024-06-03 21:17:17','0ef8346f-77c9-47b2-9eea-d407f603756d'),(3,22,14,NULL,9,1,'2024-06-03 21:25:29','2024-06-03 21:25:29','c008daa5-5a8e-428d-9135-228419ae8bd5'),(4,22,17,NULL,9,1,'2024-06-03 21:35:00','2024-06-03 21:35:00','495b173b-bbd5-446b-a727-8330e27471f7'),(5,18,5,NULL,7,1,'2024-06-04 17:19:43','2024-06-04 17:19:43','ea1cdd8e-557e-4db8-8f08-bdb83ab6586e'),(9,22,22,NULL,9,1,'2024-06-04 17:56:54','2024-06-04 17:56:54','3c61d79d-f9f0-41b5-8b88-e91103de4f45'),(11,22,25,NULL,9,1,'2024-06-04 17:57:26','2024-06-04 17:57:26','d3e69db0-23ae-481d-b19c-9633b25c5bc6'),(13,22,28,NULL,9,1,'2024-06-04 17:59:30','2024-06-04 17:59:30','8eca0321-334a-4769-af27-e1dc3b5d99e1'),(16,22,35,NULL,9,1,'2024-06-04 18:16:24','2024-06-04 18:16:24','bceace94-d954-4a72-a21a-9bc0153bb234'),(19,29,45,NULL,43,1,'2024-06-05 16:02:44','2024-06-05 16:02:44','af41e6a5-f755-4938-ba31-92a6276ab688'),(20,29,45,NULL,42,2,'2024-06-05 16:02:44','2024-06-05 16:02:44','10d2d2e7-d0c6-425c-b7c1-99fe8a943d74'),(21,22,47,NULL,9,1,'2024-06-05 16:02:44','2024-06-05 16:02:44','9439836e-2143-4ce2-bf71-78eee37a77fb'),(22,29,49,NULL,43,1,'2024-06-05 16:02:44','2024-06-05 16:02:44','76fbdc1c-d1b3-4526-9980-d3877e81732c'),(23,29,49,NULL,42,2,'2024-06-05 16:02:44','2024-06-05 16:02:44','c6559e41-5d43-4570-aa4a-2b69497bee5d'),(24,22,54,NULL,9,1,'2024-06-05 16:18:54','2024-06-05 16:18:54','75c4b054-c46a-41b9-a041-cad3e8271f97'),(25,29,56,NULL,43,1,'2024-06-05 16:18:54','2024-06-05 16:18:54','9f942359-e1dd-4f39-8e26-891824982e3f'),(26,29,56,NULL,42,2,'2024-06-05 16:18:54','2024-06-05 16:18:54','c72df76f-8762-4c71-aab9-f7aec57273c3'),(27,22,62,NULL,9,1,'2024-06-05 16:19:39','2024-06-05 16:19:39','f9c32b2f-c0d6-471e-b6f9-2f97c682c8d6'),(28,29,64,NULL,43,1,'2024-06-05 16:19:39','2024-06-05 16:19:39','0e19f367-e74b-432e-89c7-4a5fb98f4698'),(29,29,64,NULL,42,2,'2024-06-05 16:19:39','2024-06-05 16:19:39','8f6b5577-5cd5-4ed0-ae0c-a88e8dbb5a23');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('12f73fab','@craft/web/assets/fileupload/dist'),('14ae1b3f','@craft/web/assets/clearcaches/dist'),('14b7db47','@craft/web/assets/feed/dist'),('1bb254ae','@craft/web/assets/velocity/dist'),('1e255619','@craft/web/assets/jquerypayment/dist'),('1e76897b','@craft/web/assets/jquerytouchevents/dist'),('227e8cc7','@craft/web/assets/picturefill/dist'),('29c631c7','@craft/web/assets/xregexp/dist'),('2ba2e603','@craft/web/assets/craftsupport/dist'),('31e875de','@craft/web/assets/updates/dist'),('32524f01','@craft/web/assets/prismjs/dist'),('37c2fbc4','@craft/web/assets/htmx/dist'),('38b66fe','@craft/web/assets/elementresizedetector/dist'),('3a0f480a','@craft/web/assets/dashboard/dist'),('412af86d','@craft/web/assets/editsection/dist'),('426c6dc7','@craft/web/assets/jqueryui/dist'),('47f3a47f','@craft/web/assets/plugins/dist'),('488bfdd1','@bower/jquery/dist'),('48c1ab7f','@craft/web/assets/timepicker/dist'),('4c0be6c3','@craft/web/assets/xregexp/dist'),('4d6be239','@craft/web/assets/elementresizedetector/dist'),('50960dbc','@craft/web/assets/jquerytouchevents/dist'),('50c5d2de','@craft/web/assets/jquerypayment/dist'),('5425a2da','@craft/web/assets/updates/dist'),('5a575f80','@craft/web/assets/feed/dist'),('5a58bc3b','@craft/web/assets/edittransform/dist'),('5c17bb6c','@craft/web/assets/fileupload/dist'),('5ffd546c','@storage/rebrand/logo'),('66b7916','@bower/jquery/dist'),('6a5f5bf1','@craft/web/assets/vue/dist'),('6c9e0800','@craft/web/assets/picturefill/dist'),('6df4fd8c','@craft/web/assets/dashboard/dist'),('7c595385','@craft/web/assets/craftsupport/dist'),('7de9b86c','@nystudio107/codeeditor/web/assets/dist'),('7e7f83aa','@craft/web/assets/velocity/dist'),('85214451','@craft/web/assets/generalsettings/dist'),('8603a908','/var/www/sites/plugins/craft3-tungsten/src/assetbundles/tungstencraftresourceswidget/dist'),('8724e665','@craft/web/assets/iframeresizer/dist'),('8c0e100a','@craft/web/assets/updateswidget/dist'),('8c45efd2','@craft/web/assets/d3/dist'),('9248e3a8','@craft/web/assets/fabric/dist'),('9670c99b','@craft/web/assets/cp/dist'),('9a386bd3','@craft/web/assets/selectize/dist'),('9d2dd1f1','@craft/web/assets/tailwindreset/dist'),('9f0bf9e6','@craft/web/assets/pluginstore/dist'),('a1658e23','@craft/web/assets/tablesettings/dist'),('a2794ef3','@craft/web/assets/graphiql/dist'),('a35e245a','@tungsten/tungsten/assetbundles/tungstencraftresourceswidget/dist'),('a94f2655','@craft/web/assets/utilities/dist'),('a9891971','@craft/web/assets/conditionbuilder/dist'),('aa41c73d','@craft/web/assets/axios/dist'),('ac838','/var/www/sites/plugins/craft3-tungsten/src/assetbundles/tungsten/dist'),('ada1fb8','@craft/awss3/resources'),('aecde904','@craft/web/assets/focalpoint/dist'),('b14ec122','@verbb/base/resources/dist'),('b2b45264','@craft/web/assets/recententries/dist'),('b2fbe47c','@craft/web/assets/axios/dist'),('b6d2f546','@craft/icons/custom-icons'),('bafad4bf','@craft/web/assets/garnish/dist'),('bb77143b','@craft/web/assets/updater/dist'),('bdac0386','@verbb/fieldmanager/resources/dist'),('c18b7c1d','@craft/web/assets/cp/dist'),('c490676f','@storage/rebrand/icon'),('c8ce900','@craft/web/assets/jqueryui/dist'),('c90cfaa4','@craft/ckeditor/web/assets/ckeconfig/dist'),('c9c462a2','@craft/web/assets/iframeresizer/dist'),('cc82f151','@craft/web/assets/utilities/dist'),('ceed271b','@craft/web/assets/userpermissions/dist'),('cfadb794','@craft/web/assets/fieldsettings/dist'),('d25a6372','@craft/web/assets/sites/dist'),('d7798560','@craft/web/assets/recententries/dist'),('d9ff8d8c','@tungsten/tungsten/assetbundles/tungsten/dist'),('dbbe5a54','@craft/web/assets/d3/dist'),('dca8676f','@craft/web/assets/fabric/dist'),('e5941387','@craft/web/assets/admintable/dist'),('e9c3c70e','@craft/web/assets/updateswidget/dist'),('ece99e46','@craft/icons/custom-icons'),('ef3bd620','@verbb/expandedsingles/resources/dist'),('f41a5078','@craft/web/assets/garnish/dist'),('f8e006f5','@craft/web/assets/tailwindreset/dist'),('f928cf5','@craft/web/assets/vue/dist'),('fac62ee2','@craft/web/assets/pluginstore/dist'),('fcc302e3','@craft/ckeditor/web/assets/ckeditor/dist'),('fd2e30c6','@craft/web/assets/admintable/dist'),('fff5bcd7','@craft/web/assets/selectize/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yoxucjvmqyyixrjvvwsvndomniohvuakkqxy` (`canonicalId`,`num`),
  KEY `fk_lxibizrrahufshoixzrrdplzztvxusufapab` (`creatorId`),
  CONSTRAINT `fk_abaqaskgnutfviuffxcqfecofdkoxcmpfuqb` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lxibizrrahufshoixzrrdplzztvxusufapab` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,7,1,1,''),(3,8,1,1,NULL),(4,7,1,2,'Applied “Draft 1”'),(5,8,1,2,NULL),(6,7,1,3,'Applied “Draft 1”'),(7,8,1,3,NULL),(8,7,1,4,''),(9,8,1,4,NULL),(10,7,1,5,''),(11,8,1,5,NULL),(12,7,1,6,''),(13,8,1,6,NULL),(14,7,1,7,'Applied “Draft 1”'),(15,8,1,7,NULL),(16,33,1,1,NULL),(17,7,1,8,'Applied “Draft 1”'),(18,8,1,8,NULL),(19,33,1,2,NULL),(20,45,1,1,NULL),(21,7,1,9,'Applied “Draft 1”'),(22,8,1,9,NULL),(23,33,1,3,NULL),(24,45,1,2,NULL),(25,52,1,1,NULL),(26,7,1,10,'Applied “Draft 1”'),(27,8,1,10,NULL),(28,33,1,4,NULL),(29,45,1,3,NULL),(30,60,1,1,NULL),(31,52,1,2,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_iseayuktrwtzqtjbjncddqehpxdhmonmalid` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' info thenewline com '),(1,'firstname',0,1,' tungsten '),(1,'fullname',0,1,' tungsten admin '),(1,'lastname',0,1,' admin '),(1,'slug',0,1,''),(1,'username',0,1,' atomin '),(2,'slug',0,1,' home page '),(2,'title',0,1,' home page '),(4,'slug',0,1,''),(5,'field',5,1,''),(5,'field',17,1,''),(5,'slug',0,1,''),(6,'slug',0,1,''),(7,'field',23,1,' this is the about page lets see how this looks like when i add an image name date options peter pan january 7th 2024 more options than you can imagine jack london september 4th 2022 material has been extended i wonder how the table above looks like '),(7,'slug',0,1,' about us '),(7,'title',0,1,' about us '),(8,'field',3,1,''),(8,'slug',0,1,' por do sol em baixa grande '),(8,'title',0,1,' por do sol em baixa grande '),(9,'alt',0,1,''),(9,'extension',0,1,' jpg '),(9,'filename',0,1,' por do sol em baixa grande jpg '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' por do sol em baixa grande '),(33,'slug',0,1,' divider 1 custom default '),(33,'title',0,1,' divider visible custom default '),(40,'alt',0,1,''),(40,'extension',0,1,' pdf '),(40,'filename',0,1,' p fit seat quote part numbers reference pdf '),(40,'kind',0,1,' pdf '),(40,'slug',0,1,''),(40,'title',0,1,' p fit seat quote part numbers reference '),(41,'alt',0,1,''),(41,'extension',0,1,' pdf '),(41,'filename',0,1,' p fit back quote part numbers reference pdf '),(41,'kind',0,1,' pdf '),(41,'slug',0,1,''),(41,'title',0,1,' p fit back quote part numbers reference '),(42,'alt',0,1,''),(42,'extension',0,1,' pdf '),(42,'filename',0,1,' p fit back quote pdf '),(42,'kind',0,1,' pdf '),(42,'slug',0,1,''),(42,'title',0,1,' p fit back quote '),(43,'alt',0,1,''),(43,'extension',0,1,' pdf '),(43,'filename',0,1,' p fit seat quote pdf '),(43,'kind',0,1,' pdf '),(43,'slug',0,1,''),(43,'title',0,1,' p fit seat quote '),(45,'slug',0,1,' cards 1 '),(45,'title',0,1,' 2 document s display cards show file size yes '),(52,'slug',0,1,' youtube video '),(52,'title',0,1,' youtube video '),(60,'slug',0,1,' visible space above default space below default '),(60,'title',0,1,' visible space above default space below default ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eiqykpvcjsnovllhfqjfipxdcusgbhvxcgmv` (`handle`),
  KEY `idx_nyneazlcijyglerhqekfwjytwmxcofnpyobm` (`name`),
  KEY `idx_uofadfyoljzwoagncqykrznhssorfpeasifq` (`structureId`),
  KEY `idx_gbklnpiympffwkydlbutaxbkycgygyusoepb` (`dateDeleted`),
  CONSTRAINT `fk_xgkdhjetuvohnnnapsjepgzqzqwawozatwqy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home Page','home','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-01 19:17:24','2024-06-01 19:17:24',NULL,'e2b2b216-7fc2-4bfa-bdfa-16e37bfd87d0'),(2,1,'Pages','pages','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-06-03 17:28:16','2024-06-03 17:28:16',NULL,'8f8af384-0f07-4623-8f6d-c54bde2fa965');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_qzalxyaymrbanekcjmsywgteskfjpjhuwgsl` (`typeId`),
  CONSTRAINT `fk_oamkjunefiqlewkqksejcztensvtrdxspbpz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qzalxyaymrbanekcjmsywgteskfjpjhuwgsl` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1),(2,2,1),(2,3,2),(2,4,3);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ykbkifngzmhxegmyulgvbtmbjvdtmlmjkjeb` (`sectionId`,`siteId`),
  KEY `idx_tpmhngcursfoujvnochqpstdgnkopzmwegqd` (`siteId`),
  CONSTRAINT `fk_beprpvpmyksfxkegskanyooluswkqlttvmfd` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nuwxnvvkdiookqjxbjuaoftolzvyhhlgazlx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__',NULL,1,'2024-06-01 19:17:24','2024-06-01 19:17:24','dd9fe0fb-3dc7-4051-aaff-b369ee9cb704'),(2,2,1,1,'{parent.uri}/{slug}','page',1,'2024-06-03 17:28:16','2024-06-03 17:28:16','daca6403-13b4-4f66-abd4-42eaa3f2e78d');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kwgsgfgojbdkpqtpozbrzvhettxxmlhrgfbh` (`uid`),
  KEY `idx_hbmobhrezudfofphfpzetnfvgzdemlqzwqpy` (`token`),
  KEY `idx_yvwibjkuozgcefyqlvmfybslaraungruzjsv` (`dateUpdated`),
  KEY `idx_mfqmncutnfafyziamqounrbujdolnowwpqmc` (`userId`),
  CONSTRAINT `fk_yyvuumhyaszhtvbmetbdudlnzbicuswazmui` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'IDmkV5ZM8sF5qmmTCv51rtDTbqzrFiUAWp12oNsMkn_350QcUVZ68fY3JwPnUVmkuSA6bSRqmBdS8FBquA99FV8Z2b4XpU3MNt_E','2024-06-01 00:08:54','2024-06-01 00:46:05','254584e5-bd01-41d3-a347-c78c247e003f'),(2,1,'KL-5wycD-H8FrGvimdJp6Jl0KEErB5pqh9KvvY1scOC0hon3VC-_cA5ughUPO3ZqkZE0GDdvt1z9IpNUYRPy5_0TgUeI4Pk2pKL_','2024-06-01 18:54:20','2024-06-01 19:54:01','c97345d9-b124-4e78-a44e-3e7889bfd16e'),(3,1,'uZ5Qmwi7MxnC90yFw7Myn1QOZdabwroeFIzuiC-dsYRsp_OHTSDGVsIZzA0s6roETwpEzpU-tYvD9vvEP96WQMAkw2NprtcI8mWw','2024-06-03 15:35:10','2024-06-03 17:59:27','04a1c095-24e0-4a84-88b7-3f4b0ecd72fa'),(4,1,'7Ch7JzS1TWmxlyQtHbTTOeGDrWZj427ZZn8XR5ufJYvTCcQWP22CCsfu8XgAw2OqDIRv2BSY-7mJBNHoMjju5-Og5YYTNOtH2cim','2024-06-03 19:38:15','2024-06-03 21:45:04','16a2f11b-87f9-4b48-a7df-0ab83f4e7571'),(5,1,'BDlEDb-Cd1-LazdWMnELkPnpGdr2fpf5bKNO_2wT7zEiyXDzLcIM5OKMp5tgrl3TgbbCLTX1M7UJ8kui8VePYSvM0O3pLqoZeiGm','2024-06-04 12:59:06','2024-06-04 19:03:28','9a8f7b66-d3d6-41ac-b645-ee6de656ea7c'),(7,1,'wb4Gh-B8st5jHa7XdQfYcIxblWmp1qpbYqKGG2iTESdYIEZaNBSf2vVo1-yiiaCzN7H4sOr5tvM5O_e3qurdng6m2L5orqh5KiMt','2024-06-05 15:15:46','2024-06-05 15:25:59','9cfa4c6a-5843-4674-9e56-bbf7d7915bb2'),(8,1,'1raGjQ0qyXuv-VGYivw3T_eQdkxJZ_IfNMvqh4YE5hx7JP3SH_l_RkVz3IHqyZTFt1jPKaKcQmYjwUHNU3GISlfjX4UdwBg-8Vru','2024-06-05 15:54:09','2024-06-05 16:26:57','f741a67f-ee04-46e3-96b0-01c5fc55a31d');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lilygbqtewjenqugfpcesiglwepiqycbmopg` (`userId`,`message`),
  CONSTRAINT `fk_raavtmsyxilbwxbpngxstculfzsyyrtdjllg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kbsdfujttridhkrtdvvqwapwtcnyfwxoxqnn` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Craft5 Base','2024-06-01 00:08:08','2024-06-01 00:08:08',NULL,'2451a2c9-f6e7-45ba-b21f-6ba54d9018d8');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uhqzzulmlziktmdjtzrfuficzvbbhkumxtai` (`dateDeleted`),
  KEY `idx_mseocoosxcjckquhegkronwzeoxqvpzmxvzi` (`handle`),
  KEY `idx_zyrrtrawqojzhnhljaprrjqbewokususpceu` (`sortOrder`),
  KEY `fk_ppwijlcyhosgvenwzhaeuhijzkkaelldmren` (`groupId`),
  CONSTRAINT `fk_ppwijlcyhosgvenwzhaeuhijzkkaelldmren` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Craft5 Base','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-06-01 00:08:08','2024-06-01 00:08:08',NULL,'da2ec3b8-94ce-485b-8f32-4db302708c47');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_docxezndixnkkxhglaijpiqxsxuexhbgdmgr` (`structureId`,`elementId`),
  KEY `idx_qrlikeponngibrrknkbhdiytsaeimyyuegkk` (`root`),
  KEY `idx_masearxatbhtmxybgdmjdvxspfathwywprmz` (`lft`),
  KEY `idx_zcyhzidjqrcvdbcjfviepspmpqeaqmnpuuuo` (`rgt`),
  KEY `idx_jaxbxjcwqwmboahsjgdcopukfmbmwxxokdiw` (`level`),
  KEY `idx_vntsxqtljpzsajeepjrxbcdkydjimvbowfjz` (`elementId`),
  CONSTRAINT `fk_rygdrsvnopexrovbucfgruuthkliatbjyslq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,4,0,'2024-06-03 21:14:24','2024-06-03 21:14:24','ff8f59ed-ec4a-48e9-8f59-ba120fad823e'),(2,1,7,1,2,3,1,'2024-06-03 21:14:24','2024-06-03 21:14:24','13489108-cfbf-470e-b88a-451544899f29');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fyxmorvmtnferhgneqifdfbgdjdijxribkgg` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,3,'2024-06-03 17:28:16','2024-06-03 17:28:16',NULL,'fbf7ee7a-3807-4243-ab6a-a0dc25108cac');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ygysemeiiajolrqmjrnjfssnexugsyebflgl` (`key`,`language`),
  KEY `idx_zhonjvxzpissfqacybagkvbxhvbypdyivwls` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qyzathanlpsnndtsjxdpkozqszfphltlaykl` (`name`),
  KEY `idx_ejfbfzhvvquywvbkjymsopmprdccbvklnkvq` (`handle`),
  KEY `idx_nxgvbpudjnbtmrnvbekvpqhasfvswdaxmxfg` (`dateDeleted`),
  KEY `fk_tanrtegfjzqwkakklfxotvzzkugdelupveoh` (`fieldLayoutId`),
  CONSTRAINT `fk_tanrtegfjzqwkakklfxotvzzkugdelupveoh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_piduihbanwrgoppjhwcpxgvhbabudrelxtji` (`groupId`),
  CONSTRAINT `fk_kqcvprughnibjwjorsvnixizpcaanqnbiaop` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omvooueckeggauyavtoeexxyjtmwnguazdkx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rrugsjrhinpnptkqlksxiifhipsbyutxprti` (`token`),
  KEY `idx_prupsfcvdsvkidybnpiktvgzjqhpvypnztcp` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fuqfwxnocniicwatgcslfwwwtjjxrksxdsxp` (`handle`),
  KEY `idx_xgtvsnhxlwlrslccerhjnsfpsqyrocvgjrnu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_azhkwewwxzsgnhzvimcztvknmkcbkxiytyck` (`groupId`,`userId`),
  KEY `idx_vdvazggejwxsebbwezpenxdopbbtwdyvhakp` (`userId`),
  CONSTRAINT `fk_ofyrsnybwfhiiznuzbzvvixgmrzlyhucstmm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ustgnftjlqjxotdpoooxqombysyqnsojrfoj` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gfhljicrovfbcxhxzgcskebzzkroocwsxrav` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nflowltwwjzwmhiksugofjvjzwmcynubeuwj` (`permissionId`,`groupId`),
  KEY `idx_wspcukpiwllzfhpysyfuhgrpgxvzyoaxucpo` (`groupId`),
  CONSTRAINT `fk_gynatkiwyalzkppeoghitzeedbarcdzvjgqg` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rxpstcvvlunspvutidieqzgircbucfuhcuwa` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqquvnewxzlsnjzdtvemizqejqjmamkmxjlb` (`permissionId`,`userId`),
  KEY `idx_tngghyyzynqrzuizxzwtaytiklvcasmmparj` (`userId`),
  CONSTRAINT `fk_dgnzweeydtzvhqthzaoevkeciuehneziptni` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zzkztnopgbeoekrbywbbtekgqcebuhzbpqkq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_jomqubqcxplkwvwusehzurpvzflnzzzsxnsj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"locale\": null, \"language\": \"en-US\", \"useShapes\": false, \"weekStartDay\": \"1\", \"underlineLinks\": false, \"disableAutofocus\": \"\", \"profileTemplates\": false, \"showFieldHandles\": false, \"showExceptionView\": false, \"alwaysShowFocusRings\": false, \"notificationDuration\": \"5000\", \"enableDebugToolbarForCp\": false, \"enableDebugToolbarForSite\": false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ursyoqujnsadqwqdpquqgflrvinbcydbbjrt` (`active`),
  KEY `idx_mxwdhjloosplxcywhbpfiphrxroqgzuszzbp` (`locked`),
  KEY `idx_onktqgfizdlnyodtkobyjfflibcptzkqzcgx` (`pending`),
  KEY `idx_jukmysuihodnoajmdgewoimjaqhaqflbhwfj` (`suspended`),
  KEY `idx_qsjpgfoycuqcreazlatvufvqellieipxagqa` (`verificationCode`),
  KEY `idx_vxkjyeihhsynlmfmumxxnmfpzpxahzrjazgm` (`email`),
  KEY `idx_lcgacbikjmcyclogvfucljpzyilfebtcoldm` (`username`),
  KEY `fk_nhsvrvzyzbyfinqgxymaftiehgerylqrxclh` (`photoId`),
  CONSTRAINT `fk_nhsvrvzyzbyfinqgxymaftiehgerylqrxclh` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rmiqocolprgwrthoghavoyrhbicwfdjwdqdv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'atomin','Tungsten Admin','Tungsten','Admin','info@thenewline.com','$2y$13$cr/jBliW34kf8ArdiagYgOw1h4ealtjFOCRm1amSRzJHvB/za0Nai','2024-06-05 15:54:09',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-06-01 00:08:08','2024-06-01 00:08:08','2024-06-05 15:54:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_novmnatnhvqjbofwapliddowrwmnhtfyagay` (`name`,`parentId`,`volumeId`),
  KEY `idx_hlrmygmvhmbwomuxmtthzsvuxosigteayjsl` (`parentId`),
  KEY `idx_fkkgswvsblmclepeugtcmggvjxxewqpufbwt` (`volumeId`),
  CONSTRAINT `fk_egiaoiykbjggtnjsanwrirrwjvacxiqbqanr` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wkshspceivictocpkajccrhfufnzaembxocg` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images',NULL,'2024-06-01 19:07:11','2024-06-01 19:08:28','37dd4b1c-0f0d-4d15-993d-e3d58797c906'),(2,NULL,2,'Documents','','2024-06-01 19:12:31','2024-06-01 19:12:31','b990489e-3ae5-48c9-af30-33244e8b563a'),(3,NULL,NULL,'Temporary Uploads',NULL,'2024-06-01 19:12:57','2024-06-01 19:12:57','66c1c1e1-03fd-43b6-a05f-9d793ef49e0b'),(4,3,NULL,'user_1','user_1/','2024-06-01 19:12:57','2024-06-01 19:12:57','515cc3f3-d70d-4686-9abc-0e51588b2298');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tisrboattoyomphxkguelfhtxrxycyhowsuu` (`name`),
  KEY `idx_eamnjjanuyywonmmydzuivsfijjedjzyiuic` (`handle`),
  KEY `idx_twwgsnstfcnxxqdwsmvacgxwnonikwaufgdf` (`fieldLayoutId`),
  KEY `idx_xejkavovnfkhebpftqrtfsjjpmjovplnackk` (`dateDeleted`),
  CONSTRAINT `fk_vkvtlcaxnxevljtdecuwobxrrvcfujkuycxi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,1,'Images','images','nlcCraftSitesAssets','images','','','site',NULL,'none',NULL,1,'2024-06-01 19:07:11','2024-06-01 19:08:28',NULL,'c12539e4-fc26-48ee-a298-47488a5a82e0'),(2,2,'Documents','documents','nlcCraftSitesAssets','documents','','','site',NULL,'none',NULL,2,'2024-06-01 19:12:31','2024-06-01 19:12:31',NULL,'8e0e1072-3f93-4df7-a31d-e4f06eb6277f');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ldykmldsaouffhhvvedgiffbbrioqqfpvirx` (`userId`),
  CONSTRAINT `fk_ldykmldsaouffhhvvedgiffbbrioqqfpvirx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_myhxwqparfkfiuzenwsrgdaxhbygjdenvzgu` (`userId`),
  CONSTRAINT `fk_cgyhecrplafrdnyuesjiycistgfxsvxsyvmr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-06-01 00:08:55','2024-06-01 00:08:55','09244fa2-1320-4f85-9ec6-de348337c12a'),(6,1,'tungsten\\tungsten\\widgets\\TungstenCraftResources',2,NULL,'[]',1,'2024-06-04 17:16:06','2024-06-04 17:16:06','ebb41b00-67b5-470a-a26f-ae8ebbffbddc');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-05 12:27:09
